#!/bin/bash
echo "开始删除!"
rm -r /home/helen/sample/test
rm -r /home/helen/sample/sdb
mkdir  /home/helen/sample/test
mkdir  /home/helen/sample/sdb


