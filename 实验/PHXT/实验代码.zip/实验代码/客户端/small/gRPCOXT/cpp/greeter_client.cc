#include <iostream>
#include <memory>
#include <string>
#include<list>
#include<stdlib.h>
#include<NTL/ZZ.h>
#include <grpcpp/grpcpp.h>
#include<sys/time.h>
#ifdef BAZEL_BUILD
#include "examples/protos/helloworld.grpc.pb.h"
#else
#include "helloworld.grpc.pb.h"
#endif
#include"include/aes.h"
#include"include/bf.h"
#include"include/oxtf.h"
#include"include/Conn.h"
#include"include/tools.h"
using grpc::Channel;
using grpc::ChannelArguments;
using grpc::ClientContext;
using grpc::Status;
using helloworld::HelloRequest; 
using helloworld::HelloReply;
using helloworld::Greeter;
using namespace std;

class GreeterClient {
 public:
  GreeterClient(std::shared_ptr<Channel> channel)
      : stub_(Greeter::NewStub(channel)) {}

  // Assembles the client's payload, sends it and presents the response back
  // from the server.
  std::string SayHello(const std::string& user) {
    // Data we are sending to the server.
    HelloRequest request;
    request.set_name(user);

    HelloReply reply;

    ClientContext context;

    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }


  std::string SayHello1(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello1(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

  std::string SayHello2(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello2(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

  std::string SayHello3(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello3(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

 private:
  std::unique_ptr<Greeter::Stub> stub_;
};

int main(int argc, char** argv) {

  //计算程序的执行时间：
  struct timeval tp;
	struct timeval tp1;
  struct timeval start1;
	struct timeval end1;
  
  struct timeval start3;
	struct timeval end3;

  struct timeval start4;
	struct timeval end4;

  int i,j;
  int kwlen;
  long xlen, qbytes;

  char querybloom1sql[150];

  uint8_t tmp[32];
  uint8_t ke[16];
  uint8_t kl[16];
  uint8_t plain_id[16];
  uint8_t l[16];
  uint8_t data[64];
  uint8_t intb[4];
  uint8_t indexvaluesearchbyte[8];
  uint8_t realvaluebyte[4];
  uint8_t idindex[16];
  //记录客户端计算的全为1的异或结果
  uint8_t resultvalue[16];
  uint8_t k[16];
  uint8_t d1[16];
  uint8_t additition[16];
  ZZ xind,z,y,kxw;
  struct AES_ctx ctx;
  struct AES_ctx ctx1;
  struct AES_ctx ctx2;
  
  oxt_param_ptr oxt;
  
  ZZ g,p,q;
  ZZ_from_char(g,ag);
  ZZ_from_char(p,ap);
  ZZ_from_char(q,aq);
  oxt_param poxt={g,q,p,aks,akx,aki,akz,QLEN,PLEN,16, 16,16, 16, ID_LEN_IN_BYTE};
  oxt=&poxt;
  qbytes=NumBytes(oxt->q);
  ChannelArguments args;
  // Set the default compression algorithm for the channel.
  args.SetCompressionAlgorithm(GRPC_COMPRESS_GZIP);
  GreeterClient greeter(grpc::CreateCustomChannel(
      "192.168.120.12:50051", grpc::InsecureChannelCredentials(), args));
  cout<<"请输入要查询的关键字"<<endl;
  list<char *> searchword;
  list<char *>::iterator itor;
  for(int i=0;i<2;i++){
    char *word=new char[100];
    cin>>word;
    searchword.push_back(word);
  }
  //获得开始执行时间
  gettimeofday(&tp,NULL);
  gettimeofday(&start1,NULL);
  uint8_t *keyword=(uint8_t*)searchword.front();
    //Todo:获取关键词pkeywords[i]的byte长度
  kwlen=strlen(searchword.front());//获得关键字的长度
    //cout<<tokens.front()<<endl;
  cat_uint(data,oxt->Ks,keyword,oxt->kslen,kwlen);//data=Ks||kw1
  DeriveKey(tmp,32,data,oxt->kslen+kwlen);
  string stagstring=base64_encode(tmp,32);
  gettimeofday(&end1,NULL);
  double clienttime1 = 1000000 * (end1.tv_sec -start1.tv_sec) + end1.tv_usec - start1.tv_usec;
  clienttime1/=1000000;
  //cout<<stagstring<<endl;
  //将产生的stag发送给服务器
  
  //gettimeofday(&start4,NULL);
  std::string reply = greeter.SayHello(stagstring);
  // gettimeofday(&end4,NULL);
  // double tx1 = 1000000 * (end4.tv_sec -start4.tv_sec) + end4.tv_usec - start4.tv_usec;
  // cout<<"第一个通讯方法："<<tx1/1000000<<endl;
  //这里是返回对应产生的所有的索引地址
  int frcount=atoi(reply.data());
  cout<<"frcount"<<frcount<<endl;
  int icount=0;
  int c1;

  //如果返回值为，直接结束程序，显示查询结果为空
  if(frcount==0){
    cout<<"查询结果为空，程序结束"<<endl;
    exit(1);
  }
  
  //用来计算通讯成本：
  //long clientlen=0;
  //long serverlen=0;

  //clientlen=clientlen+stagstring.length()+1;
  //serverlen=serverlen+reply.length()+1;

  //构建xtoken
  double clienttime2=0;
  double tongxun=0;
  int resultcountindex=0;
  string resultstr="";
  for (int i=0;i<frcount;i++)//循环w1查询到的id个数
  {
    struct timeval start2;
	  struct timeval end2;
    gettimeofday(&start2,NULL);
    //ZZ xtokes[tokens.size()-1];//生成输入的关键字个数减1个的xtoken
    list<int> indexlist;
    list<int>::iterator indexitor;
    int_to_uint8(resultcountindex,intb);
    cat_uint(data,keyword,intb,kwlen,4);//在生成xtoken的过程中，kzw使用的是  w1
    oxt_prf(z,oxt->Kz,data,oxt->kzlen,kwlen+4,oxt->q,qbytes);//z是w1对应c的z
    //cout<<"进入1"<<endl;
    int icount=0;
    string finxtoken="";
    for(itor=searchword.begin();itor!=searchword.end();itor++){
      icount++;
      //cout<<"进入2"<<endl;
      if(icount!=1){
        uint8_t *bkeyword=(uint8_t*)*itor;
        int bkwlen=strlen(*itor);
        oxt_prf(kxw,oxt->Kx,bkeyword,oxt->kxlen,bkwlen,oxt->q,qbytes);
        ZZ xtokes;
        oxt_xtoken(xtokes,z,kxw,oxt);
        int ZZxtokenlen=NumBytes(xtokes);
        uint8_t *xokenchar=new uint8_t[ZZxtokenlen];
        BytesFromZZ(xokenchar,xtokes,ZZxtokenlen);
        string xtokenstring=base64_encode(xokenchar,ZZxtokenlen);
        finxtoken.append(xtokenstring).append(",");
      }
    }
    //clientlen=clientlen+finxtoken.length()+1;
    gettimeofday(&end2,NULL);
    double fortime = 1000000 * (end2.tv_sec -start2.tv_sec) + end2.tv_usec - start2.tv_usec;
    fortime/=1000000;
    //cout<<fortime<<endl;
    clienttime2+=fortime;
    //gettimeofday(&start3,NULL);
    std::string reply1 = greeter.SayHello1(finxtoken);
    // gettimeofday(&end3,NULL);
    // double timetx = 1000000 * (end3.tv_sec -start3.tv_sec) + end3.tv_usec - start3.tv_usec;
    // tongxun+=timetx;
    //serverlen=serverlen+ reply1.length()+1;
    resultstr.append(reply1).append(",");
    //获取到所有的索引位置
    resultcountindex++;
  }
  tongxun/=1000000;
  //cout<<"通讯方法2："<<tongxun<<endl;
  gettimeofday(&tp1,NULL);
  //std::cout << "Greeter received: " << reply1 << std::endl;
  for(j=0;j<16;j++)
  {
      ke[j]=tmp[j];//ke to encrypt the document id
      kl[j]=tmp[j+16];//kl to generate the dictionary index
  }
  AES_init_ctx(&ctx, ke);
  list<string> elist;
  list<string>::iterator elistitor;
  StringSplit(resultstr,",",elist);
  int sumid=0;
  for(elistitor=elist.begin();elistitor!=elist.end();elistitor++){
    string dee=base64_decode(*elistitor);
    uint8_t *uchare=(uint8_t*)dee.data();
        AES_ECB_decrypt(&ctx, uchare);
        //cout<<uchare<<"   ";
        uint8_t *charid=new uint8_t[4];
        for(int j=12;j<16;j++){
          charid[j-12]=uchare[j];
        }
        int id=(int)charid[0]+((int)charid[1]*256)+((int)charid[2]*256*256)+((int)charid[3]*256*256*256);
        //cout<<"id:"<<id<<endl;
        sumid++;
  }
  cout<<"查询结果集："<<sumid<<endl;
  
  double timer = 1000000 * (tp1.tv_sec -tp.tv_sec) + tp1.tv_usec - tp.tv_usec;
  cout<<"客户端时间："<<clienttime1+clienttime2<<endl;
  cout<<"总时间："<<timer/1000000<<endl;
  //cout<<"通讯成本："<<(double)(clientlen+serverlen)/1024/1024<<endl;
  //string deletestr= greeter.SayHello3("请求清除数组");
  //cout<<deletestr<<endl;
  return 0;
}
