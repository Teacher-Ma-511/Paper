#ifndef Tools_H_INCLUDED
#define Tools_H_INCLUDED
#include<iostream>
#include<string>
#include<list>
using namespace std;

void StringSplit(const std::string& strData, const std::string& strDelim, std::list<std::string>& lstSplitString)
{
	size_t iLast = 0;       
	size_t iIndex = 0;  
	iIndex = strData.find_first_of(strDelim, iLast);  
	while(iIndex != std::string::npos)  
	{  
		std::string strTemp = strData.substr(iLast, iIndex - iLast);     //拿到的值
		if (!strTemp.empty())
		{
			lstSplitString.push_back(strTemp);
		}		
		
		iLast = iIndex + strDelim.length();		//记录偏移位置
		iIndex = strData.find_first_of(strDelim, iLast);  
	}
	
	//处理最后一个
	iIndex = strData.length();
	if (iIndex > iLast)  
	{  
		std::string strTemp = strData.substr(iLast, iIndex - iLast);     //拿到的值 
		if (!strTemp.empty())
		{
			lstSplitString.push_back(strTemp);
		}
	}
 
	return;
}

#endif