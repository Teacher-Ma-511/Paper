/*
 *
 * Copyright 2018 gRPC authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <iostream>
#include <memory>
#include <string>
#include<list>
#include<stdlib.h>
#include<sys/time.h>
#include<NTL/ZZ.h>
#include <grpcpp/grpcpp.h>

#ifdef BAZEL_BUILD
#include "examples/protos/helloworld.grpc.pb.h"
#else
#include "helloworld.grpc.pb.h"
#endif
#include"include/aes.h"
#include"include/bf.h"
#include"include/fhxt.h"
#include"include/tools.h"
#include"include/Conn.h"
using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::Status;
using helloworld::HelloRequest;
using helloworld::HelloReply;
using helloworld::Greeter;
using namespace std;
struct set_bf sbf;
int resultcount=0;
int zindex=-1;
string localresult="";
//记录每一个id对应的所有的索引地址
string indexresult="";

string *e;

double servertime=0;
// Logic and data behind the server's behavior.
class GreeterServiceImpl final : public Greeter::Service {
  Status SayHello(ServerContext* context, const HelloRequest* request,
                  HelloReply* reply) override {
    // Overwrite the call's compression algorithm to DEFLATE.
    servertime=0;
    struct timeval start;
	  struct timeval end;
   

    int i,j;
    int kwlen;
    long xlen, qbytes;

    char querybloom1sql[150];
    uint8_t tmp[32];
    uint8_t ke[16];
    uint8_t kl[16];
    uint8_t plain_id[16];
    uint8_t l[16];
    uint8_t data[64];
    uint8_t intb[4];

    ZZ xind,z,y,kxw;

    zindex=-1;
    context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
    string stagstring=request->name();
    gettimeofday(&start,NULL);
    string destagstring=base64_decode(stagstring);
    uint8_t *stag=(uint8_t*)destagstring.data();
    for(j=0;j<16;j++)
    {
        ke[j]=stag[j];//ke to encrypt the document id
        kl[j]=stag[j+16];//kl to generate the dictionary index
    }
    int c=0;
    int rowcount;
    
    localresult="";
    string replystring="";
    ConnectDatabase();
     while(true){//生成一个关键字所有的l，并且用c记录id个数
      //startTime3=clock();
      int_to_uint8(c,intb);
      cat_uint(data,kl,intb,16,4);
      DeriveKey(l,16,data,20);
      string strl=base64_encode(l,16);
      const char *charl=strl.data();  
      //endTime3=clock();
      //ltime=ltime+(double)((endTime3 - startTime3));
      string e,y; 
      int ylen;
      Queryeninverted(charl,e,rowcount);
      if(rowcount==0){
        break;
      }
      localresult.append(e).append(",");
      c++;
      
    }
    //cout<<"localresult："<<localresult<<endl;
    list<string> firstresult;
    list<string>::iterator firstresultitor;
    StringSplit(localresult,",",firstresult);
    resultcount=firstresult.size()/3;
    e=new string[resultcount];


    int index=1;
    int frcount=0;

    for(firstresultitor=firstresult.begin();firstresultitor!=firstresult.end();firstresultitor++){
      if(index%3==1){
        e[frcount]=*firstresultitor;
        string tmpe=*firstresultitor;
        replystring.append(tmpe).append(",");
      } 
      if(index%3==0){
        frcount++;
      }
      index++;
    }
    mysql_free_result(res);
    FreeConnect();
    gettimeofday(&end,NULL);
    double server1=1000000 * (end.tv_sec -start.tv_sec) + end.tv_usec - start.tv_usec;
    server1/=1000000;
    servertime+=server1;
    reply->set_message(replystring);
    return Status::OK;
  }

  Status SayHello1(ServerContext* context, const HelloRequest* request,
                  HelloReply* reply) override {

    struct timeval start;
	  struct timeval end;

    indexresult="";
    zindex++;
    context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
    string xtoken=request->name();
    gettimeofday(&start,NULL);
    list<string> xtokenlist;
    list<string>::iterator xtokenlistitor;
    StringSplit(xtoken,",",xtokenlist);
    //搜索关键字减一
    int xtokenlen=xtokenlist.size();
    list<long> indexlist;
    list<long>::iterator indexlistitor;
    int index=0;
    for(xtokenlistitor=xtokenlist.begin();xtokenlistitor!=xtokenlist.end();xtokenlistitor++){
      string enxtoken=*xtokenlistitor;
      string dextoken=base64_decode(enxtoken);
      query_index((uint8_t*)dextoken.data(),dextoken.length(),&sbf,indexlist);
      index++;
    }

    //获取位置
    for(indexlistitor=indexlist.begin();indexlistitor!=indexlist.end();indexlistitor++){
      unsigned int queryresult= query1_set(*indexlistitor,&sbf);
      indexresult.append(to_string(queryresult));
    }
    //cout<<indexresult<<endl;
    unsigned int serverhash=DJBHash(indexresult.data());
    gettimeofday(&end,NULL);
    double server2=1000000 * (end.tv_sec -start.tv_sec) + end.tv_usec - start.tv_usec;
    server2/=1000000;
    servertime+=server2;
    cout<<"服务器时间："<<servertime<<endl;
    reply->set_message(to_string(serverhash));

    return Status::OK;
  }

  Status SayHello2(ServerContext* context, const HelloRequest* request,
                  HelloReply* reply) override {
    context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
    cout<<"servertime:"<<servertime<<endl;
    std::string prefix("，已执行delete操作！！！！");
    reply->set_message(prefix);
    return Status::OK;
  }
};

// class GreeterServiceImpl final : public Greeter::Service1 {
//   Status SayHello(ServerContext* context, const HelloRequest* request,
//                   HelloReply* reply) override {
//     // Overwrite the call's compression algorithm to DEFLATE.
//     context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
//     std::string prefix("Hello ");
//     reply->set_message(prefix + request->name());
//     return Status::OK;
//   }
// };

void RunServer() {
  std::string server_address("0.0.0.0:50051");
  GreeterServiceImpl service;

  ServerBuilder builder;
  // Set the default compression algorithm for the server.
  builder.SetDefaultCompressionAlgorithm(GRPC_COMPRESS_GZIP);
  // Listen on the given address without any authentication mechanism.
  builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
  // Register "service" as the instance through which we'll communicate with
  // clients. In this case it corresponds to an *synchronous* service.
  builder.RegisterService(&service);
  // Finally assemble the server.
  std::unique_ptr<Server> server(builder.BuildAndStart());
  std::cout << "Server listening on " << server_address << std::endl;

  // Wait for the server to shutdown. Note that some other thread must be
  // responsible for shutting down the server for this call to ever return.
  server->Wait();
}

int main(int argc, char** argv) {
  ConnectDatabase();
  int intarrlen;
  init_set(&sbf,58563827,NUM_OF_HASH,intarrlen);
  char sql[150];
  list<unsigned int> uintlist;
  list<unsigned int>::iterator uintitor;
  sprintf(sql,"select * from fhxtbloom1");
  QueryBloom(sql,uintlist);
  cout<<"查询长度："<<uintlist.size();
  int i=0;
  for(uintitor=uintlist.begin();uintitor!=uintlist.end();uintitor++){
    sbf.pbf->bf_array[i]=*uintitor;
    i++;
  }
  RunServer();
  
  return 0;
}
