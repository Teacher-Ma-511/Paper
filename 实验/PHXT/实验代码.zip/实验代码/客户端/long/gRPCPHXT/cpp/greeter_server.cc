/*
 *
 * Copyright 2018 gRPC authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <iostream>
#include <memory>
#include <string>
#include<list>
#include<sys/time.h>
#include<stdlib.h>
#include<NTL/ZZ.h>
#include <grpcpp/grpcpp.h>

#ifdef BAZEL_BUILD
#include "examples/protos/helloworld.grpc.pb.h"
#else
#include "helloworld.grpc.pb.h"
#endif
#include"include/aes.h"
#include"include/bf.h"
#include"include/phxt.h"
#include"include/tools.h"
#include"include/Conn.h"
using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::Status;
using helloworld::HelloRequest;
using helloworld::HelloReply;
using helloworld::Greeter;
using namespace std;
struct set_bf sbf;
int resultcount=0;
int zindex=-1;
string localresult="";
//记录每一个id对应的所有的索引地址
string indexresult="";

string *ene;
string *eny;
string *dee;
string *dey;
int *ylenarr;
ZZ *zy;
double servertime=0;

// Logic and data behind the server's behavior.
class GreeterServiceImpl final : public Greeter::Service {
  Status SayHello(ServerContext* context, const HelloRequest* request,
                  HelloReply* reply) override {
    // Overwrite the call's compression algorithm to DEFLATE.
    servertime=0;
    double time1=0;
    struct timeval starttime;
    struct timeval endtime;
    
    int i,j;
    int kwlen;
    long xlen, qbytes;

    char querybloom1sql[150];
    uint8_t tmp[32];
    uint8_t ke[16];
    uint8_t kl[16];
    uint8_t plain_id[16];
    uint8_t l[16];
    uint8_t data[64];
    uint8_t intb[4];

    ZZ xind,z,y,kxw;

    zindex=-1;
    context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
    string stagstring=request->name();
    gettimeofday(&starttime,NULL);
    //cout<<"stagstring："<<stagstring<<endl;
    string destagstring=base64_decode(stagstring);
    uint8_t *stag=(uint8_t*)destagstring.data();
    //cout<<"stag uint8_t"<<stag<<endl;
    for(j=0;j<16;j++)
    {
        ke[j]=stag[j];//ke to encrypt the document id
        kl[j]=stag[j+16];//kl to generate the dictionary index
    }
    int c=0;
    int rowcount;
    
    string sumresult="";
    localresult="";
    ConnectDatabase();
    while(true){//生成一个关键字所有的l，并且用c记录id个数
      //startTime3=clock();
      int_to_uint8(c,intb);
      cat_uint(data,kl,intb,16,4);
      DeriveKey(l,16,data,20);
      string strl=base64_encode(l,16);
      const char *charl=strl.data();  
      //endTime3=clock();
      //ltime=ltime+(double)((endTime3 - startTime3));
      string e,y; 
      int ylen;
      Queryeninverted(charl,e,rowcount);
      if(rowcount==0){
        break;
      }
      localresult.append(e).append(",");
      c++;
      
    }
    //cout<<"localresult："<<localresult<<endl;
    list<string> firstresult;
    list<string>::iterator firstresultitor;
    StringSplit(localresult,",",firstresult);
    resultcount=firstresult.size()/3;
    ene=new string[resultcount];
    eny=new string[resultcount];
    dee=new string[resultcount];
    dey=new string[resultcount];
    ylenarr=new int[resultcount];
    int index=1;
    int frcount=0;

    for(firstresultitor=firstresult.begin();firstresultitor!=firstresult.end();firstresultitor++){
      if(index%3==1){
        ene[frcount]=*firstresultitor;
      }
      else if(index%3==2){
        eny[frcount]=*firstresultitor;
      }else{
        string y=*firstresultitor;
        ylenarr[frcount]=atoi(y.data());
      }
      
      if(index%3==0){
        frcount++;
      }
      index++;
    }
    for(int i=0;i<resultcount;i++){
      dee[i]=base64_decode(ene[i]);
      dey[i]=base64_decode(eny[i]);
    }
    list<uint8_t*> uchary;
    list<uint8_t*>::iterator ucitor;
    for(int i=0;i<resultcount;i++){
      uchary.push_back((uint8_t*)dey[i].data());
    }
    zy=new ZZ[resultcount];
    int zyi=0;
    for(ucitor=uchary.begin();ucitor!=uchary.end();ucitor++){
      int zlen=strlen((char*)(*ucitor));
      zy[zyi]=ZZFromBytes(*ucitor,ylenarr[zyi]);
      //cout<<"zy:"<<zy[zyi]<<endl;
      zyi++;
    }
    //cout<<"sddsdssdsdsdsds:"<<c<<endl;
    sumresult.append(to_string(resultcount));
    mysql_free_result(res);
    FreeConnect();
    gettimeofday(&endtime,NULL);
    time1=1000000 * (endtime.tv_sec -starttime.tv_sec) + endtime.tv_usec - starttime.tv_usec;
    time1/=1000000;
    //cout<<"time1:"<<time1<<endl;
    servertime+=time1;
    reply->set_message(sumresult);
    //cout<<"成功结束方法一！！！"<<endl;
    return Status::OK;
  }

  Status SayHello1(ServerContext* context, const HelloRequest* request,
                  HelloReply* reply) override {
    // Overwrite the call's compression algorithm to DEFLATE.
    //leny
    //初始化bloom
    double time2=0;
    struct timeval starttime;
    struct timeval endtime;
    
    indexresult="";
    zindex++;
    context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
    string xtoken=request->name();
    gettimeofday(&starttime,NULL);

    list<string> xtokenlist;
    list<string>::iterator xtokenlistitor;
    StringSplit(xtoken,",",xtokenlist);
    //搜索关键字减一
    int xtokenlen=xtokenlist.size();
    //cout<<"kkkkkkkkkkkkkkkkkkkkkkkkkkk:"<<localresult<<endl;


    ZZ tx[resultcount];
    int index=0;
    for(xtokenlistitor=xtokenlist.begin();xtokenlistitor!=xtokenlist.end();xtokenlistitor++){
      string enxtoken=*xtokenlistitor;
      string dextoken=base64_decode(enxtoken);
      //cout<<"dextoken.length():"<<dextoken.length()<<endl;
      tx[index]=ZZFromBytes((uint8_t*)dextoken.data(),dextoken.length());

      index++;
    }
    ZZ g,p,q;
    ZZ_from_char(g,ag);
    ZZ_from_char(p,ap);
    ZZ_from_char(q,aq);
    int result[resultcount];
    for(int i=0;i<resultcount;i++){
      result[i]=1;
    }
    //获取位置
    list<long> indexlist;
    list<long>::iterator indexlistitor;
    for(int i=0;i<xtokenlen;i++){
        //cout<<"tx[i][j]:"<<tx[i][j]<<endl;
        //形成正确的ZZ类型的tx[i][j]
        ZZ tmpresult=PowerMod(tx[i],zy[zindex],p);
        int tmpresultlen=NumBytes(tmpresult);
        uint8_t *search=new uint8_t[tmpresultlen];
        BytesFromZZ(search,tmpresult,tmpresultlen);
        //cout<<"结果:"<<tmpresult<<endl;
        //phex(search);     
        query_index(search,tmpresultlen,&sbf,indexlist);
        delete[] search;
      
    }
    
    for(indexlistitor=indexlist.begin();indexlistitor!=indexlist.end();indexlistitor++){
      indexresult.append(to_string(*indexlistitor)).append(",");
    }
    gettimeofday(&endtime,NULL);
    time2=1000000 * (endtime.tv_sec -starttime.tv_sec) + endtime.tv_usec - starttime.tv_usec;
    time2/=1000000;
    //cout<<"time2:"<<time2<<endl;
    servertime+=time2;
    //cout<<indexresult<<endl;
    reply->set_message(indexresult);
    return Status::OK;
  }

  Status SayHello2(ServerContext* context, const HelloRequest* request,
                  HelloReply* reply) override {
    double time3=0;
    struct timeval starttime;
    struct timeval endtime;
    

    int i,j;
    int kwlen;
    long xlen, qbytes;

    char querybloom1sql[150];

    uint8_t tmp[32];
    uint8_t ke[16];
    uint8_t kl[16];
    uint8_t plain_id[16];
    uint8_t l[16];
    uint8_t data[64];
    uint8_t intb[4];
    uint8_t indexvaluesearchbyte[8];
    uint8_t realvaluebyte[4];
    uint8_t idindex[16];
    uint8_t k[16];
    ZZ xind,z,y,kxw;
    struct AES_ctx ctx;


    // Overwrite the call's compression algorithm to DEFLATE.
    context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
    //接受来自客户端的的hash计算结果
    
    std::string clientresult=request->name();
    gettimeofday(&starttime,NULL);
    unsigned int clienthash=atoi(clientresult.data());

    //获取定义为全局变量的一个id对应的所有的索引位置
    //分割后成功驱动所有的int索引位置
    list<int> indexlist;
    list<int>::iterator indexlistitor;
    //分割后的string类型索引位置
    list<string> indexstringlist;
    list<string>::iterator indexstringlistitor;
    StringSplit(indexresult,",",indexstringlist);
    //记录从服务器查询到的所有的bloomc
    string serverbf="";
    for(indexstringlistitor=indexstringlist.begin();indexstringlistitor!=indexstringlist.end();indexstringlistitor++){
      string tmpindexstr=*indexstringlistitor;
      long long tmp=atoll(tmpindexstr.data());
      //cout<<tmp<<endl;
      unsigned int queryresult= query1_set(tmp,&sbf);
      serverbf.append(to_string(queryresult));
    }
    //cout<<"serverstr："<<serverbf<<endl;
    unsigned int serverhash=DJBHash(serverbf.data());
    
    string returnresult="";
    if(clienthash==serverhash){
      returnresult.append(ene[zindex]);
    }
    gettimeofday(&endtime,NULL);
    time3=1000000 * (endtime.tv_sec -starttime.tv_sec) + endtime.tv_usec - starttime.tv_usec;
    time3/=1000000;
    //cout<<"time3:"<<time3<<endl;
    servertime+=time3;
    cout<<"服务器时间："<<servertime<<endl;
    reply->set_message(returnresult);
    return Status::OK;
  }
  Status SayHello3(ServerContext* context, const HelloRequest* request,
                  HelloReply* reply) override {
    // Overwrite the call's compression algorithm to DEFLATE.
    context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
    cout<<"servertime:"<<servertime<<endl;
    delete[] ene;
    delete[] eny;
    delete[] dee;
    delete[] dey;
    delete[] ylenarr;
    delete[] zy;
    std::string prefix("，已执行delete操作！！！！");
    reply->set_message(prefix);
    return Status::OK;
  }
};

// class GreeterServiceImpl final : public Greeter::Service1 {
//   Status SayHello(ServerContext* context, const HelloRequest* request,
//                   HelloReply* reply) override {
//     // Overwrite the call's compression algorithm to DEFLATE.
//     context->set_compression_algorithm(GRPC_COMPRESS_DEFLATE);
//     std::string prefix("Hello ");
//     reply->set_message(prefix + request->name());
//     return Status::OK;
//   }
// };

void RunServer() {
  std::string server_address("0.0.0.0:50051");
  GreeterServiceImpl service;

  ServerBuilder builder;
  // Set the default compression algorithm for the server.
  builder.SetDefaultCompressionAlgorithm(GRPC_COMPRESS_GZIP);
  // Listen on the given address without any authentication mechanism.
  builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
  // Register "service" as the instance through which we'll communicate with
  // clients. In this case it corresponds to an *synchronous* service.
  builder.RegisterService(&service);
  // Finally assemble the server.
  std::unique_ptr<Server> server(builder.BuildAndStart());
  std::cout << "Server listening on " << server_address << std::endl;

  // Wait for the server to shutdown. Note that some other thread must be
  // responsible for shutting down the server for this call to ever return.
  server->Wait();
}

int main(int argc, char** argv) {
  ConnectDatabase();
  int intarrlen;
  init_set(&sbf,219249934,NUM_OF_HASH,intarrlen);
  char sql[150];
  list<unsigned int> uintlist;
  list<unsigned int>::iterator uintitor;
  sprintf(sql,"select * from phxtbloom");
  QueryBloom(sql,uintlist);
  cout<<"查询长度："<<uintlist.size();
  int i=0;
  for(uintitor=uintlist.begin();uintitor!=uintlist.end();uintitor++){
    sbf.pbf->bf_array[i]=*uintitor;
    //cout<<sbf.pbf->bf_array[i]<<endl;
    i++;
  }
  RunServer();
  
  return 0;
}
