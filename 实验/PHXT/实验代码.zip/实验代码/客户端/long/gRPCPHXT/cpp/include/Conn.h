#ifndef Conn_H_INCLUDED
#define Conn_H_INCLUDED
#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<list>
#include<string>
#include<map>
#include<mysql/mysql.h>
using namespace std;
// bool ConnectDatabase();
// void FreeConnect();
// void Querykeyword(char * sql,list<char *> &listkeyword);
// void Queryid(char * word,list<int> &listofid);
// bool insertbloom(const char *sql);
// bool InsertData(const char*);
// long QueryCount();
// void Queryeninverted(const char * charl,string &e,string &y,int &ylen,int &count);
// list<unsigned int> QueryBloom(char* sql);


MYSQL mysql;
MYSQL_FIELD *fd; 
char field[32][32];
MYSQL_RES *res;
MYSQL_RES *mainres;
MYSQL_RES *oxtres;
MYSQL_ROW column;
char query[2000];

bool ConnectDatabase() {
	mysql_init( &mysql );//对数据句柄进行初始化
	
    if(mysql_real_connect(&mysql,"localhost","root","123456","bigdata",3306,NULL,0)){
        printf("成功链接数据库！！！！");
        return true;
    }else {
		printf("Error connecting to database:%s\n", mysql_error(&mysql));
		return false;
	}
	
}

void FreeConnect() {
	cout<<"清空mysql"<<endl;
	
	mysql_close(&mysql);
	mysql_library_end();
}

bool insertbloom(const char *sql){
	int result=mysql_query(&mysql, sql);
	//cout<<"result:"<<result<<endl;
	if(result!=0){
		return false;
	}
	return true;
}

void Querykeyword(char *sql,list<char *> &listkeyword){

	//strcpy(query,"select * from positive limit "+m+","+n);
	mysql_query(&mysql, "set names utf8");
	if (mysql_query(&mysql, sql)) {
		printf("Query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("query success\n");
	}
	mainres = mysql_store_result(&mysql);
	if (!mainres) {
		printf("Couldn't get result from %s\n", mysql_error(&mysql));
	}
	while (column = mysql_fetch_row(mainres)) {
		listkeyword.push_back(column[0]);
	}
}

void Queryid(char * word,list<int> &listofid){
	sprintf(query,"select id from mediumpositive where keyword='%s';",word);
	cout<<query<<endl;
	//strcpy(query,"select * from positive limit "+m+","+n);
	mysql_query(&mysql, "set names utf8");
	if (mysql_query(&mysql, query)) {
		printf("Query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("query success\n");
	}

	oxtres = mysql_store_result(&mysql);
	if (!oxtres) {
		printf("Couldn't get result from %s\n", mysql_error(&mysql));
	}

	while (column = mysql_fetch_row(oxtres)) {
		listofid.push_back(atoi(column[0]));
	}
}

//将加密好的倒排表插入到数据库
bool InsertData(const char *sql){
	cout<<"sql:"<<sql<<endl;
	int result=mysql_query(&mysql, sql);
	//free(sql);
	//cout<<"result:"<<result<<endl;
	if(result!=0){
		return false;
	}
	return true;
}

//查询倒排表的总记录数量
long QueryCount(){
	long count;
	sprintf(query,"select id from mediumpositive");
	mysql_query(&mysql, "set names utf8");
	if (mysql_query(&mysql, query)) {
		printf("Query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("query success\n");
	}

	res = mysql_store_result(&mysql);
	count=mysql_num_rows(res);
	return count;
}

//省内存方式查询数据库表的记录数
long QueryRowCount(){
	long count;
	sprintf(query,"select count(id) from mediumpositive");
	mysql_query(&mysql, "set names utf8");
	if (mysql_query(&mysql, query)) {
		printf("Query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("query success\n");
	}

	res = mysql_store_result(&mysql);
	
	while (column = mysql_fetch_row(res)) {
		count=atoi(column[0]);
	}
	return count;
}

//查询字典
// void Queryeninverted(const char * charl,string &e,string &y,int &ylen,int &count){

// 	sprintf(query,"select * from eninverted where l='%s'",charl);
// 	//strcpy(query,"select * from positive limit "+m+","+n);
// 	mysql_query(&mysql, "set names utf8");
// 	if (mysql_query(&mysql, query)) {
// 		printf("Query failed (%s)\n", mysql_error(&mysql));
// 	}
// 	else {
// 		//printf("query success\n");
// 	}

// 	res = mysql_store_result(&mysql);
// 	if (!res) {
// 		printf("Couldn't get result from %s\n", mysql_error(&mysql));
// 	}
// 	count=mysql_num_rows(res);
// 	while (column = mysql_fetch_row(res)) {
// 		e=column[1];
// 		y=column[2];
// 		ylen=atoi(column[3]);
// 	}

// }
void Queryeninverted(const char * charl,string &e,int &count){

	sprintf(query,"select * from groupeninverted where l='%s'",charl);
	//strcpy(query,"select * from positive limit "+m+","+n);
	mysql_query(&mysql, "set names utf8");
	if (mysql_query(&mysql, query)) {
		printf("Query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		//printf("query success\n");
	}

	res = mysql_store_result(&mysql);
	if (!res) {
		printf("Couldn't get result from %s\n", mysql_error(&mysql));
	}
	count=mysql_num_rows(res);
	while (column = mysql_fetch_row(res)) {
		e=column[1];
	}

}


//查询bloom过滤器的值
void QueryBloom(char* sql,list<unsigned int> &listbloom){

	mysql_query(&mysql, "set names utf8");
	if (mysql_query(&mysql, sql)) {
		printf("Query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("query success\n");
	}

	res = mysql_store_result(&mysql);
	if (!res) {
		printf("Couldn't get result from %s\n", mysql_error(&mysql));
	}
	unsigned int u;
	
	while (column = mysql_fetch_row(res)) {
		u = strtoul(column[0], NULL, 10);
		listbloom.push_back(u);
	}
}

//查询布隆过滤器加密后的c
void Querybloomc(const char * charl,string &strbloomc){

	//strcpy(query,"select * from positive limit "+m+","+n);
	mysql_query(&mysql, "set names utf8");
	if (mysql_query(&mysql, charl)) {
		printf("Query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		//printf("query success\n");
	}

	res = mysql_store_result(&mysql);
	if (!res) {
		printf("Couldn't get result from %s\n", mysql_error(&mysql));
	}
	while (column = mysql_fetch_row(res)) {
		strbloomc=column[0];
	}

}

#endif