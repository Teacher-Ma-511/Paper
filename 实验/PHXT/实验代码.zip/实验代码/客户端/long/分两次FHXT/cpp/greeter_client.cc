/*
 *
 * Copyright 2018 gRPC authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <iostream>
#include <memory>
#include <string>
#include<list>
#include<stdlib.h>
#include<sys/time.h>
#include<NTL/ZZ.h>
#include <grpcpp/grpcpp.h>

#ifdef BAZEL_BUILD
#include "examples/protos/helloworld.grpc.pb.h"
#else
#include "helloworld.grpc.pb.h"
#endif
#include"include/aes.h"
#include"include/bf.h"
#include"include/fhxt.h"
#include"include/Conn.h"
#include"include/tools.h"
using grpc::Channel;
using grpc::ChannelArguments;
using grpc::ClientContext;
using grpc::Status;
using helloworld::HelloRequest; 
using helloworld::HelloReply;
using helloworld::Greeter;
using namespace std;
//using namespace std;

struct set_bf sbf;
class GreeterClient {
 public:
  GreeterClient(std::shared_ptr<Channel> channel)
      : stub_(Greeter::NewStub(channel)) {}

  // Assembles the client's payload, sends it and presents the response back
  // from the server.
  std::string SayHello(const std::string& user) {
    // Data we are sending to the server.
    HelloRequest request;
    request.set_name(user);

    // Container for the data we expect from the server.
    HelloReply reply;

    // Context for the client. It could be used to convey extra information to
    // the server and/or tweak certain RPC behaviors.
    ClientContext context;

    // Overwrite the call's compression algorithm to DEFLATE.
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    // The actual RPC.
    Status status = stub_->SayHello(&context, request, &reply);

    // Act upon its status.
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }


  std::string SayHello1(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello1(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

  std::string SayHello2(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello2(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

  std::string SayHello3(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello3(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

 private:
  std::unique_ptr<Greeter::Stub> stub_;
};

int main(int argc, char** argv) {

  double servertime=0;
  double clienttime=0;

  struct timeval start;
	struct timeval end;

  struct timeval start1;
	struct timeval end1;

  int i,j;
  int kwlen;
  long xlen, qbytes;

  char querybloom1sql[150];

  uint8_t tmp[32];
  uint8_t ke[16];
  uint8_t kl[16];
  uint8_t plain_id[16];
  uint8_t l[16];
  uint8_t data[64];
  uint8_t intb[4];
  uint8_t indexvaluesearchbyte[8];
  uint8_t realvaluebyte[4];
  uint8_t idindex[16];
  //记录客户端计算的全为1的异或结果
  uint8_t resultvalue[16];
  uint8_t k[16];
  uint8_t d1[16];
  uint8_t additition[16];
  ZZ xind,z,y,kxw,xtag;
  struct AES_ctx ctx;
  struct AES_ctx ctx1;
  struct AES_ctx ctx2;
  
  phxt_param_ptr phxt;
  
  ZZ g,p,q;
  ZZ_from_char(g,ag);
  ZZ_from_char(p,ap);
  ZZ_from_char(q,aq);
  phxt_param soxt={g,q,p,aks,akx,aki,akz,QLEN,PLEN,16, 16,16, 16, ID_LEN_IN_BYTE};
  phxt=&soxt;
  int intarrlen;
  init_set(&sbf,219249934,NUM_OF_HASH,intarrlen);
  char sql[150];
  qbytes=NumBytes(phxt->q);

  //统计查询的id个数
  int idsum=0;
  ChannelArguments args;
  // Set the default compression algorithm for the channel.
  args.SetCompressionAlgorithm(GRPC_COMPRESS_GZIP);
  GreeterClient greeter(grpc::CreateCustomChannel(
      "localhost:50051", grpc::InsecureChannelCredentials(), args));
  cout<<"请输入要查询的关键字"<<endl;
  list<char *> searchword;
  list<char *>::iterator itor;
  for(int i=0;i<2;i++){
    char *word=new char[100];
    cin>>word;
    searchword.push_back(word);
  }
  gettimeofday(&start,NULL);
  gettimeofday(&start1,NULL);
  uint8_t *keyword=(uint8_t*)searchword.front();
    //Todo:获取关键词pkeywords[i]的byte长度
  kwlen=strlen(searchword.front());//获得关键字的长度
    //cout<<tokens.front()<<endl;
  cat_uint(data,phxt->Ks,keyword,phxt->kslen,kwlen);//data=Ks||kw1
  DeriveKey(tmp,32,data,phxt->kslen+kwlen);
  for(j=0;j<16;j++)
  {
      ke[j]=tmp[j];//ke to encrypt the document id
      kl[j]=tmp[j+16];//kl to generate the dictionary index
  }
  string stagstring=base64_encode(tmp,32);
  gettimeofday(&end1,NULL);
  double clienttime1=1000000 * (end1.tv_sec -start1.tv_sec) + end1.tv_usec - start1.tv_usec;
  clienttime1/=1000000;
  //cout<<stagstring<<endl;
  //将产生的stag发送给服务器
  std::string reply = greeter.SayHello(stagstring);
  std::string reply1 = greeter.SayHello1("");
  reply.append(",").append(reply1);
  //这里是返回对应产生的所有的索引地址
  list<string> enelist;
  list<string>::iterator enelistitor;
  StringSplit(reply,",",enelist);
  int frcount=enelist.size();
  string *dee=new string[frcount];
  cout<<"frcount："<<frcount<<endl;
  int enelistcount=0;
  for(enelistitor=enelist.begin();enelistitor!=enelist.end();enelistitor++){
    string ene=*enelistitor;
    dee[enelistcount]=base64_decode(ene);
    enelistcount++;
  }
  cout<<"enelistcount："<<enelistcount<<endl;
  //计算通讯成本：
  // long clientlen=0;
  // long serverlen=0;

  // clientlen=clientlen+stagstring.length()+1;
  // serverlen=serverlen+reply.length()+1;

  
  int icount=0;
  int c1;
  //构建xtoken
  int *idarr=new int[frcount];
  int resultcountindex=0;
  double clienttime2=0;

  for (int i=0;i<frcount;i++)//循环w1查询到的id个数
  {
      struct timeval start2;
      struct timeval end2;

      struct timeval start3;
      struct timeval end3;

      struct timeval start4;
      struct timeval end4;
      gettimeofday(&start2,NULL);
      AES_init_ctx(&ctx, ke);
      uint8_t *uchare=(uint8_t*)dee[resultcountindex].data();
      AES_ECB_decrypt(&ctx, uchare);
      uint8_t *charid=new uint8_t[4];
      for(int j=12;j<16;j++){
        charid[j-12]=uchare[j];
      }
      int id=(int)charid[0]+((int)charid[1]*256)+((int)charid[2]*256*256)+((int)charid[3]*256*256*256);
      //cout<<"id："<<id<<endl;
      idarr[resultcountindex]=id;
      list<long> indexlist;
      list<long>::iterator indexitor;
      int_to_uint8(id,intb);
      string finxtoken="";
      int icount=0;
      for(itor=searchword.begin();itor!=searchword.end();itor++){
        icount++;
        //cout<<"进入2"<<endl;
        if(icount!=1){
          //uint8_t *bkeyword=(uint8_t*)*itor;
          int bkwlen=strlen(*itor);
          cat_uint(data,(uint8_t*)*itor,intb,bkwlen,4);
          oxt_prf(xtag,phxt->Kx,data,phxt->kxlen,bkwlen+4,phxt->q,qbytes);
          int xlen=NumBytes(xtag);
          BytesFromZZ(tmp,xtag,xlen);
          //query_index(tmp,xlen,&sbf,indexlist);
          string xtokenstring=base64_encode(tmp,xlen);
          finxtoken.append(xtokenstring).append(",");
        }
      }
      
      gettimeofday(&end2,NULL);
      double fortime=1000000 * (end2.tv_sec -start2.tv_sec) + end2.tv_usec - start2.tv_usec;
      fortime/=1000000;
      clienttime2+=fortime;
      std::string serverreply = greeter.SayHello2(finxtoken);

      gettimeofday(&start3,NULL);
      string clientebf="";
      //服务器计算的hash值
      string serverhashstr;
      int serveri=0;
      list<string> serverresult;
      list<string>::iterator serverresultitor;
      StringSplit(serverreply,",",serverresult);
      for(serverresultitor=serverresult.begin();serverresultitor!=serverresult.end();serverresultitor++){
        if(serveri==0){
          serverhashstr=*serverresultitor;
        }
        else{
          string tmp=*serverresultitor;
          long long longtmp=atoll(tmp.data());
          indexlist.push_back(longtmp);
        }
        serveri++;
      }
      for(indexitor=indexlist.begin();indexitor!=indexlist.end();indexitor++){
        //cout<<"进入4"<<endl;
        int bitvalue,bitvalue2;
        int bitvalue1=1;
        long indexvaluesearch;
        indexvaluesearch=*indexitor;
        //cout<<"clientdizhi："<<*indexitor<<endl;
        long_to_uint8(indexvaluesearch,indexvaluesearchbyte);
        //创建出16字节的纯文本
        for(int i=0;i<8;i++){
          additition[i]=0x00;
        }
        cat_uint(additition,additition,indexvaluesearchbyte,8,8);
        AES_init_ctx(&ctx1, akz);
        AES_ECB_encrypt(&ctx1,additition);
        bitvalue2=((additition[0]>>7)&1);
        bitvalue=bitvalue1^bitvalue2;
        clientebf.append(to_string(bitvalue));
          
      }//end
      //clientlen=clientlen+finxtoken.length()+1;
      //cout<<"clientstr："<<clientebf<<endl;
      unsigned int clienthash=DJBHash(clientebf.data());
      //serverlen=serverlen+serverhashstr.length()+1;
      unsigned int serverhash=atoi(serverhashstr.data());
      if(clienthash==serverhash){
        //cout<<id<<endl;
        idsum++;
      }
      resultcountindex++;
      gettimeofday(&end3,NULL);
      double fortime1=1000000 * (end3.tv_sec -start3.tv_sec) + end3.tv_usec - start3.tv_usec;
      fortime1/=1000000;
      clienttime2+=fortime1;
    }
  gettimeofday(&end,NULL);
  double sumtime=1000000 * (end.tv_sec -start.tv_sec) + end.tv_usec - start.tv_usec;
  sumtime/=1000000;
  clienttime=clienttime1+clienttime2;
  cout<<"查询结果集："<<idsum<<endl;
  cout<<"客户端时间："<<clienttime<<endl;
  cout<<"总时间："<<sumtime<<endl;
  string deletestr= greeter.SayHello3("请求清除数组");
  cout<<deletestr<<endl;
  //cout<<"通讯成本："<<(double)(clientlen+serverlen)/1024/1024<<endl;
  return 0;
}
