#include<iostream>
#include<list>
#include<string>
//#include"include/tools.h"
using namespace std;
void Split(const string& str,const string& splitstr,list<string>& splitresult){
    size_t iLast=0;
    size_t iIndex=0;
    iIndex=str.find_first_of(splitstr,iLast);

    while(iIndex!=string::npos){
        string tmp=str.substr(iLast,iIndex-iLast);
        if(!tmp.empty()){
            splitresult.push_back(tmp);
        }
        iLast=iIndex+1;
        iIndex=str.find_first_of(splitstr,iLast);
    }
    //
    iIndex=str.length();
    if(iIndex>iLast){
        string tmp=str.substr(iLast,iIndex-iLast);
        if(!tmp.empty()){
            splitresult.push_back(tmp);
        }
    }
}
int main(){
    string str="A={13,24,35},B={46,75,68},R=3";
    list<string> liststr;
    list<string>::iterator itor;
    Split(str,"A={},BR",liststr);//注意参数问题，这里分割函数的前两个函数应该定义为const
    int A[3],B[3];
    int index=0;
    int c;
    for(itor=liststr.begin();itor!=liststr.end();itor++){
        string tmpstr=*itor;
        if(index==6){
            c=atoi(tmpstr.data());
            break;
        }
        if(index<3){
            A[index]=atoi(tmpstr.data());
            
        }else{
            B[index%3]=atoi(tmpstr.data());
        }
        index++;
    }
    for(int i=0;i<3;i++){
        cout<<A[i]<<endl;
    }
    for(int i=0;i<3;i++){
        cout<<B[i]<<endl;
    }
    cout<<c<<endl;
}