#ifndef OXT_H_INCLUDED
#define OXT_H_INCLUDED

#include <stdio.h>
#include <iostream>
#include <stdlib.h> 
#include<fstream>
#include<list>
#include<mysql/mysql.h>
#include <NTL/ZZ.h>
#include"Conn.h"
#include "bf.h"
#include "aes.h"

using namespace std;
using namespace NTL;

const char* ag = "12293041548191560959252997681221893073091763148392091587781229526780505319280253304158657014186812803260820624200425866044892534107445664741934978636107726042273789227287786063826002069319009175216162933494359277792631586799194401273339746711856497988529049521334761338869458014310995080149317625448851976250\n";

const char* ap = "35846489658960820960446633115143023883040757131525173446156521584352743991679231122673876526186909574940183912868842246185467405988094236483899550393037943055836758636212712380713704715884242930459327176061234383344181152578596944695560082751184202851538548055157781713238676762830736663499575834426106137609\n";

const char* aq = "91677580900928952829845059692479440057913422538304665006082987855400898556463\n";

uint8_t aks[] = { 0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c };

uint8_t akx[] = { 0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81 };

uint8_t aki[] = { 0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4 };

uint8_t akz[] = { 0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5 };

#define QLEN 256
#define PLEN 1024
#define PRF_KEY_LEN 128
#define AES_KEY_LEN 128
#define ID_LEN_IN_BYTE 4

struct oxt
{
    ZZ g;
    ZZ q;
    ZZ p;

    uint8_t* Ks;
    uint8_t* Kx;
    uint8_t* Ki;
    uint8_t* Kz;

    long qlen;
    long plen;

    int kslen;
    int kxlen;
    int kilen;
    int kzlen;
    int idlen;
};

typedef struct oxt   oxt_param;
typedef struct oxt*  oxt_param_ptr;

static void init_oxt(oxt_param_ptr poxt, const char* cg, const char* cq, uint8_t* ks, uint8_t* kx, uint8_t* ki, uint8_t* kz,
                        long qlen, const char* cp, long plen, int kslen, int kxlen, int kilen, int kzlen, int indlen);
static void oxt_y(ZZ& y, ZZ& xind, ZZ& z, oxt_param_ptr poxt);
static void oxt_xtoken(ZZ& xtoken, ZZ& kzw, ZZ& kxw, oxt_param_ptr poxt);
static void oxt_xtag(ZZ& xtag, ZZ& kxw, ZZ& xind, oxt_param_ptr poxt);
static void oxt_create_EDB(oxt_param_ptr poxt,list<char *> keywords,long sizeofdb,struct set_bf &sbf);
static void oxt_query(oxt_param_ptr poxt,list<char *> tokens,long sizeofdb,struct set_bf &sbf);

static void oxt_prf(ZZ& r, uint8_t* key, uint8_t* data, int klen, int dlen, oxt_param_ptr poxt, long nlen);

static void ZZ_from_char(ZZ& z, const char* ctr);

static void int_to_uint8(int source, uint8_t* dest);

static void cat_uint(uint8_t* dest, uint8_t* str1, uint8_t* str2, int len1, int len2);

void generate_ddh_parameters(ZZ& g, ZZ& q, ZZ& p, long qlen, long plen);


void KeyGen(uint8_t *&key);
string base64_encode(unsigned char const* , unsigned int len);
string base64_decode(std::string const& s);
void getlinetxt(list<string> &list);
void writeLog(string data);

ofstream outfile;
ifstream infile;
void writeLog(string data)
{
	outfile.open("/home/lihongfei/code/Test/myfile", ios::app);
	if (!outfile) //检查文件是否正常打开//不是用于检查文件是否存在
	{
		cout << "abc.txt can't open" << endl;
		abort(); //打开失败，结束程序
	}
	else
	{
		outfile <<data<<endl;
		outfile.close();
	}
}

void getlinetxt(list<string> &list) {
	infile.open("/home/lihongfei/code/Test/myfile");
	if (infile) {
		string strLine;
    int i=0;
		while (getline(infile, strLine)) // line中不包括每行的换行符 
		{
      list.push_back(strLine);
		}
	}

}

string * getlinetxtarr() {
	infile.open("/home/lihongfei/code/Test/myfile");
  string *strarr=new string[4];
	if (infile) {
		string strLine;
    int i=0;
		while (getline(infile, strLine)) // line中不包括每行的换行符 
		{
      strarr[i]=strLine;
      i++;
		}
	}
  return strarr;

}

static void phex(uint8_t* str)
{

#if defined(AES256)
    uint8_t len = 32;
#elif defined(AES192)
    uint8_t len = 24;
#elif defined(AES128)
    uint8_t len = 16;
#endif

    unsigned char i;
    for (i = 0; i < len; ++i)
        printf("%.2x", str[i]);
    printf("\n");
}

// void KeyGen(uint8_t *&key){
// 	//生成最终需要的密钥
//      long len=128;
//     NTL::ZZ pass=RandomBits_ZZ(len);
//     key=new uint8_t[128];
//     uint8_t *key1=new uint8_t[128];
//     long len1=NumBytes(pass);
//     BytesFromZZ(key1,pass,len1);
//     long klen=strlen((char *)key1);
//     DeriveKey(key,16,key1,klen);
// }

static const std::string base64_chars = 
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789+/";
 

static inline bool is_base64(unsigned char c) {
  return (isalnum(c) || (c == '+') || (c == '/'));
}
 
std::string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len) {
  std::string ret;
  int i = 0;
  int j = 0;
  unsigned char char_array_3[3];
  unsigned char char_array_4[4];
 
  while (in_len--) {
    char_array_3[i++] = *(bytes_to_encode++);
    if (i == 3) {
      char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
      char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
      char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
      char_array_4[3] = char_array_3[2] & 0x3f;
 
      for(i = 0; (i <4) ; i++)
        ret += base64_chars[char_array_4[i]];
      i = 0;
    }
  }
 
  if (i)
  {
    for(j = i; j < 3; j++)
      char_array_3[j] = '\0';
 
    char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
    char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
    char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
    char_array_4[3] = char_array_3[2] & 0x3f;
 
    for (j = 0; (j < i + 1); j++)
      ret += base64_chars[char_array_4[j]];
 
    while((i++ < 3))
      ret += '=';
 
  }
 
  return ret;
 
}
 
std::string base64_decode(std::string const& encoded_string) {
  int in_len = encoded_string.size();
  int i = 0;
  int j = 0;
  int in_ = 0;
  unsigned char char_array_4[4], char_array_3[3];
  std::string ret;
 
  while (in_len-- && ( encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
    char_array_4[i++] = encoded_string[in_]; in_++;
    if (i ==4) {
      for (i = 0; i <4; i++)
        char_array_4[i] = base64_chars.find(char_array_4[i]);
 
      char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
      char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
      char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];
 
      for (i = 0; (i < 3); i++)
        ret += char_array_3[i];
      i = 0;
    }
  }
 
  if (i) {
    for (j = i; j <4; j++)
      char_array_4[j] = 0;
 
    for (j = 0; j <4; j++)
      char_array_4[j] = base64_chars.find(char_array_4[j]);
 
    char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
    char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
    char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];
 
    for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
  }
 
  return ret;
}

string numberToString(ZZ num)
{
    long len = ceil(log(num)/log(128));
    char str[len];
    for(long i = len-1; i >= 0; i--)
    {
        str[i] = conv<int>(num % 128);
        num /= 128;
    }

    return (string) str;
}


ZZ stringToNumber(string str)
{
    ZZ number = conv<ZZ>(str[0]);
    long len = str.length();
    for(long i = 1; i < len; i++)
    {
        number *= 128;
        number += conv<ZZ>(str[i]);
    }

    return number;
}

static void ZZ_from_char(ZZ& z, const char* ctr)
{
	long i,j;
	ZZ temp1,temp2;

	i=0;
	j=0;
	z=0;
	temp1=0;
	temp2=0;
	while(ctr[i]!='\n')
	{
		i++;j++;
	}
	i=i-1;
	j=i;
	while(i>-1)
	{
		power(temp1,10,j-i);
		switch(ctr[i])
		{
			case '0': temp2=0; break;
			case '1': temp2=1; break;
			case '2': temp2=2; break;
			case '3': temp2=3; break;
			case '4': temp2=4; break;
			case '5': temp2=5; break;
			case '6': temp2=6; break;
			case '7': temp2=7; break;
			case '8': temp2=8; break;
			case '9': temp2=9; break;
			default: cout<<"initialize big integer errors"; return;

		}
		temp2=temp2 * temp1;
		z = z + temp2;
		i--;
	}
}

static void int_to_uint8(int source, uint8_t* dest)
{
    dest[0]= (source & 0xff);
    dest[1]= (source>>8 & 0xff);
    dest[2]= (source>>16 & 0xff);
    dest[3]= (source>>24 & 0xff);
}
static void long_to_uint8(long source, uint8_t* dest)
{
    dest[0]= (source & 0xff);
    dest[1]= (source>>8 & 0xff);
    dest[2]= (source>>16 & 0xff);
    dest[3]= (source>>24 & 0xff);
    dest[4]= (source>>32 & 0xff);
    dest[5]= (source>>40 & 0xff);
    dest[6]= (source>>48 & 0xff);
    dest[7]= (source>>56 & 0xff);
}

void generate_oxt_parameters(ZZ& g, ZZ& q, ZZ& p, long qlen, long plen)
{
    ZZ h,temp,temp2;
    long i,isprime=0;
	i=0;
    GenPrime(q,qlen);
    while(isprime==0){
        RandomBits(temp,plen-qlen);
        p=temp*q+1;
        isprime=ProbPrime(p);
	i++;
    }
	cout<<"the num of try="<<i<<endl;
    RandomBits(h,qlen);
	temp2=PowerMod(h,p-1,p);
	cout<<"h^p-1="<<temp2<<endl;
	temp2=temp*q+1;
	cout<<"temp*q+1="<<temp2<<endl;

    g=PowerMod(h,temp,p);
	temp2=PowerMod(g,q,p);
	cout<<"g^q="<<temp2<<endl;

    cout<<"g="<<endl<<g<<endl<<endl;
    cout<<"p="<<endl<<p<<endl<<endl<<"q="<<endl<<q<<endl;


}


static void init_oxt(oxt_param_ptr poxt, const char* cg, const char* cq, uint8_t* ks, uint8_t* kx, uint8_t* ki, uint8_t* kz,
                                long qlen, const char* cp, long plen, int kslen, int kxlen, int kilen, int kzlen, int indlen)
{
    ZZ g,p,q;

	ZZ_from_char(g,cg);
	ZZ_from_char(q,cq);
	ZZ_from_char(p,cp);

    poxt->g=g;
    poxt->q=q;
    poxt->p=p;
    poxt->qlen=qlen;
    poxt->plen=plen;
    poxt->Ks=ks;
    poxt->Kx=kx;
    poxt->Ki=ki;
    poxt->Kz=kz;
    poxt->kslen=kslen;
    poxt->kxlen=kxlen;
    poxt->kilen=kilen;
    poxt->kzlen=kzlen;
    poxt->idlen=indlen;
}

static void oxt_y(ZZ& y, ZZ& xind, ZZ& z, oxt_param_ptr poxt)
{
    ZZ tmp;
    tmp=InvMod(z,poxt->q);
    y=MulMod(xind,tmp,poxt->q);
    tmp.kill();
}

static void oxt_xtoken(ZZ& xtoken, ZZ& kzw, ZZ& kxw, oxt_param_ptr poxt)
{
    ZZ tmp;
    tmp=MulMod(kzw,kxw,poxt->q);
    xtoken=PowerMod(poxt->g%poxt->p,tmp,poxt->p);
    tmp.kill();
}

static void oxt_xtag(ZZ& xtag, ZZ& kxw, ZZ& xind, oxt_param_ptr poxt)
{
    ZZ tmp;
    tmp=MulMod(xind,kxw,poxt->q);
    xtag=PowerMod(poxt->g%poxt->p,tmp,poxt->p);
    tmp.kill();
}

static void cat_uint(uint8_t* dest, uint8_t* str1, uint8_t* str2, int len1, int len2)
{
    for(int i=0;i<len1;i++){
      dest[i]=str1[i];
    }      
    for(int j=0;j<len2;j++){
      dest[j+len1]=str2[j];
    }     
}

static void oxt_prf(ZZ& r, uint8_t* key, uint8_t* data, int klen, int dlen, ZZ& n, long nlen)
{
    uint8_t* tmp;
    uint8_t* res;

    res=(uint8_t*)malloc(nlen);

    tmp=(uint8_t*)malloc(klen+dlen);

    cat_uint(tmp,key,data,klen,dlen);//tmp=key||data
    DeriveKey(res,nlen,tmp,klen+dlen);//prf:Fp(kx,w)
    ZZFromBytes(r,res,nlen);
    rem(r,r,n);

    free(tmp);
    free(res);

}
static int tempcount=0;
static void oxt_create_EDB(oxt_param_ptr poxt,list<char *> keywords,long sizeofdb,struct set_bf &sbf)
{
    int i,j,c;
    int kwlen;
    long xlen, qbytes;

    uint8_t tmp[32];
    uint8_t ke[16];
    uint8_t kl[16];
    uint8_t plain_id[16];
    uint8_t l[16];
    uint8_t data[1200];
    uint8_t intbytes[4];
    uint8_t idbytes[4];
    int insertcount;
    for(i=0;i<12;i++)
        plain_id[i]=0x00;//id为int型，只有4个bytes给id的高位进行填充12个bytes以便达到16个bytes，满足aes加密要求
    ZZ xind,z,y,kxw,xtag;
    struct AES_ctx ctx;

    qbytes=NumBytes(poxt->q);
    list<char *>::iterator itor;
    string strinsertsql="insert into eninverted values";
    for (itor=keywords.begin();itor!=keywords.end();itor++)
    {
        c=0;
        kwlen=strlen(*itor);//获得关键字的长度
        //uint8_t *keyword=(uint8_t*)*itor;
        cout<<"关键字处理到："<<*itor<<endl;
        cat_uint(data,poxt->Ks,(uint8_t*)*itor,poxt->kslen,kwlen);//data=Ks||kw[i]
        uint8_t *ldata=(uint8_t*)malloc(poxt->kslen+kwlen);
        
        for(int i=0;i<poxt->kslen+kwlen;i++){
            ldata[i]=data[i];
        }
        DeriveKey(tmp,32,ldata,poxt->kslen+kwlen);
        free(ldata);
        for(j=0;j<16;j++)
        {
            ke[j]=tmp[j];//ke to encrypt the document id
            kl[j]=tmp[j+16];//kl to generate the dictionary index
        }
        oxt_prf(kxw,poxt->Kx,(uint8_t*)*itor,poxt->kxlen,kwlen,poxt->q,qbytes);

        //第i个keyword对应的文档个数,可以从数据库中读取
        list<int> listofid;
 
        Queryid(*itor,listofid);

        list<int>::iterator itorint;
        insertcount=0;
        
        for(itorint=listofid.begin();itorint!=listofid.end();itorint++)
        {   
            // tempcount++;
            // if(tempcount==200)
            // {
            //   exit(1);
            // }
            int id=*itorint;
            //计算xind
            int_to_uint8(id,intbytes);
            int clen=strlen((char*)intbytes);
            oxt_prf(xind,poxt->Ki,intbytes,poxt->kilen,clen,poxt->q,qbytes);
            //计算z
            int_to_uint8(c,intbytes);
            cat_uint(data,(uint8_t*)*itor,intbytes,kwlen,4);//data=kw||c
            uint8_t *zdata=(uint8_t*)malloc(4+kwlen);
            for(int i=0;i<4+kwlen;i++){
                zdata[i]=data[i];
            }
            oxt_prf(z,poxt->Kz,zdata,poxt->kzlen,kwlen+4,poxt->q,qbytes);
            free(zdata);
            //计算y
            oxt_y(y,xind,z,poxt);

            cout<<"y:"<<y<<endl;
            uint8_t *chary=(uint8_t*)malloc(NumBytes(y));
            BytesFromZZ(chary,y,NumBytes(y));
        
            string stry=base64_encode(chary,NumBytes(y));
            free(chary);
            //计算id对应的密文
            AES_init_ctx(&ctx, ke);
            int_to_uint8(id,idbytes);
            cat_uint(plain_id,plain_id,idbytes,12,4);//plain_id=plain_id||id[j]
            AES_ECB_encrypt(&ctx, plain_id);//e=plain_id

            cat_uint(data,kl,intbytes,16,4);
            uint8_t *kldata=(uint8_t*)malloc(20);
            for(int i=0;i<20;i++){
              kldata[i]=data[i];
            }
            DeriveKey(l,16,kldata,20);
            free(kldata);
            //计算xtag
            oxt_xtag(xtag,kxw,xind,poxt);
            xlen=NumBytes(xtag);
            cout<<xtag<<endl;
            cout<<"长度："<<xlen<<endl;
            BytesFromZZ(tmp,xtag,xlen);
            insert_set(tmp,xlen,&sbf);
            c++;
            string strid=base64_encode(plain_id,16);
            string strl=base64_encode(l,16);
            insertcount++;
            if (listofid.size()<=50000) {
              if(c==listofid.size()){
                strinsertsql.append("('").append(strl).append("','").append(strid).append("','").append(stry).append("','").append(to_string(NumBytes(y))).append("');");

                bool result=InsertData(strinsertsql.c_str());

                if(result==false){
                  cout<<"插入错误！！！"<<endl;
                  exit(1);
                }

                insertcount=0;
                strinsertsql="insert into eninverted values";
              }else
              {
                strinsertsql.append("('").append(strl).append("','").append(strid).append("','").append(stry).append("','").append(to_string(NumBytes(y))).append("'),");
              }
            }else{
              if(insertcount==50000||c==listofid.size()){
                strinsertsql.append("('").append(strl).append("','").append(strid).append("','").append(stry).append("','").append(to_string(NumBytes(y))).append("');");

                  bool result=InsertData(strinsertsql.c_str());

                  if(result==false){
                    cout<<"插入错误！！！"<<endl;
                    exit(1);
                  }

                insertcount=0;
                strinsertsql="insert into eninverted values";
              }
              else
              {
                strinsertsql.append("('").append(strl).append("','").append(strid).append("','").append(stry).append("','").append(to_string(NumBytes(y))).append("'),");
              }

              
            }
            
           
            
        }
        listofid.clear();
        mysql_free_result(oxtres);
        z.kill();
        xind.kill();
        y.kill();
        kxw.kill();
        xtag.kill();
    }
    //ToDo: 把布隆过滤器sbf存入数据库或存入文件

    
}
clock_t startTime,endTime,startTime1,endTime1,startTime2,endTime2,startTime3,endTime3;
static void oxt_query(oxt_param_ptr poxt,list<char *> tokens,long sizeofdb,struct set_bf &sbf){
    int i,j;
    int kwlen;
    long xlen, qbytes;

    uint8_t tmp[32];
    uint8_t ke[16];
    uint8_t kl[16];
    uint8_t plain_id[16];
    uint8_t l[16];
    uint8_t data[64];
    uint8_t intb[4];

    ZZ xind,z,y,kxw;
    struct AES_ctx ctx;
    
    qbytes=NumBytes(poxt->q);
    //初始化bloom里数组的值
    startTime3=clock();
    uint8_t *keyword=(uint8_t*)tokens.front();
    //Todo:获取关键词pkeywords[i]的byte长度
    kwlen=strlen(tokens.front());//获得关键字的长度
    //cout<<tokens.front()<<endl;
    cat_uint(data,poxt->Ks,keyword,poxt->kslen,kwlen);//data=Ks||kw1
    DeriveKey(tmp,32,data,poxt->kslen+kwlen);
    endTime3=clock();
    double clienttime1=(double)(endTime3 - startTime3);
    cout<<"clienttime1"<<clienttime1<<endl;
    for(j=0;j<16;j++)
    {
        ke[j]=tmp[j];//ke to encrypt the document id
        kl[j]=tmp[j+16];//kl to generate the dictionary index
    }
    int c=0;
    int rowcount;
    list<string> liste,listy;
    list<int> listylen;
    startTime=clock();
    while(true){//生成一个关键字所有的l，并且用c记录id个数
      //startTime3=clock();
      int_to_uint8(c,intb);
      cat_uint(data,kl,intb,16,4);
      DeriveKey(l,16,data,20);
      string strl=base64_encode(l,16);
      const char *charl=strl.data();  
      //endTime3=clock();
      //ltime=ltime+(double)((endTime3 - startTime3));
      string e,y;
      int ylen;
      Queryeninverted(charl,e,y,ylen,rowcount);
      if(rowcount==0){
        break;
      }
      liste.push_back(e);
      //cout<<"e"<<endl;
      listy.push_back(y);
      //cout<<"y"<<endl;
      listylen.push_back(ylen);
      c++;
    }
    endTime=clock();
    //cout << "服务器第一次的查询时间（client1和server1） : " <<(double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
    double servertime1=(double)(endTime - startTime);
    //cout<<"server1:"<<servertime1<<endl;
    //查询第一个关键字不存在
    // if(c==0){
    //   cout<<"查询结果为空，请重新输入！"<<endl;
    //   exit(1);
    // }
    string *ene=new string[c];
    string *eny=new string[c];
    string *dee=new string[c];
    string *dey=new string[c];
    int *ylenarr=new int[c];
    list<string>::iterator eitor,yitor;
    list<int>::iterator ylenitor;
    i=0;
    for(eitor=liste.begin();eitor!=liste.end();eitor++){
      ene[i]=*eitor;
      i++;
    }
    i=0;
    for(yitor=listy.begin();yitor!=listy.end();yitor++){
      eny[i]=*yitor;
      i++;
    }
    i=0;
    for(ylenitor=listylen.begin();ylenitor!=listylen.end();ylenitor++){
      ylenarr[i]=*ylenitor;
      i++;
    }
    int resultcount=c;
    // for(int i=0;i<resultcount;i++){
    //   cout<<ene[i]<<"    "<<eny[i]<<"     "<<ylenarr[i]<<endl;
    // }
    cout<<"数量："<<resultcount<<endl;
    dee=new string[resultcount];
    dey=new string[resultcount];
    for(int i=0;i<resultcount;i++){
      dee[i]=base64_decode(ene[i]);
      dey[i]=base64_decode(eny[i]);
      //cout<<"解码y："<<dey[i]<<endl;
    }

    list<uint8_t*> uchary;
    list<uint8_t*>::iterator ucitor;
    for(int i=0;i<resultcount;i++){
      uchary.push_back((uint8_t*)dey[i].data());
      //cout<<"phexy:"<<endl;
      //phex((uint8_t*)dey[i].data());
    }
    ZZ zy[resultcount];
    int zyi=0;
    for(ucitor=uchary.begin();ucitor!=uchary.end();ucitor++){
      //cout<<"int to uint8_t"<<*ucitor<<endl;
      //phex(*ucitor);
      int zlen=strlen((char*)(*ucitor));
      //cout<<"zlen:"<<zlen<<endl;
      zy[zyi]=ZZFromBytes(*ucitor,ylenarr[zyi]);
      zyi++;
    } 
    // for(int i=0;i<resultcount;i++){
    //   cout<<zy[i]<<endl;
    // }

    list<char *>::iterator itor;
    int result[resultcount];
    for(int i=0;i<resultcount;i++){
      result[i]=1;
    }
    int icount=0;
    int c1;
    startTime2=clock();
    double querytime=0;
    for (itor=tokens.begin();itor!=tokens.end();itor++)
    {
      icount++;
      if(icount!=1){
        c1=0;
        ZZ xtokes[resultcount];
        for(int i=0;i<resultcount;i++){
          uint8_t *bkeyword=(uint8_t*)*itor;
          int bkwlen=strlen(*itor);
          oxt_prf(kxw,poxt->Kx,bkeyword,poxt->kxlen,bkwlen,poxt->q,qbytes);
          int_to_uint8(c1,intb);
          //phex(intb);
          cat_uint(data,keyword,intb,kwlen,4);//在生成xtoken的过程中，kzw使用的是  w1
          //phex(zdata);
          oxt_prf(z,poxt->Kz,data,poxt->kzlen,kwlen+4,poxt->q,qbytes);//z是w1对应c的z
          oxt_xtoken(xtokes[i],z,kxw,poxt);
          cout<<"xtokes:"<<xtokes[i]<<endl;
          startTime1=clock();
          ZZ tmpresult=PowerMod(xtokes[i],zy[i],poxt->p);
          cout<<tmpresult<<endl;
          int tmpresultlen=NumBytes(tmpresult);
          uint8_t *search=new uint8_t[tmpresultlen];
          BytesFromZZ(search,tmpresult,tmpresultlen);
          //cout<<tmpresult<<endl;
          //phex(search);     
          int queryresult=query_set(search,tmpresultlen,&sbf);
          //cout<<"tmpresultlen:"<<tmpresultlen<<"查询结果："<<queryresult<<endl;
          if(queryresult==0){//查找布隆过滤器不存在
            result[c1]=0;
          }
          endTime1=clock();
          querytime=querytime+(double)((endTime1 - startTime1));
          c1++;
          // free(zdata);
        }
      }
      
    }
    // / CLOCKS_PER_SEC 
    endTime2=clock();
    //cout << "混合时间 : " <<(double)(endTime2 - startTime2)<< "s" << endl;
    //cout << "查询时间 : " <<querytime/CLOCKS_PER_SEC<< "s" << endl;
    double clienttime2=(double)(endTime2 - startTime2)-querytime;
    

    cout<<"client:"<<(clienttime1+clienttime2)/CLOCKS_PER_SEC<<endl;
    cout<<"server:"<<(servertime1+querytime)/CLOCKS_PER_SEC<<endl;
    AES_init_ctx(&ctx, ke);
    int sumid=0;
    for(int i=0;i<resultcount;i++){
      if(result[i]==1){
        uint8_t *uchare=(uint8_t*)dee[i].data();
        AES_ECB_decrypt(&ctx, uchare);
        //cout<<uchare<<"   ";
        uint8_t *charid=new uint8_t[4];
        for(int j=12;j<16;j++){
          charid[j-12]=uchare[j];
        }
        int id=(int)charid[0]+((int)charid[1]*256)+((int)charid[2]*256*256)+((int)charid[3]*256*256*256);
        //cout<<"id:"<<id<<endl;
        sumid++;
        //phex(uchare);
      }
    }
    cout<<"搜索到的文件数量："<<sumid<<endl;


    
}

#endif // OXT_H_INCLUDED
