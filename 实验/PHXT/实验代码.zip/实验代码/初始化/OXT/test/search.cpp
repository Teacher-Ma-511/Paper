#include"include/Conn.h"
//#include"include/oxt.h"
#include"include/oxtf.h"
#include"include/aes.h"
#include<iostream>
#include<stdio.h>
#include<list>
#include<string>
#include<map>
#include<string.h>
#include<sys/time.h>
#include<unistd.h>
#include<mysql/mysql.h>
#include<NTL/tools.h>
#include<NTL/ZZ.h>
#include<gmp.h> 
#define LEN 1024
using namespace std;
using namespace NTL;

int main(){


  ConnectDatabase();

  //clock_t start, end;
  long numofinverted=4194;
  
  cout<<"记录数量："<<numofinverted<<endl;
  // int i=0;
  oxt_param_ptr poxt;
  
  ZZ g,p,q;
  ZZ_from_char(g,ag);
  ZZ_from_char(p,ap);
  ZZ_from_char(q,aq);
  oxt_param soxt={g,q,p,aks,akx,aki,akz,QLEN,PLEN,16, 16,16, 16, ID_LEN_IN_BYTE};
  poxt=&soxt;
  struct set_bf sbf;
  int intarrlen;
  init_set(&sbf,numofinverted,NUM_OF_HASH,intarrlen);
  char sql[150];
  list<unsigned int> uintlist;
  list<unsigned int>::iterator uintitor;
  sprintf(sql,"select * from bloom");
  QueryBloom(sql,uintlist);
  cout<<"查询长度："<<uintlist.size();
  int i=0;
  for(uintitor=uintlist.begin();uintitor!=uintlist.end();uintitor++){
    sbf.pbf->bf_array[i]=*uintitor;
    i++;
  }



  for(int j=0;j<1000;j++){
    cout<<"请输入要查询的关键词："<<endl;
    list<char *> searchword;
    
    for(int i=0;i<2;i++){
      char *word=new char[100];
      cin>>word;
      searchword.push_back(word);
    }
    clock_t startTime,endTime;
	  startTime = clock();
    oxt_query(poxt,searchword,numofinverted,sbf);
    endTime=clock();
    cout << "查询时间 : " <<(double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
  }
  
  
  FreeConnect();
  return 0;
}
