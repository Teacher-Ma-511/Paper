#include"include/Conn.h"
//#include"include/oxt.h"
#include"include/oxtf.h"
#include"include/aes.h"
#include<iostream>
#include<stdio.h>
#include<list>
#include<string>
#include<map>
#include<string.h>
#include<sys/time.h>
#include<unistd.h>
#include<mysql/mysql.h>
#include<NTL/tools.h>
#include<NTL/ZZ.h>
#include<gmp.h> 
#define LEN 1024
using namespace std;
using namespace NTL;
char sqlstr[2000];
int main(){
  //clock_t start, end;
  
  //  cout<<(int)sizeof(unsigned int)*8<<endl;
  //  exit(1);
  long numofinverted=1558324040;
  cout<<"记录数量："<<numofinverted<<endl;
  // int i=0;
  int intarrlen;
  struct set_bf sbf;
  init_set(&sbf,numofinverted,NUM_OF_HASH,intarrlen);
  cout<<intarrlen<<endl;
  oxt_param_ptr poxt;
  
  ZZ g,p,q;
  ZZ_from_char(g,ag);
  ZZ_from_char(p,ap);
  ZZ_from_char(q,aq);
  oxt_param soxt={g,q,p,aks,akx,aki,akz,QLEN,PLEN,16, 16,16, 16, ID_LEN_IN_BYTE};
  poxt=&soxt;
  int m=0;
  int n=50000;
  for(int i=0;i<546;i++){
    list<char *> keyoflist;
    sprintf(sqlstr,"select keyword from keyword limit %d,%d",m,n);
    ConnectDatabase();
    Querykeyword(sqlstr,keyoflist);
    cout<<"keyoflist长度："<<keyoflist.size()<<endl;
    oxt_create_EDB(poxt,keyoflist,numofinverted,sbf);
    keyoflist.clear();
    mysql_free_result(mainres);
    FreeConnect();
    m+=n;
  }
  cout<<intarrlen<<endl;
  string bloomsql="insert into bloom values";
  ConnectDatabase();
  for(int i=0;i<intarrlen;i++){
      unsigned int temp=sbf.pbf->bf_array[i];
      

      if((i+1)%50000==0||i==intarrlen-1){
        bloomsql.append("('").append(to_string(temp)).append("');");
        
        bool re=insertbloom(bloomsql.c_str());
        
        bloomsql="insert into bloom values";
      }else{
        bloomsql.append("('").append(to_string(temp)).append("'),");
      }
      
  }
  cout<<"完成bloom"<<endl;
  
  for(int i=0;i<20;i++){
    
    cout<<"请输入要查询的关键词："<<endl;
    list<char *> searchword;
    
    for(int i=0;i<2;i++){
      char *word=new char[100];
      cin>>word;
      searchword.push_back(word);
    }
    oxt_query(poxt,searchword,numofinverted,sbf);
  }
  mysql_free_result(res);
  FreeConnect();
  return 0;
}