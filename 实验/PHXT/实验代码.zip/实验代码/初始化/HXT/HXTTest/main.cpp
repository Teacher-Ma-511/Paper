#include"include/Conn.h"
//#include"include/oxt.h"
#include"include/hxt.h"
#include"include/aes.h"
#include<iostream>
#include<stdio.h>
#include<list>
#include<string>
#include<map>
#include<string.h>
#include<sys/time.h>
#include<unistd.h>
#include<mysql/mysql.h>
#include<NTL/tools.h>
#include<NTL/ZZ.h>
#include<gmp.h> 
#define LEN 1024
using namespace std;
using namespace NTL;
char sqlstr[1000];
int main(){
  //clock_t start, end;
  
  //  cout<<(int)sizeof(unsigned int)*8<<endl;
  //  exit(1);
  long numofinverted=58563827;
  cout<<"记录数量："<<numofinverted<<endl;
  // int i=0;
  int intarrlen;
  struct set_bf sbf;
  struct AES_ctx ctx;
  init_set(&sbf,numofinverted,NUM_OF_HASH,intarrlen);
  cout<<intarrlen<<endl;
  hxt_param_ptr phxt;
  
  ZZ g,p,q;
  ZZ_from_char(g,ag);
  ZZ_from_char(p,ap);
  ZZ_from_char(q,aq);
  hxt_param shxt={g,q,p,aks,akx,aki,akz,QLEN,PLEN,16, 16,16, 16, ID_LEN_IN_BYTE};
  phxt=&shxt;
  int m=0;
  int n=50000;
  for(int i=0;i<53;i++){
    list<char *> keyoflist;
    sprintf(sqlstr,"select keyword from mediumkeyword limit %d,%d",m,n);
    ConnectDatabase();
    Querykeyword(sqlstr,keyoflist);
    cout<<"keyoflist长度："<<keyoflist.size()<<endl;
    oxt_create_EDB(phxt,keyoflist,numofinverted,sbf);
    keyoflist.clear();
    mysql_free_result(mainres);
    FreeConnect();
    m+=n;
  }
  cout<<intarrlen<<endl;
  
  ConnectDatabase();
  cout<<"完成bloom"<<endl;
  uint8_t bitvaluebytes[4];
  uint8_t indexvaluebytes[8];
  uint8_t idindex[16];
  uint8_t cdata[8];

  ZZ cz;
  string csql="insert into hxtbloom(c) values";
  long ccount=0;
  for(int i=0;i<intarrlen;i++){
      unsigned int temp=sbf.pbf->bf_array[i];
      //cout<<temp<<endl;
      int bitvalue;
      for (int j=31;j>=0;j--) 
      { 
          for(int i=0;i<4;i++){
            idindex[i]=0x00;
          }
        ccount++;
        bitvalue=((temp>>j)&1); 
        int_to_uint8(bitvalue,bitvaluebytes);
        long_to_uint8(ccount,indexvaluebytes);
        cat_uint(cdata,bitvaluebytes,indexvaluebytes,4,8);
        //创建出16字节的纯文本
        cat_uint(idindex,idindex,cdata,4,12);
        AES_init_ctx(&ctx, akz);
        AES_ECB_encrypt(&ctx,idindex);
        string strc=base64_encode(idindex,16);
        //cout<<"strc:"<<strc<<endl;
        if(ccount%100000==0||ccount==32*intarrlen){
        csql.append("('").append(strc).append("');");
        //cout<<csql<<endl;
        bool re=insertbloom(csql.c_str());
        cout<<re<<endl;
        
        csql="insert into hxtbloom(c) values";
        }else{
          csql.append("('").append(strc).append("'),");
        }
      }         
  }

   //free(sbf.pbf->bf_array);

  for(int i=0;i<10000;i++){
    
    cout<<"请输入要查询的关键词："<<endl;
    list<char *> searchword;
    
    for(int i=0;i<2;i++){
      char *word=new char[100];
      cin>>word;
      searchword.push_back(word);
    }
    oxt_query(phxt,searchword,numofinverted,sbf);
  }
  mysql_free_result(res);
  FreeConnect();
  return 0;
}