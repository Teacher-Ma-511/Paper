#ifndef BF_H_INCLUDED
#define BF_H_INCLUDED

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>

#include <NTL/ZZ.h>

using namespace std;
using namespace NTL;

/*begin the bloom filter party*/
#define TOOMANYHASHS 1<<sizeof(unsigned int)*8-1
#define NUM_OF_HASH 20

struct bf{
    unsigned int* bf_array=0;
    unsigned long length;
    unsigned long numofblock;
    int shift;
    int blocksize;
};

struct set_bf{
    struct bf* pbf;
    unsigned long numofmember;
    int numofhash;
};

static int init_bf(struct bf* pbf,unsigned long len,int &intlen);
static void free_bf(struct bf* pbf);
static unsigned int setvalue_bf(struct bf* pbf, unsigned long pos);
static unsigned int getvalue_bf(struct bf* pbf, unsigned long pos);
static unsigned int query_bf(struct bf* pbf, unsigned long* pos, int mpos);

static int init_set(set_bf* pset,unsigned long numofmember, int numofhash,int &intlen);
static int insert_set(unsigned char* member, int mlen, set_bf* pset);
static unsigned int query_set(unsigned char* member, int mlen, set_bf* pset);


static int init_bf(struct bf* pbf, unsigned long len,int &intlen)
{
    if(len<0)
        return 5;

    long i;

    pbf->blocksize= (int)sizeof(unsigned int)*8;
    //printf("blocksize=%d\n",pbf->blocksize);

    switch(pbf->blocksize){
        case 8:  pbf->shift=3; break;
        case 16: pbf->shift=4; break;
        case 32: pbf->shift=5; break;
        case 64: pbf->shift=6; break;
        default: return 10;
    }

    //printf("%d\n",pbf->sizeofblock);
    //printf("shift=%d\n",pbf->shift);
    pbf->length=len;

    if(pbf->length % pbf->blocksize == 0)
        pbf->numofblock = pbf->length>>pbf->shift;
    else
        pbf->numofblock = (pbf->length>>pbf->shift) + 1;

    //printf("numofblock=%ld\n",pbf->numofblock);
    intlen=pbf->numofblock;
    pbf->bf_array = (unsigned int*) malloc(sizeof(unsigned int)*(pbf->numofblock));

    for(i=0;i<pbf->numofblock;i++)
        pbf->bf_array[i]=0;

    //printf("bf:length=%ld,shift=%d,numofblock=%ld",pbf->length,pbf->shift,pbf->numofblock);
    //printf("\n\n");

    return 1;
}

static void free_bf(struct bf* pbf)
{
    free(pbf->bf_array);
}

static unsigned int setvalue_bf(struct bf* pbf, unsigned long pos)
{
    if(pos<0||pos>pbf->length)
    {
        printf("error: illegal pos\n");
        return 3;
    }
 /*
    unsigned int test,i,j,shifts;
    i=pos>>pbf->shift;
    j=pbf->bf_array[i];
    shifts=pos % pbf->blocksize;
    printf("array[%d]=%d,shifts=%d\n",i,j,shifts);
    test=(pbf->bf_array[pos>>pbf->shift]>>(pos % pbf->blocksize)) & 1;
    printf("test=%d",test);
*/
    if(((pbf->bf_array[pos>>pbf->shift]>>(31-pos % pbf->blocksize)) & 1) == 0)
    {
        pbf->bf_array[pos>>pbf->shift]=pbf->bf_array[pos>>pbf->shift]+(1<<(31-pos % pbf->blocksize));
        //cout<<"bloom:"<<pbf->bf_array[pos>>pbf->shift]+(1<<(pos % pbf->blocksize))<<endl;
//        printf("updated\n");
    }
    return 1;
}

static unsigned int getvalue_bf(struct bf* pbf, unsigned long pos)
{
    if(pos<0||pos>pbf->length)
        return 3;

    return (pbf->bf_array[pos>>pbf->shift]>>(31-pos % pbf->blocksize)) & 1;

}

static unsigned int query_bf(struct bf* pbf, unsigned long* pos, int mpos)
{
    unsigned int result=0;
    long i;

    for(i=0;i<mpos;i++)
        result+=(getvalue_bf(pbf,pos[i])<<i);

    return result;
}

static int init_set(set_bf* pset, unsigned long numofmember, int numofhash,int &intlen)
{
    if(numofhash>sizeof(unsigned int)*8-1)
        return TOOMANYHASHS;

    pset->numofhash=numofhash;
    pset->numofmember=numofmember;
    pset->pbf= (struct bf*)malloc(sizeof(struct bf));
    init_bf(pset->pbf,28*pset->numofmember,intlen);

    return 1;
}
static int insert_set(unsigned char* member, int mlen, set_bf* pset)
{
    int i,j;
    long pos;
    unsigned char* key;
    key= (unsigned char*)malloc(sizeof(unsigned char)*6*pset->numofhash);
    DeriveKey(key, 6*pset->numofhash, member, mlen);//need ntl lib
    for(i=0;i<pset->numofhash;i++)
    {
        pos=0;
        for(j=0;j<6;j++)
        {
            pos=pos+(((int)key[i*6+j])<<8*j);
        }
        pos=pos % pset->pbf->length;

        //printf("pos%d=%ld\n",i,pos);

        setvalue_bf(pset->pbf,pos);
    }
    free(key);
    return 1;
}
static unsigned int query_set(unsigned char* member, int mlen, set_bf* pset)
{
    int i,j;
    unsigned result=0;
    long pos;
    unsigned char* key;
    key= (unsigned char*)malloc(sizeof(unsigned char)*6*pset->numofhash);
    DeriveKey(key, 6*pset->numofhash, member, mlen);//need ntl lib
    for(i=0;i<pset->numofhash;i++)
    {
        pos=0;
        for(j=0;j<6;j++)
        {
            pos=pos+(((int)key[i*6+j])<<8*j);
        }
        pos=pos % pset->pbf->length;

        result=getvalue_bf(pset->pbf,pos);
        if(result==0)
            return 0;
    }
    free(key);
    return 1;
}

static void query_index(unsigned char* member, int mlen, set_bf* pset,list<long> &indexlist)
{
    int i,j;
    unsigned result=0;
    long pos;
    unsigned char* key;
    key= (unsigned char*)malloc(sizeof(unsigned char)*6*pset->numofhash);
    DeriveKey(key, 6*pset->numofhash, member, mlen);//need ntl lib
    for(i=0;i<pset->numofhash;i++)
    {
        pos=0;
        for(j=0;j<6;j++)
        {
            pos=pos+(((int)key[i*6+j])<<8*j);
        }
        pos=pos % pset->pbf->length;
        indexlist.push_back(pos+1);
    }
    free(key);
}

#endif // BF_H_INCLUDED
