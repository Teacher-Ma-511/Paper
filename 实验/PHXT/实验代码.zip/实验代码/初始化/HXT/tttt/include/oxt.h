#ifndef OXT_H_INCLUDED
#define OXT_H_INCLUDED
#include"aes.h"
#include"Conn.h"
#include <stdio.h>
#include <assert.h>
#include <iostream>
#include<map>
#include<list>
#include <NTL/ZZ.h>

using namespace std;
using namespace NTL;



const char* ag="12293041548191560959252997681221893073091763148392091587781229526780505319280253304158657014186812803260820624200425866044892534107445664741934978636107726042273789227287786063826002069319009175216162933494359277792631586799194401273339746711856497988529049521334761338869458014310995080149317625448851976250\n";

const char* ap="35846489658960820960446633115143023883040757131525173446156521584352743991679231122673876526186909574940183912868842246185467405988094236483899550393037943055836758636212712380713704715884242930459327176061234383344181152578596944695560082751184202851538548055157781713238676762830736663499575834426106137609\n";

const char* aq="91677580900928952829845059692479440057913422538304665006082987855400898556463\n";
const char* aa="256657756656173201739006276223986806063\n";
const char* ss="207795221597475674033728225247992608407466656032486224579019\n";

#define QLEN 256
#define PLEN 1024

struct oxt
{
    ZZ g;
    ZZ q;
    ZZ p;
    long qlen;
    long plen;
};
typedef struct oxt   oxt_param;
typedef struct oxt*  oxt_param_ptr;

static void init_oxt(oxt_param_ptr poxt, const char* cg, const char* cp, const char* cq, long qlen, long plen);
static void oxt_y(ZZ& y, ZZ& xind, ZZ& z, oxt_param_ptr poxt);
static void oxt_xtoken(ZZ& xtoken, ZZ& kzw, ZZ& kxw, oxt_param_ptr poxt);
static void oxt_xtag(ZZ& xtag, ZZ& kxw, ZZ& xind, oxt_param_ptr poxt);

static void ZZ_from_char(ZZ& z, const char* ctr);
void generate_ddh_parameters(ZZ& g, ZZ& q, ZZ& p, long qlen, long plen);


string base64_encode(unsigned char const* , unsigned int len);
string base64_decode(std::string const& s);
void stringappend(string &word);
void KeyGen(uint8_t *&key);
void KeyWord(string word,uint8_t *&key1,uint8_t *&key2);
void encryptcount(uint8_t * word,string appendword,struct AES_ctx ctx,int &max);
void Setup(list<string> keyoflist,multimap<string,string> inverted,uint8_t *key,uint8_t *&key1,uint8_t *&key2);

static void phex(uint8_t* str)
{

#if defined(AES256)
    uint8_t len = 32;
#elif defined(AES192)
    uint8_t len = 24;
#elif defined(AES128)
    uint8_t len = 16;
#endif

    unsigned char i;
    for (i = 0; i < len; ++i)
        printf("%.2x", str[i]);
    printf("\n");
}


static void ZZ_from_char(ZZ& z, const char* ctr)
{
	long i,j;
	ZZ temp1,temp2;

	i=0;
	j=0;
	z=0;
	temp1=0;
	temp2=0;
	while(ctr[i]!='\n')
	{
		i++;j++;
	}
	i=i-1;
	j=i;
	while(i>-1)
	{
		power(temp1,10,j-i);
		switch(ctr[i])
		{
			case '0': temp2=0; break;
			case '1': temp2=1; break;
			case '2': temp2=2; break;
			case '3': temp2=3; break;
			case '4': temp2=4; break;
			case '5': temp2=5; break;
			case '6': temp2=6; break;
			case '7': temp2=7; break;
			case '8': temp2=8; break;
			case '9': temp2=9; break;
			default: cout<<"initialize big integer errors"; return;

		}
		temp2=temp2 * temp1;
		z = z + temp2;
		i--;
	}
}

void generate_ddh_parameters(ZZ& g, ZZ& q, ZZ& p, long qlen, long plen)
{
    ZZ h,temp,temp2;
    long i,isprime=0;
	i=0;
    GenPrime(q,qlen);
    while(isprime==0){
        RandomBits(temp,plen-qlen);
        p=temp*q+1;
        isprime=ProbPrime(p);
	i++;
    }
	cout<<"the num of try="<<i<<endl;
    RandomBits(h,qlen);
	temp2=PowerMod(h,p-1,p);
	cout<<"h^p-1="<<temp2<<endl;
	temp2=temp*q+1;
	cout<<"temp*q+1="<<temp2<<endl;

    g=PowerMod(h,temp,p);
	temp2=PowerMod(g,q,p);
	cout<<"g^q="<<temp2<<endl;

    cout<<"g="<<endl<<g<<endl<<endl;
    cout<<"p="<<endl<<p<<endl<<endl<<"q="<<endl<<q<<endl;
}

static void init_oxt(oxt_param_ptr poxt, const char* cg, const char* cp, const char* cq, long qlen, long plen)
{
    ZZ g,p,q;

	ZZ_from_char(g,cg);
	ZZ_from_char(q,cq);
	ZZ_from_char(p,cp);
    poxt->g=g;
    poxt->q=q;
    poxt->p=p;
    poxt->qlen=qlen;
    poxt->plen=plen;
}

static void oxt_y(ZZ& y, ZZ& xind, ZZ& z, oxt_param_ptr poxt)
{
    ZZ tmp;
    tmp=InvMod(z,poxt->q);
    y=MulMod(xind,tmp,poxt->q);
}

static void oxt_xtoken(ZZ& xtoken, ZZ& kzw, ZZ& kxw, oxt_param_ptr poxt)
{
    ZZ tmp;
    tmp=MulMod(kzw,kxw,poxt->q);
    xtoken=PowerMod(poxt->g,tmp,poxt->p);
	
}

static void oxt_xtag(ZZ& xtag, ZZ& kxw, ZZ& xind, oxt_param_ptr poxt)
{
    ZZ tmp;

    tmp=MulMod(xind,kxw,poxt->q);
    xtag=PowerMod(poxt->g%poxt->p,tmp,poxt->p);
}


static const std::string base64_chars = 
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789+/";
 

static inline bool is_base64(unsigned char c) {
  return (isalnum(c) || (c == '+') || (c == '/'));
}
 
std::string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len) {
  std::string ret;
  int i = 0;
  int j = 0;
  unsigned char char_array_3[3];
  unsigned char char_array_4[4];
 
  while (in_len--) {
    char_array_3[i++] = *(bytes_to_encode++);
    if (i == 3) {
      char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
      char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
      char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
      char_array_4[3] = char_array_3[2] & 0x3f;
 
      for(i = 0; (i <4) ; i++)
        ret += base64_chars[char_array_4[i]];
      i = 0;
    }
  }
 
  if (i)
  {
    for(j = i; j < 3; j++)
      char_array_3[j] = '\0';
 
    char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
    char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
    char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
    char_array_4[3] = char_array_3[2] & 0x3f;
 
    for (j = 0; (j < i + 1); j++)
      ret += base64_chars[char_array_4[j]];
 
    while((i++ < 3))
      ret += '=';
 
  }
 
  return ret;
 
}
 
std::string base64_decode(std::string const& encoded_string) {
  int in_len = encoded_string.size();
  int i = 0;
  int j = 0;
  int in_ = 0;
  unsigned char char_array_4[4], char_array_3[3];
  std::string ret;
 
  while (in_len-- && ( encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
    char_array_4[i++] = encoded_string[in_]; in_++;
    if (i ==4) {
      for (i = 0; i <4; i++)
        char_array_4[i] = base64_chars.find(char_array_4[i]);
 
      char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
      char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
      char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];
 
      for (i = 0; (i < 3); i++)
        ret += char_array_3[i];
      i = 0;
    }
  }
 
  if (i) {
    for (j = i; j <4; j++)
      char_array_4[j] = 0;
 
    for (j = 0; j <4; j++)
      char_array_4[j] = base64_chars.find(char_array_4[j]);
 
    char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
    char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
    char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];
 
    for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
  }
 
  return ret;
}



//将关键字扩展为16的倍数长度
void stringappend(string &word){
	int len=16-word.length()%16;
	for(int i=0;i<len;i++){
		word.append(" ");
	}
}
void KeyGen(uint8_t *&key){
	//生成最终需要的密钥
     long len=128;
    NTL::ZZ pass=RandomBits_ZZ(len);
    key=new uint8_t[128];
    uint8_t *key1=new uint8_t[128];
    long len1=NumBytes(pass);
    BytesFromZZ(key1,pass,len1);
    long klen=strlen((char *)key1);
    DeriveKey(key,16,key1,klen);
}
//对应关键字的生成的密钥
void KeyWord(string word,uint8_t *&key1,uint8_t *&key2){
	long len1=16;
	string word1=word+to_string(1);
	string word2=word+to_string(2);
	uint8_t *cword1=(uint8_t *)(word1.data());
	uint8_t *cword2=(uint8_t *)(word2.data());
	long lenght1=strlen((char*)cword1); 
	long lenght2=strlen((char*)cword2);
	key1=new uint8_t[16];
	key2=new uint8_t[16];
	DeriveKey(key1,len1,cword1,lenght1);
	DeriveKey(key2,len1,cword2,lenght2);
	cout<<"key1:"<<key1<<endl;	
}

//多次加密
void encryptcount(uint8_t * word,string appendword,struct AES_ctx ctx,int &max){
	int len=appendword.length();
	max=len/16; 
	//对文件名进行加密
	for(int i=0;i<max;i++){
		AES_ECB_encrypt(&ctx, word+i*16);
	}
}


void Setup(list<string> keyoflist,multimap<string,string> inverted,uint8_t *key,uint8_t *&key1,uint8_t *&key2){
	struct AES_ctx ctxw;
    struct AES_ctx ctxf;
	struct AES_ctx ctxz;
	oxt_param_ptr sptroxt;
	ZZ g,p,q,z,xind,kxw,xtag,y;
	ZZ_from_char(g,ag);
	ZZ_from_char(p,ap);
	ZZ_from_char(q,aq);
	oxt_param soxt={g,p,q,QLEN,PLEN};
	sptroxt=&soxt;
	//init_oxt(soxt,ag,ap,aq,QLEN,PLEN);
	list<string>::iterator listitor;
	int number=0;
	bool result;
	for(listitor=keyoflist.begin();listitor!=keyoflist.end();listitor++){
        number++;
		// if(number==1184){
		// 	exit(1);
		// }
        cout<<"便利的关键字的个数："<<number<<endl;
        string word=*listitor;
		//记住原始的关键字，后面生成Z会用
		string zword=word;
		cout<<"zwordstr:"<<zword<<endl;
		multimap<string,string>::iterator itor=inverted.find(word);
        multimap<string,string>::size_type cnt = inverted.count(word);
		//k1,k2的两个对应密钥
		AES_init_ctx(&ctxz, key);
		AES_init_ctx(&ctxw, key1);
        AES_init_ctx(&ctxf, key2);
		stringappend(word);
		cout<<"wprdstr:"<<word<<endl;
		//这里要注意循环的次数，因为解密的时候需要同样的次数，所以准备将次数插入数据库，也就是将max的值进行插库。
		//加密关键字的变量是：wordchar
		cout<<"长加密："<<endl;
		uint8_t *wordchar=(uint8_t *)word.data();
		int wmax;//记录加密次数
		encryptcount(wordchar,word,ctxz,wmax);
		
		int wordcount=0;
		for(;cnt>0;cnt--,itor++){
			cout<<(*itor).first<<"   "<<(*itor).second<<endl;
			string filename=(*itor).second;
			
			//生成xind
			uint8_t *filenamechar=(uint8_t*)filename.data();
			int fcharlen=strlen((char *)filenamechar);
			uint8_t *charxind=new uint8_t[16];
			DeriveKey(charxind,16,filenamechar,fcharlen);


			//将关键字和文件名的排列顺序组成zword，来生成z
			//生成Z
			wordcount++;
			string zwordstr=zword;
			zwordstr=zwordstr+to_string(wordcount);
			cout<<"zwordapp:"<<zwordstr<<endl;
			uint8_t *zwordchar=(uint8_t *)zwordstr.data();
			int lenchar=strlen((char *)zwordchar);
			uint8_t *chary=new uint8_t[16];
			DeriveKey(chary,16,zwordchar,lenchar);
			cout<<"chary(char):"<<chary<<endl;

			




			stringappend(filename);
			uint8_t* ffn=(uint8_t *)(filename.data());

			int fmax;
			encryptcount(ffn,filename,ctxf,fmax);

			z=ZZFromBytes(chary,16);
			xind=ZZFromBytes(charxind,32);
			kxw=ZZFromBytes(wordchar,16);
			
			oxt_y(y,xind,z,sptroxt);
			oxt_xtag(xtag,kxw,xind,sptroxt);
			cout<<"z:"<<z<<endl;
			cout<<"xind:"<<xind<<endl;
			cout<<"kwx:"<<kxw<<endl;
			cout<<"y:"<<y<<endl;
			cout<<"xtag:"<<xtag<<endl;
			//string wordcharencoded = base64_encode(wordchar, strlen((char *)wordchar));
			//string ffnencoded=base64_encode(ffn,strlen((char *)ffn));
			//cout<<"wordcharencode:"<<wordcharencoded<<endl;
			//cout<<"ffnencoded:"<<ffnencoded<<endl;
			//uint8_t *finword=(uint8_t*)wordcharencoded.data();
			//uint8_t *finfilename=(uint8_t*)ffnencoded.data();
			result=InsertData(wordchar,ffn,wmax,fmax);	

			//cout<<"解密："<<ffn<<endl;

		}//cnt循环


		
	}//for
            
 
}

#endif // OXT_H_INCLUDED
