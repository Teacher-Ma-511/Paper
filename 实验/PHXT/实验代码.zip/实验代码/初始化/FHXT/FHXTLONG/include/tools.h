
/***********************************************************************************************************************************
 *the tools for SSE experiments which include the following parts
 *1. the Bloom Filter
 *2. the bernoulli sampling
 *3. the BCH codes
 *4. the AES algorithm
 *other useful functions can be found in NTL library
 *the compile command should be: g++ -g -o2 -std=c++11 -pthread -march=native tools.c -o main -lntl -lgmp -lm
 ***********************************************************************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>

#include <NTL/ZZ.h>

using namespace std;
using namespace NTL;

/*begin the bloom filter party*/
#define TOOMANYHASHS 1<<sizeof(unsigned int)*8-1

//#define BF_LENGTH (1<<30))

struct bf{
    unsigned int* bf_array=0;
    unsigned long length;
    unsigned long numofblock;
    int shift;
    int blocksize;
};

struct set_bf{
    struct bf* pbf;
    unsigned long numofmember;
    int numofhash;
};

static int init_bf(struct bf* pbf,unsigned long len);
static void free_bf(struct bf* pbf);
static unsigned int setvalue_bf(struct bf* pbf, unsigned long pos);
static unsigned int getvalue_bf(struct bf* pbf, unsigned long pos);
static unsigned int query_bf(struct bf* pbf, unsigned long* pos, int num_of_hash);

static int init_set(set_bf* pset,unsigned long numofmember, int numofhash);
static int insert_set(unsigned char* member, int mlen, set_bf* pset);
static unsigned int query_set(unsigned char* member, int mlen, set_bf* pset);


static int init_bf(struct bf* pbf, unsigned long len)
{
    if(len<0)
        return 5;

    long i;

    pbf->blocksize= (int)sizeof(unsigned int)*8;
    //printf("blocksize=%d\n",pbf->blocksize);

    switch(pbf->blocksize){
        case 8:  pbf->shift=3; break;
        case 16: pbf->shift=4; break;
        case 32: pbf->shift=5; break;
        case 64: pbf->shift=6; break;
        default: return 10;
    }

    //printf("%d\n",pbf->sizeofblock);
    //printf("shift=%d\n",pbf->shift);
    pbf->length=len;

    if(pbf->length % pbf->blocksize == 0)
        pbf->numofblock = pbf->length>>pbf->shift;
    else
        pbf->numofblock = (pbf->length>>pbf->shift) + 1;

    //printf("numofblock=%ld\n",pbf->numofblock);

    pbf->bf_array = (unsigned int*) malloc(sizeof(unsigned int)*(pbf->numofblock));

    for(i=0;i<pbf->numofblock;i++)
        pbf->bf_array[i]=0;

    //printf("bf:length=%ld,shift=%d,numofblock=%ld",pbf->length,pbf->shift,pbf->numofblock);
    //printf("\n\n");

    return 1;
}

static void free_bf(struct bf* pbf)
{
    free(pbf->bf_array);
}

static unsigned int setvalue_bf(struct bf* pbf, unsigned long pos)
{
    if(pos<0||pos>pbf->length)
    {
        printf("error: illegal pos\n");
        return 3;
    }
 /*
    unsigned int test,i,j,shifts;
    i=pos>>pbf->shift;
    j=pbf->bf_array[i];
    shifts=pos % pbf->blocksize;
    printf("array[%d]=%d,shifts=%d\n",i,j,shifts);
    test=(pbf->bf_array[pos>>pbf->shift]>>(pos % pbf->blocksize)) & 1;
    printf("test=%d",test);
*/
    if(((pbf->bf_array[pos>>pbf->shift]>>(pos % pbf->blocksize)) & 1) == 0)
    {
        pbf->bf_array[pos>>pbf->shift]=pbf->bf_array[pos>>pbf->shift]+(1<<(pos % pbf->blocksize));
//        printf("updated\n");
    }
    return 1;
}

static unsigned int getvalue_bf(struct bf* pbf, unsigned long pos)
{
    if(pos<0||pos>pbf->length)
        return 3;

    return (pbf->bf_array[pos>>pbf->shift]>>(pos % pbf->blocksize)) & 1;

}

static unsigned int query_bf(struct bf* pbf, unsigned long* pos, int num_of_hash)
{
    if(num_of_hash>sizeof(unsigned int)*8-1)
        return TOOMANYHASHS;//(1<<sizeof(unsigned int)*8-1);

    unsigned int result=0;
    long i;

    for(i=0;i<num_of_hash;i++)
        result+=(getvalue_bf(pbf,pos[i])<<i);

    return result;
}

static int init_set(set_bf* pset, unsigned long numofmember, int numofhash)
{
    pset->numofhash=numofhash;
    pset->numofmember=numofmember;
    pset->pbf= (struct bf*)malloc(sizeof(struct bf));
    init_bf(pset->pbf,28*pset->numofmember);

    return 1;
}
static int insert_set(unsigned char* member, int mlen, set_bf* pset)
{
    int i,j;
    long pos;
    unsigned char* key;
    key= (unsigned char*)malloc(sizeof(unsigned char)*8*pset->numofhash);
    DeriveKey(key, 8*pset->numofhash, member, mlen);//need ntl lib
    for(i=0;i<pset->numofhash;i++)
    {
        pos=0;
        for(j=0;j<8;j++)
        {
            pos=pos+(((int)key[i*8+j])<<8*j);
        }
        pos=pos % pset->pbf->length;

        //printf("pos%d=%ld\n",i,pos);

        setvalue_bf(pset->pbf,pos);
    }
    return 1;
}
static unsigned int query_set(unsigned char* member, int mlen, set_bf* pset)
{
    int i,j;
    unsigned result=0;
    long pos;
    unsigned char* key;
    key= (unsigned char*)malloc(sizeof(unsigned char)*8*pset->numofhash);
    DeriveKey(key, 8*pset->numofhash, member, mlen);//need ntl lib
    for(i=0;i<pset->numofhash;i++)
    {
        pos=0;
        for(j=0;j<8;j++)
        {
            pos=pos+(((int)key[i*8+j])<<8*j);
        }
        pos=pos % pset->pbf->length;

        result=getvalue_bf(pset->pbf,pos);
        if(result==0)
            return 0;
    }
    return 1;
}

/*end of the bloom filter party*/


/*begin the bernoulli sampling part*/

#define DIMENSION 280
#define MAX_PRECISION 63
#define SHORT_RANDOM_BITS 7
#define NONE_ZERO_VECTOR 1
#define ZERO_VECTOR 0
#define TOO_MANY_PRECESSION 3
struct bernoulli{
    double p;            //error rate
    int precision;       //sample precision
    int length;          //the length bernoilli sequence
    int weight;          //the weight of bernoulli sequence
    int* berbits;        //the bernoulli sequence
};

static void init_bernoulli(struct bernoulli* pb, double p, int len, int precision);
static void free_bernoilli(struct bernoulli* pb);
static int xbit(int n, int k);
static int bernoulli_Sample_DDG(double p, ZZ& r, int* ber_bits, int len,int precision,int* hw);
static int sample_bernoulli(struct bernoulli* pb);
static int sample_bernoulli_wsrb(struct bernoulli* pb, ZZ& randombits);//sample bernoulli sequence with tha same random bits



static void init_bernoulli(struct bernoulli* pb, double p, int len, int precision)
{
    pb->berbits=(int*) malloc(sizeof(int)*len);
    pb->length=len;
    pb->weight=0;
    pb->precision=precision;
    pb->p=p;
}

static void free_bernoilli(struct bernoulli* pb)
{
    free(pb->berbits);
}

static int xbit(int n,int k)
{
    if((n>>(k-1))%2==1)
        return 1;
    else
        return 0;
}


static int bernoulli_Sample_DDG(double p, ZZ& r, int* ber_bits, int len,int precision,int* hw)
{
    if(precision>MAX_PRECISION)
        return TOO_MANY_PRECESSION;

    int prob_matrice=0;
    int a,i,k;
    long j,num_of_bits;

    num_of_bits=NumBits(r);
    a=0;
    for(i=0;i<precision;i++)
    {
        a=floor(p*2);
        prob_matrice=prob_matrice+a*(1<<i);//(pow(2,i));//
        p=p*2-a;
    }

    *hw=0;
    j=0;
    for(i=0;i<len;i++)
    {
        k=0;
        j=j+1;
        while(j<num_of_bits && bit(r,j)!=0)
        {
            j++;
            k++;
        }

        if(j<num_of_bits)
        {
            ber_bits[i]=xbit(prob_matrice,k);
            if(ber_bits[i]!=0)
            {
                *hw+=1;
            }
        }
        else if(i<len-1)
        {
            return SHORT_RANDOM_BITS;
        }
    }

    if(*hw>0)
        return NONE_ZERO_VECTOR;
    else
        return ZERO_VECTOR;

}

static int sample_bernoulli(struct bernoulli* pb)
{
    ZZ randombits;
    RandomBits(randombits,3*pb->length);
    return sample_bernoulli_DDG(pb->p,randombits,pb->berbits,pb->length,pb->precision,pb->weight);
}

static int sample_bernoulli_wsrb(struct bernoulli* pb, ZZ& randombits)
{
    return sample_bernoulli_DDG(pb->p,randombits,pb->berbits,pb->length,pb->precision,pb->weight);
}

/*end of the bernoulli sampling part*/


/*the bch_code part*/

//#define TEST

struct bch_code{
    int m;
    int n;
    int length;//the code length
    int k;//message bits length to be encoded
    int t;//correct t bits errors
    int d;//the code distance
    int p[21];
    int alpha_to[512];
    int index_of[512];
    int g[512];
    int bb[512];
};

void generate_gf(struct bch_code* pbch);
void gen_poly(struct bch_code* pbch);
void init_bch(struct bch_code* pbch,int m, int length, int t);
void encode_bch(struct bch_code* pbch, int* data, int* data_code);
void decode_bch(struct bch_code* pbch, int* received_code,int* recovered_data);


void
init_bch(struct bch_code* pbch,int m, int length, int t)
{
    int	i;

    pbch->m=m;
    pbch->t=t;
    pbch->length=length;

    for (i=1; i<m; i++)
		pbch->p[i] = 0;
	pbch->p[0] =1;
	pbch->p[m] = 1;
	if (m == 2)			pbch->p[1] = 1;
	else if (m == 3)	pbch->p[1] = 1;
	else if (m == 4)	pbch->p[1] = 1;
	else if (m == 5)	pbch->p[2] = 1;
	else if (m == 6)	pbch->p[1] = 1;
	else if (m == 7)	pbch->p[1] = 1;
	else if (m == 8)	pbch->p[4] = pbch->p[5] = pbch->p[6] = 1;
	else if (m == 9)	pbch->p[4] = 1;
	else if (m == 10)	pbch->p[3] = 1;
	else if (m == 11)	pbch->p[2] = 1;
	else if (m == 12)	pbch->p[3] = pbch->p[4] = pbch->p[7] = 1;
	else if (m == 13)	pbch->p[1] = pbch->p[3] = pbch->p[4] = 1;
	else if (m == 14)	pbch->p[1] = pbch->p[11] = pbch->p[12] = 1;
	else if (m == 15)	pbch->p[1] = 1;
	else if (m == 16)	pbch->p[2] = pbch->p[3] = pbch->p[5] = 1;
	else if (m == 17)	pbch->p[3] = 1;
	else if (m == 18)	pbch->p[7] = 1;
	else if (m == 19)	pbch->p[1] = pbch->p[5] = pbch->p[6] = 1;
	else if (m == 20)	pbch->p[3] = 1;

    pbch->n = (1<<m)-1;
    generate_gf(pbch);
    gen_poly(pbch);
}

void
generate_gf(struct bch_code* pbch)
/*
 * Generate field GF(2**m) from the irreducible polynomial p(X) with
 * coefficients in p[0]..p[m].
 *
 * Lookup tables:
 *   index->polynomial form: alpha_to[] contains j=alpha^i;
 *   polynomial form -> index form:	index_of[j=alpha^i] = i
 *
 * alpha=2 is the primitive element of GF(2**m)
 */
{
	register int i, mask;

	mask = 1;
	pbch->alpha_to[pbch->m] = 0;
	for (i = 0; i < pbch->m; i++) {
		pbch->alpha_to[i] = mask;
		pbch->index_of[pbch->alpha_to[i]] = i;
		if (pbch->p[i] != 0)
			pbch->alpha_to[pbch->m] ^= mask;
		mask <<= 1;
	}
	pbch->index_of[pbch->alpha_to[pbch->m]] = pbch->m;
	mask >>= 1;
	for (i = pbch->m + 1; i < pbch->n; i++) {
		if (pbch->alpha_to[i - 1] >= mask)
		  pbch->alpha_to[i] = pbch->alpha_to[pbch->m] ^ ((pbch->alpha_to[i - 1] ^ mask) << 1);
		else
		  pbch->alpha_to[i] = pbch->alpha_to[i - 1] << 1;
		pbch->index_of[pbch->alpha_to[i]] = i;
	}
	pbch->index_of[0] = -1;
}


void
gen_poly(struct bch_code* pbch)
/*
 * Compute the generator polynomial of a binary BCH code. Fist generate the
 * cycle sets modulo 2**m - 1, cycle[][] =  (i, 2*i, 4*i, ..., 2^l*i). Then
 * determine those cycle sets that contain integers in the set of (d-1)
 * consecutive integers {1..(d-1)}. The generator polynomial is calculated
 * as the product of linear factors of the form (x+alpha^i), for every i in
 * the above cycle sets.
 */
{
	register int	ii, jj, ll, kaux;
	register int	test, aux, nocycles, root, noterms, rdncy;
	int             cycle[1024][21], size[1024], min[1024], zeros[1024];

	/* Generate cycle sets modulo n, n = 2**m - 1 */
	cycle[0][0] = 0;
	size[0] = 1;
	cycle[1][0] = 1;
	size[1] = 1;
	jj = 1;			/* cycle set index */
	if (pbch->m > 9)  {
		printf("Computing cycle sets modulo %d\n", pbch->n);
		printf("(This may take some time)...\n");
	}
	do {
		/* Generate the jj-th cycle set */
		ii = 0;
		do {
			ii++;
			cycle[jj][ii] = (cycle[jj][ii - 1] * 2) % pbch->n;
			size[jj]++;
			aux = (cycle[jj][ii] * 2) % pbch->n;
		} while (aux != cycle[jj][0]);
		/* Next cycle set representative */
		ll = 0;
		do {
			ll++;
			test = 0;
			for (ii = 1; ((ii <= jj) && (!test)); ii++)
			/* Examine previous cycle sets */
			  for (kaux = 0; ((kaux < size[ii]) && (!test)); kaux++)
			     if (ll == cycle[ii][kaux])
			        test = 1;
		} while ((test) && (ll < (pbch->n - 1)));
		if (!(test)) {
			jj++;	/* next cycle set index */
			cycle[jj][0] = ll;
			size[jj] = 1;
		}
	} while (ll < (pbch->n - 1));
	nocycles = jj;		/* number of cycle sets modulo n */

	pbch->d = 2 * pbch->t + 1;

	/* Search for roots 1, 2, ..., d-1 in cycle sets */
	kaux = 0;
	rdncy = 0;
	for (ii = 1; ii <= nocycles; ii++) {
		min[kaux] = 0;
		test = 0;
		for (jj = 0; ((jj < size[ii]) && (!test)); jj++)
			for (root = 1; ((root < pbch->d) && (!test)); root++)
				if (root == cycle[ii][jj])  {
					test = 1;
					min[kaux] = ii;
				}
		if (min[kaux]) {
			rdncy += size[min[kaux]];
			kaux++;
		}
	}
	noterms = kaux;
	kaux = 1;
	for (ii = 0; ii < noterms; ii++)
		for (jj = 0; jj < size[min[ii]]; jj++) {
			zeros[kaux] = cycle[min[ii]][jj];
			kaux++;
		}

	pbch->k = pbch->length - rdncy;//the length of message

    if (pbch->k<0)
    {
        printf("Parameters invalid!\n");
        exit(0);
    }
#ifdef TEST
	printf("This is a (%d, %d, %d) binary BCH code\n", pbch->length, pbch->k, pbch->d);
#endif // TEST

	/* Compute the generator polynomial */
	pbch->g[0] = pbch->alpha_to[zeros[1]];
	pbch->g[1] = 1;		/* g(x) = (X + zeros[1]) initially */
	for (ii = 2; ii <= rdncy; ii++) {
        pbch->g[ii] = 1;
        for (jj = ii - 1; jj > 0; jj--)
            if (pbch->g[jj] != 0)
                pbch->g[jj] = pbch->g[jj - 1] ^ pbch->alpha_to[(pbch->index_of[pbch->g[jj]] + zeros[ii]) % pbch->n];
            else
                pbch->g[jj] = pbch->g[jj - 1];
            pbch->g[0] = pbch->alpha_to[(pbch->index_of[pbch->g[0]] + zeros[ii]) % pbch->n];
	}
#ifdef TEST
	printf("Generator polynomial:\ng(x) = ");
	for (ii = 0; ii <= rdncy; ii++) {
        printf("%d", pbch->g[ii]);
        if (ii && ((ii % 50) == 0))
            printf("\n");
	}
	printf("\n");
#endif // TEST
}



void
encode_bch(struct bch_code* pbch, int* data, int* data_code)
/*
 * Compute redundacy bb[], the coefficients of b(x). The redundancy
 * polynomial b(x) is the remainder after dividing x^(length-k)*data(x)
 * by the generator polynomial g(x).
 */
{
	register int    i, j;
	register int    feedback;

	for (i = 0; i < pbch->length - pbch->k; i++)
		pbch->bb[i] = 0;
	for (i = pbch->k - 1; i >= 0; i--) {
		feedback = data[i] ^ pbch->bb[pbch->length - pbch->k - 1];
		if (feedback != 0) {
			for (j = pbch->length - pbch->k - 1; j > 0; j--)
				if (pbch->g[j] != 0)
					pbch->bb[j] = pbch->bb[j - 1] ^ feedback;
				else
					pbch->bb[j] = pbch->bb[j - 1];
			pbch->bb[0] = pbch->g[0] && feedback;
		} else {
			for (j = pbch->length - pbch->k - 1; j > 0; j--)
				pbch->bb[j] = pbch->bb[j - 1];
			pbch->bb[0] = 0;
		}
	}

	for (i = 0; i < pbch->length - pbch->k; i++)
		data_code[i] = pbch->bb[i];
	for (i = 0; i < pbch->k; i++)
		data_code[i + pbch->length - pbch->k] = data[i];

}


void
decode_bch(struct bch_code* pbch, int* received_code,int* recovered_data)
/*
 * Simon Rockliff's implementation of Berlekamp's algorithm.
 *
 * Assume we have received bits in recd[i], i=0..(n-1).
 *
 * Compute the 2*t syndromes by substituting alpha^i into rec(X) and
 * evaluating, storing the syndromes in s[i], i=1..2t (leave s[0] zero) .
 * Then we use the Berlekamp algorithm to find the error location polynomial
 * elp[i].
 *
 * If the degree of the elp is >t, then we cannot correct all the errors, and
 * we have detected an uncorrectable error pattern. We output the information
 * bits uncorrected.
 *
 * If the degree of elp is <=t, we substitute alpha^i , i=1..n into the elp
 * to get the roots, hence the inverse roots, the error location numbers.
 * This step is usually called "Chien's search".
 *
 * If the number of errors located is not equal the degree of the elp, then
 * the decoder assumes that there are more than t errors and cannot correct
 * them, only detect them. We output the information bits uncorrected.
 */
{
	int i, j, u, q, t2;
	int count = 0;
	int syn_error = 0;
    int d[1026], l[1026], u_lu[1026], s[1025];
	int elp[512][512];
	int root[512], loc[512], err[1024], reg[512];

	t2 = 2 * pbch->t;
    for (i = pbch->length - pbch->k; i < pbch->length; i++)
		recovered_data[i-pbch->length + pbch->k]=received_code[i];
	/* first form the syndromes */
#ifdef TEST
	printf("S(x) = ");
#endif // TEST
	for (i = 1; i <= t2; i++) {
		s[i] = 0;
		for (j = 0; j < pbch->length; j++)
			if (received_code[j] != 0)
				s[i] ^= pbch->alpha_to[(i * j) % pbch->n];
		if (s[i] != 0)
			syn_error = 1; /* set error flag if non-zero syndrome */
/*
 * Note:    If the code is used only for ERROR DETECTION, then
 *          exit program here indicating the presence of errors.
 */
		/* convert syndrome from polynomial form to index form  */
		s[i] = pbch->index_of[s[i]];
#ifdef TEST
		printf("%3d ", s[i]);
#endif // TEST
	}

#ifdef TEST
	printf("\n");
#endif // TEST

	if (syn_error) {	/* if there are errors, try to correct them */
		/*
		 * Compute the error location polynomial via the Berlekamp
		 * iterative algorithm. Following the terminology of Lin and
		 * Costello's book :   d[u] is the 'mu'th discrepancy, where
		 * u='mu'+1 and 'mu' (the Greek letter!) is the step number
		 * ranging from -1 to 2*t (see L&C),  l[u] is the degree of
		 * the elp at that step, and u_l[u] is the difference between
		 * the step number and the degree of the elp.
		 */
		/* initialise table entries */
		d[0] = 0;			/* index form */
		d[1] = s[1];		/* index form */
		elp[0][0] = 0;		/* index form */
		elp[1][0] = 1;		/* polynomial form */
		for (i = 1; i < t2; i++) {
			elp[0][i] = -1;	/* index form */
			elp[1][i] = 0;	/* polynomial form */
		}
		l[0] = 0;
		l[1] = 0;
		u_lu[0] = -1;
		u_lu[1] = 0;
		u = 0;

		do {
			u++;
			if (d[u] == -1) {
				l[u + 1] = l[u];
				for (i = 0; i <= l[u]; i++) {
					elp[u + 1][i] = elp[u][i];
					elp[u][i] = pbch->index_of[elp[u][i]];
				}
			} else
				/*
				 * search for words with greatest u_lu[q] for
				 * which d[q]!=0
				 */
			{
				q = u - 1;
				while ((d[q] == -1) && (q > 0))
					q--;
				/* have found first non-zero d[q]  */
				if (q > 0) {
                    j = q;
                    do {
                        j--;
                        if ((d[j] != -1) && (u_lu[q] < u_lu[j]))
                            q = j;
                    } while (j > 0);
				}

				/*
				 * have now found q such that d[u]!=0 and
				 * u_lu[q] is maximum
				 */
				/* store degree of new elp polynomial */
				if (l[u] > l[q] + u - q)
					l[u + 1] = l[u];
				else
					l[u + 1] = l[q] + u - q;

				/* form new elp(x) */
				for (i = 0; i < t2; i++)
					elp[u + 1][i] = 0;
				for (i = 0; i <= l[q]; i++)
					if (elp[q][i] != -1)
						elp[u + 1][i + u - q] =
                                   pbch->alpha_to[(d[u] + pbch->n - d[q] + elp[q][i]) % pbch->n];
				for (i = 0; i <= l[u]; i++) {
					elp[u + 1][i] ^= elp[u][i];
					elp[u][i] = pbch->index_of[elp[u][i]];
				}
			}
			u_lu[u + 1] = u - l[u + 1];

			/* form (u+1)th discrepancy */
			if (u < t2) {
			/* no discrepancy computed on last iteration */
                if (s[u + 1] != -1)
                    d[u + 1] = pbch->alpha_to[s[u + 1]];
                else
                    d[u + 1] = 0;
			    for (i = 1; i <= l[u + 1]; i++)
                    if ((s[u + 1 - i] != -1) && (elp[u + 1][i] != 0))
                        d[u + 1] ^= pbch->alpha_to[(s[u + 1 - i]
			                      + pbch->index_of[elp[u + 1][i]]) % pbch->n];
			  /* put d[u+1] into index form */
                d[u + 1] = pbch->index_of[d[u + 1]];
            }
		} while ((u < t2) && (l[u + 1] <= pbch->t));

		u++;
		if (l[u] <= pbch->t) {/* Can correct errors */
			/* put elp into index form */
			for (i = 0; i <= l[u]; i++)
				elp[u][i] = pbch->index_of[elp[u][i]];
#ifdef TEST
			printf("sigma(x) = ");
			for (i = 0; i <= l[u]; i++)
				printf("%3d ", elp[u][i]);
			printf("\n");
			printf("Roots: ");
#endif // TEST
			/* Chien search: find roots of the error location polynomial */
			for (i = 1; i <= l[u]; i++)
				reg[i] = elp[u][i];
			count = 0;
			for (i = 1; i <= pbch->n; i++) {
				q = 1;
				for (j = 1; j <= l[u]; j++)
					if (reg[j] != -1) {
						reg[j] = (reg[j] + j) % pbch->n;
						q ^= pbch->alpha_to[reg[j]];
					}
				if (!q) {	/* store root and error
						 * location number indices */
					root[count] = i;
					loc[count] = pbch->n - i;
					count++;
#ifdef TEST
					printf("%3d ", pbch->n - i);
#endif // TEST
				}
			}
#ifdef TEST
			printf("\n");
#endif // TEST
			if (count == l[u]){
			/* no. roots = degree of elp hence <= t errors */
				for (i = 0; i < l[u]; i++)
                    if(loc[i]>=(pbch->length - pbch->k))
                        recovered_data[loc[i]-pbch->length + pbch->k]=received_code[loc[i]] ^ 1;
			}else	/* elp has degree >t hence cannot solve */
				printf("Incomplete decoding: errors detected\n");
		}
	}
}


/*the end of bch_code part*/



/*the aes part*/

// #define the macros below to 1/0 to enable/disable the mode of operation.
//
// CBC enables AES encryption in CBC-mode of operation.
// CTR enables encryption in counter-mode.
// ECB enables the basic ECB 16-byte block algorithm. All can be enabled simultaneously.

// The #ifndef-guard allows it to be configured before #include'ing or at compile time.
#ifndef CBC
  #define CBC 1
#endif

#ifndef ECB
  #define ECB 1
#endif

#ifndef CTR
  #define CTR 1
#endif

#define AES128 1

#define AES_BLOCKLEN 16 //Block length in bytes AES is 128b block only

#if defined(AES256) && (AES256 == 1)
    #define AES_KEYLEN 32
    #define AES_keyExpSize 240
#elif defined(AES192) && (AES192 == 1)
    #define AES_KEYLEN 24
    #define AES_keyExpSize 208
#else
    #define AES_KEYLEN 16   // Key length in bytes
    #define AES_keyExpSize 176
#endif

struct AES_ctx
{
  uint8_t RoundKey[AES_keyExpSize];
#if (defined(CBC) && (CBC == 1)) || (defined(CTR) && (CTR == 1))
  uint8_t Iv[AES_BLOCKLEN];
#endif
};

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key);
#if (defined(CBC) && (CBC == 1)) || (defined(CTR) && (CTR == 1))
void AES_init_ctx_iv(struct AES_ctx* ctx, const uint8_t* key, const uint8_t* iv);
void AES_ctx_set_iv(struct AES_ctx* ctx, const uint8_t* iv);
#endif

#if defined(ECB) && (ECB == 1)
// buffer size is exactly AES_BLOCKLEN bytes;
// you need only AES_init_ctx as IV is not used in ECB
// NB: ECB is considered insecure for most uses
void AES_ECB_encrypt(struct AES_ctx* ctx, uint8_t* buf);
void AES_ECB_decrypt(struct AES_ctx* ctx, uint8_t* buf);

#endif // #if defined(ECB) && (ECB == !)


#if defined(CBC) && (CBC == 1)
// buffer size MUST be mutile of AES_BLOCKLEN;
// Suggest https://en.wikipedia.org/wiki/Padding_(cryptography)#PKCS7 for padding scheme
// NOTES: you need to set IV in ctx via AES_init_ctx_iv() or AES_ctx_set_iv()
//        no IV should ever be reused with the same key
void AES_CBC_encrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);
void AES_CBC_decrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);

#endif // #if defined(CBC) && (CBC == 1)


#if defined(CTR) && (CTR == 1)

// Same function for encrypting as for decrypting.
// IV is incremented for every block, and used after encryption as XOR-compliment for output
// Suggesting https://en.wikipedia.org/wiki/Padding_(cryptography)#PKCS7 for padding scheme
// NOTES: you need to set IV in ctx with AES_init_ctx_iv() or AES_ctx_set_iv()
//        no IV should ever be reused with the same key
void AES_CTR_xcrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);

#endif // #if defined(CTR) && (CTR == 1)

/*

This is an implementation of the AES algorithm, specifically ECB, CTR and CBC mode.
Available choices for block size are AES128, AES192, AES256.

The implementation is verified against the test vectors in:
  National Institute of Standards and Technology Special Publication 800-38A 2001 ED

ECB-AES128
----------

  plain-text:
    6bc1bee22e409f96e93d7e117393172a
    ae2d8a571e03ac9c9eb76fac45af8e51
    30c81c46a35ce411e5fbc1191a0a52ef
    f69f2445df4f9b17ad2b417be66c3710

  key:
    2b7e151628aed2a6abf7158809cf4f3c

  resulting cipher
    3ad77bb40d7a3660a89ecaf32466ef97
    f5d3d58503b9699de785895a96fdbaaf
    43b1cd7f598ece23881b00e3ed030688
    7b0c785e27e8ad3f8223207104725dd4


NOTE:   String length must be evenly divisible by 16byte (str_len % 16 == 0)
        You should pad the end of the string with zeros if this is not the case.
        For AES192/256 the key size is proportionally larger.

*/

/*****************************************************************************/
/* Defines:                                                                  */
/*****************************************************************************/
// The number of columns comprising a state in AES. This is a constant in AES. Value=4
#define Nb 4

#if defined(AES256) && (AES256 == 1)
    #define Nk 8
    #define Nr 14
#elif defined(AES192) && (AES192 == 1)
    #define Nk 6
    #define Nr 12
#else
    #define Nk 4        // The number of 32 bit words in a key.
    #define Nr 10       // The number of rounds in AES Cipher.
#endif

// jcallan@github points out that declaring Multiply as a function
// reduces code size considerably with the Keil ARM compiler.
// See this link for more information: https://github.com/kokke/tiny-AES-C/pull/3
#ifndef MULTIPLY_AS_A_FUNCTION
  #define MULTIPLY_AS_A_FUNCTION 0
#endif




/*****************************************************************************/
/* Private variables:                                                        */
/*****************************************************************************/
// state - array holding the intermediate results during decryption.
typedef uint8_t state_t[4][4];



// The lookup-tables are marked const so they can be placed in read-only storage instead of RAM
// The numbers below can be computed dynamically trading ROM for RAM -
// This can be useful in (embedded) bootloader applications, where ROM is often limited.
static const uint8_t sbox[256] = {
  //0     1    2      3     4    5     6     7      8    9     A      B    C     D     E     F
  0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
  0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
  0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
  0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
  0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
  0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
  0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
  0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
  0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
  0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
  0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
  0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
  0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
  0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
  0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
  0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16 };

static const uint8_t rsbox[256] = {
  0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
  0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
  0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
  0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
  0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
  0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
  0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
  0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
  0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
  0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
  0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
  0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
  0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
  0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
  0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
  0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d };

// The round constant word array, Rcon[i], contains the values given by
// x to the power (i-1) being powers of x (x is denoted as {02}) in the field GF(2^8)
static const uint8_t Rcon[11] = {
  0x8d, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36 };

/*
 * Jordan Goulder points out in PR #12 (https://github.com/kokke/tiny-AES-C/pull/12),
 * that you can remove most of the elements in the Rcon array, because they are unused.
 *
 * From Wikipedia's article on the Rijndael key schedule @ https://en.wikipedia.org/wiki/Rijndael_key_schedule#Rcon
 *
 * "Only the first some of these constants are actually used �?up to rcon[10] for AES-128 (as 11 round keys are needed),
 *  up to rcon[8] for AES-192, up to rcon[7] for AES-256. rcon[0] is not used in AES algorithm."
 */


/*****************************************************************************/
/* Private functions:                                                        */
/*****************************************************************************/
/*
static uint8_t getSBoxValue(uint8_t num)
{
  return sbox[num];
}
*/
#define getSBoxValue(num) (sbox[(num)])
/*
static uint8_t getSBoxInvert(uint8_t num)
{
  return rsbox[num];
}
*/
#define getSBoxInvert(num) (rsbox[(num)])

// This function produces Nb(Nr+1) round keys. The round keys are used in each round to decrypt the states.
static void KeyExpansion(uint8_t* RoundKey, const uint8_t* Key)
{
  unsigned i, j, k;
  uint8_t tempa[4]; // Used for the column/row operations

  // The first round key is the key itself.
  for (i = 0; i < Nk; ++i)
  {
    RoundKey[(i * 4) + 0] = Key[(i * 4) + 0];
    RoundKey[(i * 4) + 1] = Key[(i * 4) + 1];
    RoundKey[(i * 4) + 2] = Key[(i * 4) + 2];
    RoundKey[(i * 4) + 3] = Key[(i * 4) + 3];
  }

  // All other round keys are found from the previous round keys.
  for (i = Nk; i < Nb * (Nr + 1); ++i)
  {
    {
      k = (i - 1) * 4;
      tempa[0]=RoundKey[k + 0];
      tempa[1]=RoundKey[k + 1];
      tempa[2]=RoundKey[k + 2];
      tempa[3]=RoundKey[k + 3];

    }

    if (i % Nk == 0)
    {
      // This function shifts the 4 bytes in a word to the left once.
      // [a0,a1,a2,a3] becomes [a1,a2,a3,a0]

      // Function RotWord()
      {
        const uint8_t u8tmp = tempa[0];
        tempa[0] = tempa[1];
        tempa[1] = tempa[2];
        tempa[2] = tempa[3];
        tempa[3] = u8tmp;
      }

      // SubWord() is a function that takes a four-byte input word and
      // applies the S-box to each of the four bytes to produce an output word.

      // Function Subword()
      {
        tempa[0] = getSBoxValue(tempa[0]);
        tempa[1] = getSBoxValue(tempa[1]);
        tempa[2] = getSBoxValue(tempa[2]);
        tempa[3] = getSBoxValue(tempa[3]);
      }

      tempa[0] = tempa[0] ^ Rcon[i/Nk];
    }
#if defined(AES256) && (AES256 == 1)
    if (i % Nk == 4)
    {
      // Function Subword()
      {
        tempa[0] = getSBoxValue(tempa[0]);
        tempa[1] = getSBoxValue(tempa[1]);
        tempa[2] = getSBoxValue(tempa[2]);
        tempa[3] = getSBoxValue(tempa[3]);
      }
    }
#endif
    j = i * 4; k=(i - Nk) * 4;
    RoundKey[j + 0] = RoundKey[k + 0] ^ tempa[0];
    RoundKey[j + 1] = RoundKey[k + 1] ^ tempa[1];
    RoundKey[j + 2] = RoundKey[k + 2] ^ tempa[2];
    RoundKey[j + 3] = RoundKey[k + 3] ^ tempa[3];
  }
}

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key)
{
  KeyExpansion(ctx->RoundKey, key);
}
#if (defined(CBC) && (CBC == 1)) || (defined(CTR) && (CTR == 1))
void AES_init_ctx_iv(struct AES_ctx* ctx, const uint8_t* key, const uint8_t* iv)
{
  KeyExpansion(ctx->RoundKey, key);
  memcpy (ctx->Iv, iv, AES_BLOCKLEN);
}
void AES_ctx_set_iv(struct AES_ctx* ctx, const uint8_t* iv)
{
  memcpy (ctx->Iv, iv, AES_BLOCKLEN);
}
#endif

// This function adds the round key to state.
// The round key is added to the state by an XOR function.
static void AddRoundKey(uint8_t round,state_t* state,uint8_t* RoundKey)
{
  uint8_t i,j;
  for (i = 0; i < 4; ++i)
  {
    for (j = 0; j < 4; ++j)
    {
      (*state)[i][j] ^= RoundKey[(round * Nb * 4) + (i * Nb) + j];
    }
  }
}

// The SubBytes Function Substitutes the values in the
// state matrix with values in an S-box.
static void SubBytes(state_t* state)
{
  uint8_t i, j;
  for (i = 0; i < 4; ++i)
  {
    for (j = 0; j < 4; ++j)
    {
      (*state)[j][i] = getSBoxValue((*state)[j][i]);
    }
  }
}

// The ShiftRows() function shifts the rows in the state to the left.
// Each row is shifted with different offset.
// Offset = Row number. So the first row is not shifted.
static void ShiftRows(state_t* state)
{
  uint8_t temp;

  // Rotate first row 1 columns to left
  temp           = (*state)[0][1];
  (*state)[0][1] = (*state)[1][1];
  (*state)[1][1] = (*state)[2][1];
  (*state)[2][1] = (*state)[3][1];
  (*state)[3][1] = temp;

  // Rotate second row 2 columns to left
  temp           = (*state)[0][2];
  (*state)[0][2] = (*state)[2][2];
  (*state)[2][2] = temp;

  temp           = (*state)[1][2];
  (*state)[1][2] = (*state)[3][2];
  (*state)[3][2] = temp;

  // Rotate third row 3 columns to left
  temp           = (*state)[0][3];
  (*state)[0][3] = (*state)[3][3];
  (*state)[3][3] = (*state)[2][3];
  (*state)[2][3] = (*state)[1][3];
  (*state)[1][3] = temp;
}

static uint8_t xtime(uint8_t x)
{
  return ((x<<1) ^ (((x>>7) & 1) * 0x1b));
}

// MixColumns function mixes the columns of the state matrix
static void MixColumns(state_t* state)
{
  uint8_t i;
  uint8_t Tmp, Tm, t;
  for (i = 0; i < 4; ++i)
  {
    t   = (*state)[i][0];
    Tmp = (*state)[i][0] ^ (*state)[i][1] ^ (*state)[i][2] ^ (*state)[i][3] ;
    Tm  = (*state)[i][0] ^ (*state)[i][1] ; Tm = xtime(Tm);  (*state)[i][0] ^= Tm ^ Tmp ;
    Tm  = (*state)[i][1] ^ (*state)[i][2] ; Tm = xtime(Tm);  (*state)[i][1] ^= Tm ^ Tmp ;
    Tm  = (*state)[i][2] ^ (*state)[i][3] ; Tm = xtime(Tm);  (*state)[i][2] ^= Tm ^ Tmp ;
    Tm  = (*state)[i][3] ^ t ;              Tm = xtime(Tm);  (*state)[i][3] ^= Tm ^ Tmp ;
  }
}

// Multiply is used to multiply numbers in the field GF(2^8)
// Note: The last call to xtime() is unneeded, but often ends up generating a smaller binary
//       The compiler seems to be able to vectorize the operation better this way.
//       See https://github.com/kokke/tiny-AES-c/pull/34
#if MULTIPLY_AS_A_FUNCTION
static uint8_t Multiply(uint8_t x, uint8_t y)
{
  return (((y & 1) * x) ^
       ((y>>1 & 1) * xtime(x)) ^
       ((y>>2 & 1) * xtime(xtime(x))) ^
       ((y>>3 & 1) * xtime(xtime(xtime(x)))) ^
       ((y>>4 & 1) * xtime(xtime(xtime(xtime(x)))))); /* this last call to xtime() can be omitted */
  }
#else
#define Multiply(x, y)                                \
      (  ((y & 1) * x) ^                              \
      ((y>>1 & 1) * xtime(x)) ^                       \
      ((y>>2 & 1) * xtime(xtime(x))) ^                \
      ((y>>3 & 1) * xtime(xtime(xtime(x)))) ^         \
      ((y>>4 & 1) * xtime(xtime(xtime(xtime(x))))))   \

#endif

// MixColumns function mixes the columns of the state matrix.
// The method used to multiply may be difficult to understand for the inexperienced.
// Please use the references to gain more information.
static void InvMixColumns(state_t* state)
{
  int i;
  uint8_t a, b, c, d;
  for (i = 0; i < 4; ++i)
  {
    a = (*state)[i][0];
    b = (*state)[i][1];
    c = (*state)[i][2];
    d = (*state)[i][3];

    (*state)[i][0] = Multiply(a, 0x0e) ^ Multiply(b, 0x0b) ^ Multiply(c, 0x0d) ^ Multiply(d, 0x09);
    (*state)[i][1] = Multiply(a, 0x09) ^ Multiply(b, 0x0e) ^ Multiply(c, 0x0b) ^ Multiply(d, 0x0d);
    (*state)[i][2] = Multiply(a, 0x0d) ^ Multiply(b, 0x09) ^ Multiply(c, 0x0e) ^ Multiply(d, 0x0b);
    (*state)[i][3] = Multiply(a, 0x0b) ^ Multiply(b, 0x0d) ^ Multiply(c, 0x09) ^ Multiply(d, 0x0e);
  }
}


// The SubBytes Function Substitutes the values in the
// state matrix with values in an S-box.
static void InvSubBytes(state_t* state)
{
  uint8_t i, j;
  for (i = 0; i < 4; ++i)
  {
    for (j = 0; j < 4; ++j)
    {
      (*state)[j][i] = getSBoxInvert((*state)[j][i]);
    }
  }
}

static void InvShiftRows(state_t* state)
{
  uint8_t temp;

  // Rotate first row 1 columns to right
  temp = (*state)[3][1];
  (*state)[3][1] = (*state)[2][1];
  (*state)[2][1] = (*state)[1][1];
  (*state)[1][1] = (*state)[0][1];
  (*state)[0][1] = temp;

  // Rotate second row 2 columns to right
  temp = (*state)[0][2];
  (*state)[0][2] = (*state)[2][2];
  (*state)[2][2] = temp;

  temp = (*state)[1][2];
  (*state)[1][2] = (*state)[3][2];
  (*state)[3][2] = temp;

  // Rotate third row 3 columns to right
  temp = (*state)[0][3];
  (*state)[0][3] = (*state)[1][3];
  (*state)[1][3] = (*state)[2][3];
  (*state)[2][3] = (*state)[3][3];
  (*state)[3][3] = temp;
}


// Cipher is the main function that encrypts the PlainText.
static void Cipher(state_t* state, uint8_t* RoundKey)
{
  uint8_t round = 0;

  // Add the First round key to the state before starting the rounds.
  AddRoundKey(0, state, RoundKey);

  // There will be Nr rounds.
  // The first Nr-1 rounds are identical.
  // These Nr-1 rounds are executed in the loop below.
  for (round = 1; round < Nr; ++round)
  {
    SubBytes(state);
    ShiftRows(state);
    MixColumns(state);
    AddRoundKey(round, state, RoundKey);
  }

  // The last round is given below.
  // The MixColumns function is not here in the last round.
  SubBytes(state);
  ShiftRows(state);
  AddRoundKey(Nr, state, RoundKey);
}

static void InvCipher(state_t* state,uint8_t* RoundKey)
{
  uint8_t round = 0;

  // Add the First round key to the state before starting the rounds.
  AddRoundKey(Nr, state, RoundKey);

  // There will be Nr rounds.
  // The first Nr-1 rounds are identical.
  // These Nr-1 rounds are executed in the loop below.
  for (round = (Nr - 1); round > 0; --round)
  {
    InvShiftRows(state);
    InvSubBytes(state);
    AddRoundKey(round, state, RoundKey);
    InvMixColumns(state);
  }

  // The last round is given below.
  // The MixColumns function is not here in the last round.
  InvShiftRows(state);
  InvSubBytes(state);
  AddRoundKey(0, state, RoundKey);
}


/*****************************************************************************/
/* Public functions:                                                         */
/*****************************************************************************/
#if defined(ECB) && (ECB == 1)


void AES_ECB_encrypt(struct AES_ctx *ctx, uint8_t* buf)
{
  // The next function call encrypts the PlainText with the Key using AES algorithm.
  Cipher((state_t*)buf, ctx->RoundKey);
}

void AES_ECB_decrypt(struct AES_ctx* ctx, uint8_t* buf)
{
  // The next function call decrypts the PlainText with the Key using AES algorithm.
    InvCipher((state_t*)buf, ctx->RoundKey);
}


#endif // #if defined(ECB) && (ECB == 1)





#if defined(CBC) && (CBC == 1)


static void XorWithIv(uint8_t* buf, uint8_t* Iv)
{
    uint8_t i;
    for (i = 0; i < AES_BLOCKLEN; ++i) // The block in AES is always 128bit no matter the key size
    {
        buf[i] ^= Iv[i];
    }
}

void AES_CBC_encrypt_buffer(struct AES_ctx *ctx,uint8_t* buf, uint32_t length)
{
    uintptr_t i;
    uint8_t *Iv = ctx->Iv;
      for (i = 0; i < length; i += AES_BLOCKLEN)
      {
        XorWithIv(buf, Iv);
        Cipher((state_t*)buf, ctx->RoundKey);
        Iv = buf;
        buf += AES_BLOCKLEN;
        //printf("Step %d - %d", i/16, i);
      }
      /* store Iv in ctx for next call */
      memcpy(ctx->Iv, Iv, AES_BLOCKLEN);
}

void AES_CBC_decrypt_buffer(struct AES_ctx* ctx, uint8_t* buf,  uint32_t length)
{
    uintptr_t i;
    uint8_t storeNextIv[AES_BLOCKLEN];
    for (i = 0; i < length; i += AES_BLOCKLEN)
    {
        memcpy(storeNextIv, buf, AES_BLOCKLEN);
        InvCipher((state_t*)buf, ctx->RoundKey);
        XorWithIv(buf, ctx->Iv);
        memcpy(ctx->Iv, storeNextIv, AES_BLOCKLEN);
        buf += AES_BLOCKLEN;
    }
}

#endif // #if defined(CBC) && (CBC == 1)



#if defined(CTR) && (CTR == 1)

/* Symmetrical operation: same function for encrypting as for decrypting. Note any IV/nonce should never be reused with the same key */
void AES_CTR_xcrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length)
{
    uint8_t buffer[AES_BLOCKLEN];

    unsigned i;
    int bi;
    for (i = 0, bi = AES_BLOCKLEN; i < length; ++i, ++bi)
    {
        if (bi == AES_BLOCKLEN) /* we need to regen xor compliment in buffer */
        {
            memcpy(buffer, ctx->Iv, AES_BLOCKLEN);
            Cipher((state_t*)buffer,ctx->RoundKey);

    /* Increment Iv and handle overflow */
            for (bi = (AES_BLOCKLEN - 1); bi >= 0; --bi)
            {
	/* inc will owerflow */
                if (ctx->Iv[bi] == 255)
                {
                    ctx->Iv[bi] = 0;
                    continue;
                }
                ctx->Iv[bi] += 1;
                break;
            }
            bi = 0;
        }
        buf[i] = (buf[i] ^ buffer[bi]);
    }
}

#endif // #if defined(CTR) && (CTR == 1)


// Enable ECB, CTR and CBC mode. Note this can be done before including aes.h or at compile-time.
// E.g. with GCC by using the -D flag: gcc -c aes.c -DCBC=0 -DCTR=1 -DECB=1
#define CBC 1
#define CTR 1
#define ECB 1

static void phex(uint8_t* str);

int test_bf();
static int test_encrypt_ecb();
static int test_decrypt_ecb();
int test_bch_code();
int test_bernoulli();

int main(void)
{
    int exit;

#if defined(AES256)
    printf("\nTesting AES256\n\n");
#elif defined(AES192)
    printf("\nTesting AES192\n\n");
#elif defined(AES128)
    printf("\nTesting AES128\n\n");
#else
    printf("You need to specify a symbol between AES128, AES192 or AES256. Exiting");
    return 0;
#endif

    exit = test_encrypt_ecb() + test_decrypt_ecb() + test_bch_code()+test_bernoulli();

    return exit;
}


int test_bernoulli()
{
    ZZ randombits;//��һ��������һ��ZZ �������������洢�������

    int len=DIMENSION;//�ڶ��������屴Ŭ���ֲ��ı�����Ŀ��������
    int precesion=30;//����������������ľ���
    double p_2=(double)1.0/(sqrt(1000*len));//���Ĳ�����������������

    int i, izerovector;

    struct bernoulli_distribution bd;//���岽������һ����Ŭ���ֲ�����

    init_bernoulli(&bd, p_2,len,precision);//����������ʼ����Ŭ���ֲ�����

    izerovector=sample_bernoulli(&bd);//���߲�������һ������ı�Ŭ����������һ�ַ�����

    for(i=0;i<bd.length;i++)
        printf("%d",&bd.berbits[i]);
    printf("\n");

    RandomBits(randombits,3*DIMENSION);//�ڰ˲���������Ŭ���������������
    izerovector=sample_bernoulli_wsrb(&bd,randombits);//�ھŲ�������һ������ı�Ŭ���������ڶ��ַ�����


    for(i=0;i<bd.length;i++)
        printf("%d",&bd.berbits[i]);
    printf("\n");

    int hw=0;
    int berbits[DIMENSION];//��ʮ����������ձ�Ŭ�����������飻
    RandomBits(randombits,3*DIMENSION);//��ʮһ����������Ŭ���������������
    izerovector=bernoulli_Sample_DDG(p_2,randombits,berbits,len,precesion,&hw);//��ʮ����������һ������ı�Ŭ�������������ַ�����

     for(i=0;i<len;i++)
        printf("%d",&berbits[i]);
    printf("\n");

    free_bernoilli(&bd);

    return 0;
}


// prints string as hex
static void phex(uint8_t* str)
{

#if defined(AES256)
    uint8_t len = 32;
#elif defined(AES192)
    uint8_t len = 24;
#elif defined(AES128)
    uint8_t len = 16;
#endif

    unsigned char i;
    for (i = 0; i < len; ++i)
        printf("%.2x", str[i]);
    printf("\n");
}

static int test_encrypt_ecb()
{
    uint8_t i;

    // ��һ��������һ��128���ص���Կ
    uint8_t key[16] =        { (uint8_t) 0x2b, (uint8_t) 0x7e, (uint8_t) 0x15, (uint8_t) 0x16, (uint8_t) 0x28, (uint8_t) 0xae, (uint8_t) 0xd2, (uint8_t) 0xa6, (uint8_t) 0xab, (uint8_t) 0xf7, (uint8_t) 0x15, (uint8_t) 0x88, (uint8_t) 0x09, (uint8_t) 0xcf, (uint8_t) 0x4f, (uint8_t) 0x3c };
    // 5�ڶ���������һ���������飨���ַ������߶����Ʊ��ش���
    uint8_t plain_text[64] = { (uint8_t) 0x6b, (uint8_t) 0xc1, (uint8_t) 0xbe, (uint8_t) 0xe2, (uint8_t) 0x2e, (uint8_t) 0x40, (uint8_t) 0x9f, (uint8_t) 0x96, (uint8_t) 0xe9, (uint8_t) 0x3d, (uint8_t) 0x7e, (uint8_t) 0x11, (uint8_t) 0x73, (uint8_t) 0x93, (uint8_t) 0x17, (uint8_t) 0x2a,
                               (uint8_t) 0xae, (uint8_t) 0x2d, (uint8_t) 0x8a, (uint8_t) 0x57, (uint8_t) 0x1e, (uint8_t) 0x03, (uint8_t) 0xac, (uint8_t) 0x9c, (uint8_t) 0x9e, (uint8_t) 0xb7, (uint8_t) 0x6f, (uint8_t) 0xac, (uint8_t) 0x45, (uint8_t) 0xaf, (uint8_t) 0x8e, (uint8_t) 0x51,
                               (uint8_t) 0x30, (uint8_t) 0xc8, (uint8_t) 0x1c, (uint8_t) 0x46, (uint8_t) 0xa3, (uint8_t) 0x5c, (uint8_t) 0xe4, (uint8_t) 0x11, (uint8_t) 0xe5, (uint8_t) 0xfb, (uint8_t) 0xc1, (uint8_t) 0x19, (uint8_t) 0x1a, (uint8_t) 0x0a, (uint8_t) 0x52, (uint8_t) 0xef,
                               (uint8_t) 0xf6, (uint8_t) 0x9f, (uint8_t) 0x24, (uint8_t) 0x45, (uint8_t) 0xdf, (uint8_t) 0x4f, (uint8_t) 0x9b, (uint8_t) 0x17, (uint8_t) 0xad, (uint8_t) 0x2b, (uint8_t) 0x41, (uint8_t) 0x7b, (uint8_t) 0xe6, (uint8_t) 0x6c, (uint8_t) 0x37, (uint8_t) 0x10 };

    // print text to encrypt, key and IV
    printf("ECB encrypt verbose:\n\n");
    printf("plain text:\n");
    for (i = (uint8_t) 0; i < (uint8_t) 4; ++i)
    {
        phex(plain_text + i * (uint8_t) 16);
    }
    printf("\n");

    printf("key:\n");
    phex(key);
    printf("\n");

    // print the resulting cipher as 4 x 16 byte strings
    printf("ciphertext:\n");
    //������ ����һ��AES_ctx��������
    struct AES_ctx ctx;
    //���Ĳ�����ʼ�����ܻ���
    AES_init_ctx(&ctx, key);

    for (i = 0; i < 4; ++i)
    {
      AES_ECB_encrypt(&ctx, plain_text + (i * 16));//���岽�����ü��ܺ������ܣ����Ĵ�ص�plain_text��
      phex(plain_text + (i * 16));
    }
    printf("\n");

    return 1;
}




static int test_decrypt_ecb()
{
#if defined(AES256)
    uint8_t key[] = { 0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81,
                      0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4 };
    uint8_t in[]  = { 0xf3, 0xee, 0xd1, 0xbd, 0xb5, 0xd2, 0xa0, 0x3c, 0x06, 0x4b, 0x5a, 0x7e, 0x3d, 0xb1, 0x81, 0xf8 };
#elif defined(AES192)
    uint8_t key[] = { 0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5,
                      0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b };
    uint8_t in[]  = { 0xbd, 0x33, 0x4f, 0x1d, 0x6e, 0x45, 0xf2, 0x5f, 0xf7, 0x12, 0xa2, 0x14, 0x57, 0x1f, 0xa5, 0xcc };
#elif defined(AES128)
    uint8_t key[] = { 0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c };
    uint8_t in[]  = { 0x3a, 0xd7, 0x7b, 0xb4, 0x0d, 0x7a, 0x36, 0x60, 0xa8, 0x9e, 0xca, 0xf3, 0x24, 0x66, 0xef, 0x97 };
#endif

    uint8_t out[]   = { 0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a };
    struct AES_ctx ctx;

    AES_init_ctx(&ctx, key);
    AES_ECB_decrypt(&ctx, in);//�����������ý��ܺ�����������in������������in�С�

    printf("ECB decrypt: ");

    if (0 == memcmp((char*) out, (char*) in, 16)) {
        printf("SUCCESS!\n");
	return(0);
    } else {
        printf("FAILURE!\n");
	return 1;
    }
}


int test_bch_code()
{
	int  i,m,n,t;
	int numerr=0;
    int errpos[512];
    int* data_before_encoded = (int*) malloc(sizeof(int)*256);//��һ������ʼ������������ݱ������������飬����256
    int* data_after_decoded = (int*) malloc(sizeof(int)*256);//�ڶ�������ʼ�����ս������ݵı������������飬����256
    int* data_code = (int*) malloc(sizeof(int)*256);//�����������ձ������ݵı������������飬����256


    printf("Enter the parameters:\n");
    printf("m=");
	scanf("%d", &m);
	printf("code length n=");
	scanf("%d", &n);
	printf("error tolerance t=");
	scanf("%d", &t);

	struct bch_code bch_control;//���Ĳ�������һ��bch_code�ṹ���ͱ���
    init_bch(&bch_control,m,n,t);//���岽����ʼ��bch_code�������ͱ������ڽ��б���֮ǰ�������ȳ�ʼ���ñ�����

	for (i = 0; i < bch_control.k; i++)//��������װ�ر�������
		if(i%2==1)
            data_before_encoded[i] = 1;
        else
            data_before_encoded[i] = 0;

	encode_bch(&bch_control,data_before_encoded,data_code); //���߲�������

	printf("The Code is:\n");
	for (i = 0; i < bch_control.length; i++) {
		printf("%1d", data_code[i]);
		if (i && (((i+1) % 50) == 0))
			printf("\n");
	}
	printf("\n");

	printf("Enter the number of errors:\n");
	scanf("%d", &numerr);	/* CHANNEL errors */
    printf("Enter error locations (integers between");
    printf(" 0 and %d): ", bch_control.length-1);
	/*
	 * recd[] are the coefficients of r(x) = c(x) + e(x)
	 */
	for (i = 0; i < numerr; i++)
		scanf("%d", &errpos[i]);
	if (numerr)
		for (i = 0; i < numerr; i++)
			data_code[errpos[i]] ^= 1;
	printf("the received code = ");
	for (i = 0; i < bch_control.length; i++)
		printf("%1d", data_code[i]);

	printf("\n");

	decode_bch(&bch_control,data_code,data_after_decoded); //�ڰ˲�������

	/*
	 * print out original and decoded data
	 */
	printf("Results:\n");
	printf("original data  = ");
	for (i = 0; i < bch_control.k; i++)
		printf("%1d", data_before_encoded[i]);

	printf("\nrecovered data = ");
	for (i = 0; i < bch_control.k; i++)
		printf("%1d", data_after_decoded[i]);

	printf("\n");

    free(data_code);
    free(data_after_decoded);
    free(data_before_encoded);

    return 1;
}

int test_bf()
{
    struct set_bf sbf;//��һ��������һ��set_bf������
    unsigned long len=10000;//�ڶ�����ȷ������Ԫ�ظ�����hash����������
    int numofhash=20;
    unsigned char test[10];//������������һ������Ԫ�ر����������ͱ���Ϊunsigned char���飻
    unsigned int i,result;
    for(i=0;i<10;i++)//���Ĳ���������Ԫ�ظ�ֵ
        test[i]='A';

    init_set(&sbf,len,numofhash);//���岽����ʼ�����ڲ�¡�������ļ���


    for(i=0;i<sbf.pbf->numofblock;i++)
        printf("%d\n",sbf.pbf->bf_array[i]);
    printf("\n\n");

    insert_set(test,10,&sbf);//�����������뼯��Ԫ��

    for(i=0;i<sbf.pbf->numofblock;i++)
        printf("%d\n",sbf.pbf->bf_array[i]);
    printf("\n\n");

    result=query_set(test,10,&sbf);//���߲�����ѯ����Ԫ��

    printf("%d\n",result);

    return 0;
}
