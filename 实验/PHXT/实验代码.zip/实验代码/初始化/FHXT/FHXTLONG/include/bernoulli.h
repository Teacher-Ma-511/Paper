#ifndef BERNOULLI_H_INCLUDED
#define BERNOULLI_H_INCLUDED

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>

#include <NTL/ZZ.h>

using namespace std;
using namespace NTL;

#define DIMENSION 280
#define MAX_PRECISION 63
#define SHORT_RANDOM_BITS 7
#define NONE_ZERO_VECTOR 1
#define ZERO_VECTOR 0
#define TOO_MANY_PRECESSION 3
struct bernoulli{
    double p;            //error rate
    int precision;       //sample precision
    int length;          //the length bernoilli sequence
    int weight;          //the weight of bernoulli sequence
    int* berbits;        //the bernoulli sequence
};

static void init_bernoulli(struct bernoulli* pb, double p, int len, int precision);
static void free_bernoilli(struct bernoulli* pb);
static int xbit(int n, int k);
static int bernoulli_Sample_DDG(double p, ZZ& r, int* ber_bits, int len,int precision,int* hw);
static int sample_bernoulli(struct bernoulli* pb);
static int sample_bernoulli_wsrb(struct bernoulli* pb, ZZ& randombits);//sample bernoulli sequence with tha same random bits



static void init_bernoulli(struct bernoulli* pb, double p, int len, int precision)
{
    pb->berbits=(int*) malloc(sizeof(int)*len);
    pb->length=len;
    pb->weight=0;
    pb->precision=precision;
    pb->p=p;
}

static void free_bernoilli(struct bernoulli* pb)
{
    free(pb->berbits);
}

static int xbit(int n,int k)
{
    if((n>>(k-1))%2==1)
        return 1;
    else
        return 0;
}


static int bernoulli_Sample_DDG(double p, ZZ& r, int* ber_bits, int len,int precision,int& hw)
{
    if(precision>MAX_PRECISION)
        return TOO_MANY_PRECESSION;

    int prob_matrice=0;
    int a,i,k;
    long j,num_of_bits;

    num_of_bits=NumBits(r);
    a=0;
    for(i=0;i<precision;i++)
    {
        a=floor(p*2);
        prob_matrice=prob_matrice+a*(1<<i);//(pow(2,i));//
        p=p*2-a;
    }

    hw=0;
    j=0;
    for(i=0;i<len;i++)
    {
        k=0;
        j=j+1;
        while(j<num_of_bits && bit(r,j)!=0)
        {
            j++;
            k++;
        }

        if(j<num_of_bits)
        {
            ber_bits[i]=xbit(prob_matrice,k);
            if(ber_bits[i]!=0)
            {
                hw+=1;
            }
        }
        else if(i<len-1)
        {
            return SHORT_RANDOM_BITS;
        }
    }

    if(hw>0)
        return NONE_ZERO_VECTOR;
    else
        return ZERO_VECTOR;

}

static int sample_bernoulli(struct bernoulli* pb)
{
    ZZ randombits;
    RandomBits(randombits,3*pb->length);
    return bernoulli_Sample_DDG(pb->p,randombits,pb->berbits,pb->length,pb->precision,pb->weight);
}

static int sample_bernoulli_wsrb(struct bernoulli* pb, ZZ& randombits)
{
    return bernoulli_Sample_DDG(pb->p,randombits,pb->berbits,pb->length,pb->precision,pb->weight);
}

#endif // BERNOULLI_H_INCLUDED
