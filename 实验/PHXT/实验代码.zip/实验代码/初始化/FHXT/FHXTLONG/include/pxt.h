#ifndef PXT_H_INCLUDED
#define PXT_H_INCLUDED


#include <pbc/pbc.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;


struct pxt_ctx{
	pairing_t pairing;
	element_t g;
	element_t P;
	element_t K_I;
	element_t K_X;
	element_t K_Z;
	uint8_t K_S[16];
};

typedef struct pxt_ctx  pxt_param;
typedef struct pxt_ctx* pxt_param_ptr;

static void init_pxt_ctx(pxt_param_ptr ppxt, const char* pairing_param, const char* gparam, const char* Pparam);
static void free_pxt_ctx(pxt_param_ptr ppxt);

static void pxt_y(element_t& y, element_t& xind, element_t& z, pxt_param_ptr ppxt);
static void pxt_xtoken(element_t& xtoken, element_t& kzw, element_t& kxw, pxt_param_ptr ppxt);
static void pxt_xtag(element_t& xtag, element_t& kxw, element_t& xind, pxt_param_ptr ppxt);

static void pxt_prf(element_t& pr, char* key, int klen, char* data, int dlen, pxt_param_ptr ppxt);


const char *aparam =
"type a\n"
"q 8780710799663312522437781984754049815806883199414208211028653399266475630880222957078625179422662221423155858769582317459277713367317481324925129998224791\n"
"h 12016012264891146079388821366740534204802954401251311822919615131047207289359704531102844802183906537786776\n"
"r 730750818665451621361119245571504901405976559617\n"
"exp2 159\n"
"exp1 107\n"
"sign1 1\n"
"sign0 1\n";

const char *dparam =
"type d\n"
"q 625852803282871856053922297323874661378036491717\n"
"n 625852803282871856053923088432465995634661283063\n"
"h 3\n"
"r 208617601094290618684641029477488665211553761021\n"
"a 581595782028432961150765424293919699975513269268\n"
"b 517921465817243828776542439081147840953753552322\n"
"k 6\n"
"nk 60094290356408407130984161127310078516360031868417968262992864809623507269833854678414046779817844853757026858774966331434198257512457993293271849043664655146443229029069463392046837830267994222789160047337432075266619082657640364986415435746294498140589844832666082434658532589211525696\n"
"hk 1380801711862212484403205699005242141541629761433899149236405232528956996854655261075303661691995273080620762287276051361446528504633283152278831183711301329765591450680250000592437612973269056\n"
"coeff0 472731500571015189154958232321864199355792223347\n"
"coeff1 352243926696145937581894994871017455453604730246\n"
"coeff2 289113341693870057212775990719504267185772707305\n"
"nqr 431211441436589568382088865288592347194866189652\n";

const char* gparam=
"[2683883050849265915189365416030956254581411241282647542859647780869218433307221604126989955674747906372647052618524791783256790551896107044940489595731910,6402367145343749258479722306742141071418848285533645922279191831741404149832550075819343068294409474939103068768591532155189154318512103404771415219991951]\n";

const char* Pparam=
"[8765544994558544511822473501913852919255105499092973702221399703725974218832853409960792419230424557217895897923961406035302463206030462239159943485750306,420316100301432142122650580294507095130860221927557920072312027724564716526663697991031937781684918278912873084231063770883016821017145884257708286584865]\n";

const char* K_Iparam="632597478073482338755130710647762295475483994846\n";

const char* K_Xparam="682695452370594649715623412977380945530104623085\n";

const char* K_Zparam="216052748108958001189220277864453919583067029715\n";

//const char* K_Sparam="333965537199995825066514027578366744932889017875\n";

uint8_t K_S_par[16] = { (uint8_t) 0x2b, (uint8_t) 0x7e, (uint8_t) 0x15, (uint8_t) 0x16, (uint8_t) 0x28, (uint8_t) 0xae, (uint8_t) 0xd2, (uint8_t) 0xa6, (uint8_t) 0xab, (uint8_t) 0xf7, (uint8_t) 0x15, (uint8_t) 0x88, (uint8_t) 0x09, (uint8_t) 0xcf, (uint8_t) 0x4f, (uint8_t) 0x3c };

static void init_pxt_ctx(pxt_param_ptr ppxt, const char* pairing_param, const char* gparam, const char* Pparam)
{
	//char* gbuf;
	//char* Pbuf;
	//int glen,Plen;
	int i;

	pairing_init_set_str(ppxt->pairing, pairing_param);

	//glen=4*pairing_length_in_bytes_G1(ppxt->pairing);
	//Plen=4*pairing_length_in_bytes_G2(ppxt->pairing);

	//gbuf=(char*)malloc(1024);
	//Pbuf=(char*)malloc(1024);

	element_init_G1(ppxt->g, ppxt->pairing);
	element_init_G2(ppxt->P, ppxt->pairing);
	element_init_Zr(ppxt->K_I, ppxt->pairing);
    element_init_Zr(ppxt->K_X, ppxt->pairing);
    element_init_Zr(ppxt->K_Z, ppxt->pairing);
    //element_init_Zr(ppxt->K_S, ppxt->pairing);

    element_set_str(ppxt->g, gparam, 10);
	element_set_str(ppxt->P, Pparam, 10);
    element_set_str(ppxt->K_I, K_Iparam, 10);
    element_set_str(ppxt->K_X, K_Xparam, 10);
    element_set_str(ppxt->K_Z, K_Zparam, 10);

    for(i=0;i<16;i++) ppxt->K_S[i]=K_S_par[i];
    //element_set_str(ppxt->K_S, K_Sparam, 10);
	//element_random(ppxt->K_I);
	//element_random(ppxt->K_X);
	//element_random(ppxt->K_Z);
	//element_random(ppxt->K_S);

    //element_printf("K_I=%B\n",ppxt->K_I);
    //element_printf("K_X=%B\n",ppxt->K_X);
    //element_printf("K_Z=%B\n",ppxt->K_Z);
    //element_printf("K_S=%B\n",ppxt->K_S);
  	//element_snprint(gbuf, glen, ppxt->K_I);//把一个pairing对象转换为10进制字符串
	//printf("K_I=%s\n",gbuf);


	//element_snprint(gbuf, glen, ppxt->g);
	//printf("%s\n",gbuf);

	//element_printf("%B\n", ppxt->g);
	//element_printf("%B\n", ppxt->P);

	//element_random(ppxt->P);
  	//element_snprint(Pbuf, Plen, ppxt->P);
	//printf("%s\n",Pbuf);

	//free(gbuf);
	//free(Pbuf);
}

static void free_pxt_ctx(pxt_param_ptr ppxt)
{
	element_clear(ppxt->g);
 	element_clear(ppxt->P);

 	pairing_clear(ppxt->pairing);
}

//y must be initialized with element_init_G1
//xind and z must be initialized with element_init_Zr.
static void pxt_y(element_t& y, element_t& xind, element_t& z, pxt_param_ptr ppxt)
{
	element_t temp;
	element_init_Zr(temp,ppxt->pairing);
	element_div(temp,xind,z);
	element_pow_zn(y, ppxt->g, temp);

	element_clear(temp);
}

//xtoken must be initialized with element_init_G2
//kzw and kxw must be initialized with element_init_Zr.
static void pxt_xtoken(element_t& xtoken, element_t& kzw, element_t& kxw, pxt_param_ptr ppxt)
{
	element_t temp;
	element_init_Zr(temp,ppxt->pairing);
	element_mul(temp,kzw,kxw);
	element_pow_zn(xtoken,ppxt->P,temp);

	element_clear(temp);
}

//xtag must be initialized with element_init_GT
//xind and kxw must be initialized with element_init_Zr.
static void pxt_xtag(element_t& xtag, element_t& kxw, element_t& xind, pxt_param_ptr ppxt)
{
	element_t tmp1,tmp2,tmp3;
	element_init_G1(tmp1, ppxt->pairing);
	element_init_G2(tmp2, ppxt->pairing);
	element_init_Zr(tmp3, ppxt->pairing);

	element_pow_zn(tmp1, ppxt->g, kxw);
	element_pow_zn(tmp2, ppxt->P,xind);

	element_pairing(xtag, tmp1, tmp2);

	element_clear(tmp1);
	element_clear(tmp2);
	element_clear(tmp3);
}

//pr must be initialized with element_init_Zr
static void pxt_prf(element_t& pr, char* key, int klen, char* data, int dlen, pxt_param_ptr ppxt)
{
    char* msg;
    int i,j,len;

    len=klen+dlen;
    msg=(char*) malloc(len+1);
    for(i=0;i<klen;i++){
	if(key[i]=='\n')
		break;
        msg[i]=key[i];
	}
    for(j=0;j<dlen;j++){
	if(data[j]=='\n')
		break;
        msg[j+i]=data[j];
	}
	//msg[len]='\n';
    element_from_hash(pr, msg, i+j);

    free(msg);
}

#endif // PXT_H_INCLUDED
