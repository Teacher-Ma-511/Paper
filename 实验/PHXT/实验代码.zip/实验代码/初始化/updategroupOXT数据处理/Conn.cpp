// #include"include/Conn.h"
// #include<iostream>

// #include<algorithm>
// #include<stdio.h>
// #include<map>
// #include<string.h>
// #include<mysql/mysql.h>   

// using namespace std;









// void stringsub(string str,int& len,string *&strarr){
// 	int l=str.length();
// 	if(l%16==0){
// 		len=l/16;
// 	}else{
// 		len=(l/16)+1;
// 	}
// 	strarr=new string[len];
// 	for(int i=0;i<len;i++){
// 		strarr[i]=str.substr(i*16,16);
// 	}
// }





// multimap<string,string> Querypositive(list<string> &keyoflist) {
// 	multimap<string,string> multilp1;
// 	int m=0;
// 	int n=1000;
// 	for(int i=0;i<252;i++){
// 		sprintf(query,"select * from smallpositive limit %d,%d;",m,n);
// 		//strcpy(query,"select * from positive limit "+m+","+n);
// 		mysql_query(&mysql, "set names gbk");
// 		if (mysql_query(&mysql, query)) {
// 			printf("Query failed (%s)\n", mysql_error(&mysql));
// 			return multilp1;
// 		}
// 		else {
// 			printf("query success\n");
// 		}

// 		res = mysql_store_result(&mysql);
// 		if (!res) {
// 			printf("Couldn't get result from %s\n", mysql_error(&mysql));
// 			return multilp1;
// 		}

// 		while (column = mysql_fetch_row(res)) {
// 			multilp1.insert(make_pair(column[1],column[0]));
// 			keyoflist.push_back(column[1]);
// 		}
// 		m+=n;	
// 	}

// 	return multilp1;
// }

// multimap<char *,char *> Querypositivechar(list<char *> &keyoflist) {

// 	multimap<char *,char *> multilp1;
// 	int m=0;
// 	int n=1000;
// 	for(int i=0;i<252;i++){
// 		sprintf(query,"select * from positive limit %d,%d;",m,n);
// 		mysql_query(&mysql, "set names gbk");
// 		if (mysql_query(&mysql, query)) {
// 			printf("Query failed (%s)\n", mysql_error(&mysql));
// 			return multilp1;
// 		}
// 		else {
// 			//printf("query success\n");
// 		}

// 		res = mysql_store_result(&mysql);
// 		if (!res) {
// 			//printf("Couldn't get result from %s\n", mysql_error(&mysql));
// 			return multilp1;
// 		}

// 		while (column = mysql_fetch_row(res)) {
// 			multilp1.insert(make_pair(column[1],column[0]));
// 			keyoflist.push_back((column[1]));
// 		}
// 		m+=n;	
// 	}

// 	return multilp1;
// }


// void queryinverted(){
// 	sprintf(query,"select * from eninverted;");
// 		//strcpy(query,"select * from eninverted);
// 		mysql_query(&mysql, "set names gbk");
// 		if (mysql_query(&mysql, query)) {
// 			//printf("Query failed (%s)\n", mysql_error(&mysql));
// 		}
// 		else {
// 			//printf("query success\n");
// 		}

// 		res = mysql_store_result(&mysql);
// 		if (!res) {
// 			//printf("Couldn't get result from %s\n", mysql_error(&mysql));
// 		}

// 		while (column = mysql_fetch_row(res)) {
// 			cout<<column[0]<<"       "<<column[1]<<endl;
// 		}
// }



// //  string&   replace(string&   str,const string& old_value,const string& new_value,const string& old_value1,const string& new_value1)     
// // {     
// // 	for(string::size_type   pos(0);   pos!=string::npos;   pos+=new_value.length())   {     
// // 		if(   (pos=str.find(old_value,pos))!=string::npos   )     
// // 			str.replace(pos,old_value.length(),new_value);     
// // 		else   break;  

// // 		if(   (pos=str.find(old_value1,pos))!=string::npos   )     
// // 			str.replace(pos,old_value1.length(),new_value1);     
// // 		else   break;

// // 	}     
// // 	return   str;     
// // }     

// void replaceSpace(char *str) {

// 	int length=strlen(str);
// 	if(str==NULL||length<=0) return ;
// 	for (int i=0;i<length;i++){
// 		if(str[i]=='\''){   //单引号
// 			length++;
// 			for(int k=length-1;k>i;k--){
// 				str[k]=str[k-1];
// 			}     //先将数组长度加2
// 			str[i]='\'';
// 			i++;
// 		}
// 	}
// 	length++;
// 	str[length]='\0';  
// }

// void replaceSpace1(char *str){
// 	int length=strlen(str);
// 	if(str==NULL||length<=0) return ;
// 	for (int i=0;i<length;i++){
// 		if(str[i]=='\\'){   //单引号
// 			length++;
// 			for(int k=length-1;k>i;k--){
// 				str[k]=str[k-1];
// 			}     //先将数组长度加2
// 			str[i]='\\';
// 			i++;
// 		}
// 	}
// 	length++;
// 	str[length]='\0';  
// }



// multimap<string,string> queryinverted(list<string> &keyoflist){
// 	multimap<string,string> lp1;
// 	sprintf(query,"select * from inverted");
// 	//strcpy(query,"select * from positive limit "+m+","+n);
// 	mysql_query(&mysql, "set names gbk");
// 	if (mysql_query(&mysql, query)) {
// 		printf("Query failed (%s)\n", mysql_error(&mysql));
// 		return lp1;
// 	}
// 	else {
// 		printf("query success\n");
// 	}

// 	res = mysql_store_result(&mysql);
// 	if (!res) {
// 		printf("Couldn't get result from %s\n", mysql_error(&mysql));
// 		return lp1;
// 	}

// 	while (column = mysql_fetch_row(res)) {
// 		lp1.insert(make_pair(column[0],column[1]));
// 		keyoflist.push_back(column[0]);
// 	}
// }


