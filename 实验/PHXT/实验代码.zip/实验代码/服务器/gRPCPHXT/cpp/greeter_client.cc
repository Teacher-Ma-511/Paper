#include <iostream>
#include <memory>
#include <string>
#include<list>
#include<stdlib.h>
#include<sys/time.h>
#include<NTL/ZZ.h>
#include <grpcpp/grpcpp.h>

#ifdef BAZEL_BUILD
#include "examples/protos/helloworld.grpc.pb.h"
#else
#include "helloworld.grpc.pb.h"
#endif
#include"include/aes.h"
#include"include/bf.h"
#include"include/phxt.h"
#include"include/Conn.h"
#include"include/tools.h"
using grpc::Channel;
using grpc::ChannelArguments;
using grpc::ClientContext;
using grpc::Status;
using helloworld::HelloRequest; 
using helloworld::HelloReply;
using helloworld::Greeter;
using namespace std;
//using namespace std;
struct set_bf sbf;
class GreeterClient {
 public:
  GreeterClient(std::shared_ptr<Channel> channel)
      : stub_(Greeter::NewStub(channel)) {}

  // Assembles the client's payload, sends it and presents the response back
  // from the server.
  std::string SayHello(const std::string& user) {
    // Data we are sending to the server.
    HelloRequest request;
    request.set_name(user);

    // Container for the data we expect from the server.
    HelloReply reply;

    // Context for the client. It could be used to convey extra information to
    // the server and/or tweak certain RPC behaviors.
    ClientContext context;

    // Overwrite the call's compression algorithm to DEFLATE.
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    // The actual RPC.
    Status status = stub_->SayHello(&context, request, &reply);

    // Act upon its status.
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }


  std::string SayHello1(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello1(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

  std::string SayHello2(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello2(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

  std::string SayHello3(const std::string& user) {
    HelloRequest request;
    request.set_name(user);
    HelloReply reply;
    ClientContext context;
    context.set_compression_algorithm(GRPC_COMPRESS_DEFLATE);

    Status status = stub_->SayHello3(&context, request, &reply);
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

 private:
  std::unique_ptr<Greeter::Stub> stub_;
};

int main(int argc, char** argv) {

  double servertime=0;
  double clienttime=0;

  struct timeval start;
	struct timeval end;

  struct timeval start1;
	struct timeval end1;
  
  

  

  int i,j;
  int kwlen;
  long xlen, qbytes;

  char querybloom1sql[150];

  uint8_t tmp[32];
  uint8_t ke[16];
  uint8_t kl[16];
  uint8_t plain_id[16];
  uint8_t l[16];
  uint8_t data[64];
  uint8_t intb[4];
  uint8_t indexvaluesearchbyte[8];
  uint8_t realvaluebyte[4];
  uint8_t idindex[16];
  //记录客户端计算的全为1的异或结果
  uint8_t resultvalue[16];
  uint8_t k[16];
  uint8_t d1[16];
  uint8_t additition[16];
  ZZ xind,z,y,kxw;
  struct AES_ctx ctx;
  struct AES_ctx ctx1;
  struct AES_ctx ctx2;
  
 phxt_param_ptr phxt;
  
  ZZ g,p,q;
  ZZ_from_char(g,ag);
  ZZ_from_char(p,ap);
  ZZ_from_char(q,aq);
  phxt_param soxt={g,q,p,aks,akx,aki,akz,QLEN,PLEN,16, 16,16, 16, ID_LEN_IN_BYTE};
  phxt=&soxt;
  qbytes=NumBytes(phxt->q);
  ChannelArguments args;
  // Set the default compression algorithm for the channel.
  args.SetCompressionAlgorithm(GRPC_COMPRESS_GZIP);
  GreeterClient greeter(grpc::CreateCustomChannel(
      "localhost:50051", grpc::InsecureChannelCredentials(), args));
  cout<<"请输入要查询的关键字"<<endl;
  list<char *> searchword;
  list<char *>::iterator itor;
  for(int i=0;i<6;i++){
    char *word=new char[100];
    cin>>word;
    searchword.push_back(word);
  }
  gettimeofday(&start,NULL);
  gettimeofday(&start1,NULL);
  uint8_t *keyword=(uint8_t*)searchword.front();
    //Todo:获取关键词pkeywords[i]的byte长度
  kwlen=strlen(searchword.front());//获得关键字的长度
    //cout<<tokens.front()<<endl;
  cat_uint(data,phxt->Ks,keyword,phxt->kslen,kwlen);//data=Ks||kw1
  DeriveKey(tmp,32,data,phxt->kslen+kwlen);
  string stagstring=base64_encode(tmp,32);
  gettimeofday(&end1,NULL);
  double clienttime1=1000000 * (end1.tv_sec -start1.tv_sec) + end1.tv_usec - start1.tv_usec;
  clienttime1/=1000000;
  //cout<<stagstring<<endl;
  //将产生的stag发送给服务器
  std::string reply = greeter.SayHello(stagstring);
  //这里是返回对应产生的所有的索引地址
  int frcount=atoi(reply.data());
  cout<<"frcount"<<frcount<<endl;
  int icount=0;
  int c1;
  //构建xtoken
  
  //计算通讯成本：
  // long clientlen=0;
  // long serverlen=0;

  // clientlen=clientlen+stagstring.length()+1;
  // serverlen=serverlen+reply.length()+1;


  int resultcountindex=0;
  string resultstr="";
  double clienttime2=0;
  for (int i=0;i<frcount;i++)//循环w1查询到的id个数
  {
    struct timeval start2;
	  struct timeval end2;

    struct timeval start3;
	  struct timeval end3;

    struct timeval start4;
  	struct timeval end4;
    gettimeofday(&start2,NULL);
    //ZZ xtokes[tokens.size()-1];//生成输入的关键字个数减1个的xtoken
    list<long> indexlist;
    list<long>::iterator indexitor;
    int_to_uint8(resultcountindex,intb);
    cat_uint(data,keyword,intb,kwlen,4);//在生成xtoken的过程中，kzw使用的是  w1
    oxt_prf(z,phxt->Kz,data,phxt->kzlen,kwlen+4,phxt->q,qbytes);//z是w1对应c的z
    //cout<<"进入1"<<endl;
    int icount=0;
    string finxtoken="";
    for(itor=searchword.begin();itor!=searchword.end();itor++){
      icount++;
      //cout<<"进入2"<<endl;
      if(icount!=1){
        uint8_t *bkeyword=(uint8_t*)*itor;
        int bkwlen=strlen(*itor);
        oxt_prf(kxw,phxt->Kx,bkeyword,phxt->kxlen,bkwlen,phxt->q,qbytes);
        ZZ xtokes;
        oxt_xtoken(xtokes,z,kxw,phxt);
        int ZZxtokenlen=NumBytes(xtokes);
        uint8_t *xokenchar=new uint8_t[ZZxtokenlen];
        BytesFromZZ(xokenchar,xtokes,ZZxtokenlen);
        string xtokenstring=base64_encode(xokenchar,ZZxtokenlen);
        finxtoken.append(xtokenstring).append(",");
      }
    }
    gettimeofday(&end2,NULL);
    double fortime=1000000 * (end2.tv_sec -start2.tv_sec) + end2.tv_usec - start2.tv_usec;
    fortime/=1000000;
    clienttime2+=fortime;

    std::string reply1 = greeter.SayHello1(finxtoken); 

    gettimeofday(&start3,NULL);
    //这里传过来的时一组经过base64编码的xtag
    list<string> xtaglist;
    list<string>::iterator xtaglistitor;
    StringSplit(reply1,",",xtaglist);
    for(xtaglistitor=xtaglist.begin();xtaglistitor!=xtaglist.end();xtaglistitor++){
      string inttsr=*xtaglistitor;
      string tmp=base64_decode(inttsr);
      query_index((uint8_t *)tmp.data(),16,&sbf,indexlist);
    }

    string clientebf="";

    for(indexitor=indexlist.begin();indexitor!=indexlist.end();indexitor++){
      //cout<<"进入4"<<endl;
      int bitvalue,bitvalue2;
      int bitvalue1=1;
      long indexvaluesearch;
      indexvaluesearch=*indexitor;
      long_to_uint8(indexvaluesearch,indexvaluesearchbyte);
      //创建出16字节的纯文本
      for(int i=0;i<8;i++){
        additition[i]=0x00;
      }
      cat_uint(additition,additition,indexvaluesearchbyte,8,8);
      AES_init_ctx(&ctx1, akz);
      AES_ECB_encrypt(&ctx1,additition);
      bitvalue2=((additition[0]>>7)&1);
      bitvalue=bitvalue1^bitvalue2;
      clientebf.append(to_string(bitvalue));
    }//end
    
    unsigned int clienthash=DJBHash(clientebf.data()); 
    gettimeofday(&end3,NULL);
    double fortime1=1000000 * (end3.tv_sec -start3.tv_sec) + end3.tv_usec - start3.tv_usec;
    fortime1/=1000000;
    clienttime2+=fortime1;
    std::string eneresult = greeter.SayHello2(to_string(clienthash));
    //clientlen=clientlen+to_string(clienthash).length()+1;
    //serverlen=serverlen+ eneresult.length()+1;
    resultstr.append(eneresult).append(",");
    resultcountindex++;
  }
  gettimeofday(&end,NULL);
  double sumtime=1000000 * (end.tv_sec -start.tv_sec) + end.tv_usec - start.tv_usec;
  sumtime/=1000000;
  //cout<<"finxtoken"<<finxtoken<<endl;
  //cout<<"返回查询的id位置："<<resultstr<<endl;
  
  //std::cout << "Greeter received: " << reply1 << std::endl;
  for(j=0;j<16;j++)
  {
      ke[j]=tmp[j];//ke to encrypt the document id
      kl[j]=tmp[j+16];//kl to generate the dictionary index
  }
  AES_init_ctx(&ctx, ke);
  list<string> elist;
  list<string>::iterator elistitor;
  StringSplit(resultstr,",",elist);
  int sumid=0;
  for(elistitor=elist.begin();elistitor!=elist.end();elistitor++){
    string dee=base64_decode(*elistitor);
    uint8_t *uchare=(uint8_t*)dee.data();
        AES_ECB_decrypt(&ctx, uchare);
        //cout<<uchare<<"   ";
        uint8_t *charid=new uint8_t[4];
        for(int j=12;j<16;j++){
          charid[j-12]=uchare[j];
        }
        int id=(int)charid[0]+((int)charid[1]*256)+((int)charid[2]*256*256)+((int)charid[3]*256*256*256);
        //cout<<"id:"<<id<<endl;
        sumid++;
  }
  cout<<"查询结果集："<<sumid<<endl;
  
  //cout<<"通讯成本："<<(double)(clientlen+serverlen)/1024/1024<<endl;
  clienttime=clienttime1+clienttime2;
  cout<<"clienttime:"<<clienttime<<endl;
  cout<<"总查询时间:"<<sumtime<<endl;
  //string deletestr= greeter.SayHello3("请求清除数组");
  //cout<<deletestr<<endl;
  return 0;
}
