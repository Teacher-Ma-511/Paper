package nsse;

import entity.*;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import util.*;

import java.util.*;

import cprf.AllParameter;
import cprf.CPRF;

public class NSSEP {
	public Pairing pairing = PairingFactory.getPairing("params/curves/a.properties");
	
	CPRF cp = new CPRF();

    public NAllKeyP KeySetup(String[] kws){
        NAllKeyP nakp = new NAllKeyP();
        
        AllParameter ap = cp.Setup(kws);
        
        nakp.nppp.g = pairing.getGT().newRandomElement().getImmutable();
        nakp.nppp.kbs = ap.kbs;
        
        byte[] k = {5,5,5};
        byte[] k_i = {1,1,1};
        byte[] k_s = {2,2,2};
        byte[] k_z = {3,3,3};
        byte[] k_x = {4,4,4};
        byte[] k1 = {6,6,6};
        byte[] k2 = {7,7,7};
        byte[] k3 = {8,8,8};
        
        nakp.nmskp.K = k;
        nakp.nmskp.K_I = k_i;
        nakp.nmskp.K_S = k_s;
        nakp.nmskp.K_Z = k_z;
        nakp.nmskp.K_X = k_x;
        
        nakp.nmskp.K1 = k1;
        nakp.nmskp.K2 = k2;
        nakp.nmskp.K3 = k3;

        return nakp;
    }

    public EDBAndXSet EDBSetup(DBBlock[] db, NAllKeyP nakp){
        EDBAndXSet eax = new EDBAndXSet(db.length);

        for(int i=0; i<db.length; i++){
        	
        	byte[] Xw1 = cp.PRFW(db[i].kw, nakp.nppp.kbs, nakp.nmskp.K1);
        	byte[] Xw2 = cp.PRFW(db[i].kw, nakp.nppp.kbs, nakp.nmskp.K2);
        	byte[] Xw3 = cp.PRFW(db[i].kw, nakp.nppp.kbs, nakp.nmskp.K3);
        	
            eax.edb[i].stag = AES.encrypt(nakp.nmskp.K_S, Xw1);
            byte[] k_w = AES.encrypt(nakp.nmskp.K, eax.edb[i].stag);

            for(int j=0; j<db[i].index.size(); j++){
                byte[] l = AES.encrypt(eax.edb[i].stag, IntToByteArray.IntToByte(j));
                String l_str = new String(l);

                EY ey = new EY();
                String id = db[i].index.get(j);
                ey.e = AES.encrypt(k_w, id.getBytes());

                byte[] xind = AES.encrypt(nakp.nmskp.K_I, id.getBytes());
                String kwh_c = String.valueOf(j).concat(Hash.ByteToHex(Xw2));
                byte[] z = AES.encrypt(nakp.nmskp.K_Z, kwh_c.getBytes());

                Element e_xind = Hash.HashToZr(pairing, xind).getImmutable();
                Element e_z = Hash.HashToZr(pairing, z).getImmutable();
                Element e_z1 = pairing.getZr().newOneElement().div(e_z).getImmutable();
                ey.y = e_xind.mul(e_z1).getImmutable();

                byte[] x = AES.encrypt(nakp.nmskp.K_X, Xw3);
                Element e_x = Hash.HashToZr(pairing, x).getImmutable();

                Element xtag = nakp.nppp.g.powZn(e_x.mul(e_xind)).getImmutable();

                eax.edb[i].mey.put(l_str, ey);
                eax.xset.add(xtag);
            }
        }
        return  eax;
    }

    public ClientKeyP ClientKeyGen(NAllKeyP nakp, String[] W){
        ClientKeyP ckp = new ClientKeyP();
        
        ckp.K = nakp.nmskp.K;
        ckp.K_I = nakp.nmskp.K_I;
        ckp.K_S = nakp.nmskp.K_S;
        ckp.K_X = nakp.nmskp.K_X;
        ckp.K_Z = nakp.nmskp.K_Z;
        ckp.kbs = nakp.nppp.kbs;
        
        ckp.ckw1 = cp.CKeyGen(W, nakp.nppp.kbs, nakp.nmskp.K1);
        ckp.ckw2 = cp.CKeyGen(W, nakp.nppp.kbs, nakp.nmskp.K2);
        ckp.ckw3 = cp.CKeyGen(W, nakp.nppp.kbs, nakp.nmskp.K3);

        return ckp;
    }

    public byte[] StagGen(String w1, ClientKeyP ckp){
        byte[] Xw1 = cp.PRFW(ckp.ckw1, w1, ckp.kbs);
   
        if(Xw1 != null)
        	return AES.encrypt(ckp.K_S, Xw1);
        return null;
    }

    public Token TokenGen(int c, String[] QW, ClientKeyP ckp, Element g){
        int m = QW.length - 1;
        Token t = new Token(c, m);
        byte[] Xw2 = cp.PRFW(ckp.ckw2, QW[0], ckp.kbs);
        String Xw2_str = Hash.ByteToHex(Xw2);
        
        Element[] e_xs = new Element[m];
        
        byte[] Xwj;
        byte[] x;
        for(int j=0; j<m; j++) {
        	Xwj = cp.PRFW(ckp.ckw3, QW[j+1], ckp.kbs);   
            x = AES.encrypt(ckp.K_X, Xwj);
            e_xs[j] = Hash.HashToZr(pairing, x).getImmutable();
        }
        
        for(int i=0; i<c; i++){
        	String Xw2_c = String.valueOf(i).concat(Xw2_str);
        	byte[] z = AES.encrypt(ckp.K_Z, Xw2_c.getBytes());
            Element e_z = Hash.HashToZr(pairing, z).getImmutable();
        	for(int j=0; j<m; j++){    
                t.xtoken[i][j] = g.powZn(e_z.mul(e_xs[j])).getImmutable();
            }
        }
        return t;
    }

    public Map<String, EY> SearchStag(byte[] stag, EDBBlock[] edb){
        for(int i=0; i<edb.length; i++){
            if(Arrays.equals(edb[i].stag, stag))
                return edb[i].mey;
        }
        return null;
    }

    public Set<byte[]> SearchXtoken(Token t, byte[] stag, Map<String, EY> mey, Set<Element> xset){
        Set<byte[]> es = new HashSet<>();

        Element[] xs = new Element[xset.size()];
        Iterator<Element> it = xset.iterator();
        for(int i=0; i<xs.length; i++){
            xs[i] = it.next();
        }

        for(int i=0; i<t.xtoken.length; i++){
            byte[] l = AES.encrypt(stag, IntToByteArray.IntToByte(i));
            String l_str = new String(l);

            EY ey = mey.get(l_str);

            int counter = 0;
            for(int j=0; j<t.xtoken[i].length; j++){
                Element xtag = t.xtoken[i][j].powZn(ey.y).getImmutable();
                //System.out.println("xtoken" + i + j + ": " + t.xtoken[i][j]);
                //System.out.println("xtag" + i + j + ": " + xtag);
                for(int k=0; k<xs.length; k++){
                    if(xs[k].isEqual(xtag)){
                        counter ++;
                        break;
                    }
                }
            }
            if(counter == t.xtoken[i].length)
                es.add(ey.e);
        }

        return es;
    }

    public static void main(String[] args){
        NSSEP nssep = new NSSEP();
        DBBlock[] db = ReadInvertedIndex.Read("InvertedIndex.txt");
        //DBBlock[] db = ReadInvertedIndex.Read("inverted_index_aaron_dataset.txt");
//        System.out.println("Inverted Index DB:");
//        for(int i=0; i<db.length; i++){
//            System.out.print(db[i].kw + " ");
//            for(int j=0; j<db[i].index.size(); j++){
//                System.out.print(db[i].index.get(j) + " ");
//            }
//            System.out.println();
//        }

        String[] W = new String[400];
        for(int i=0; i<W.length; i++)
        	W[i] = "w" + i;
        
        String[][] Q = new String[5][];
        for(int i=0; i<5; i++) {
        	Q[i] = new String[(i+1)*10];
        	for(int j=0; j<Q[i].length; j++)
            	Q[i][j] = "w" + j;
        }
        
//        String[] W = {"w0", "w1", "w2", "w3"};
//        String[] Q = {"w0", "w1", "w2"};
        
        long start, end;
        
        NAllKeyP nakp = nssep.KeySetup(W);
        
        start = System.nanoTime();
        EDBAndXSet eax = nssep.EDBSetup(db, nakp);
        end = System.nanoTime();
        System.out.println("EDB Setup Time: " + (end - start));
        
//        long start, end;
//        
//        String[] W;
//        ClientKey ck = null;
//        for(int i=1; i<=4; i++) {
//        	W = new String[i*500];
//        	for(int j=0; j<W.length; j++)
//        		W[j] = "w" + (j+1);
//        	start = System.nanoTime();
//        	ck = nsse.ClientKeyGen(nakBnak, S, W);
//        	end = System.nanoTime();
//        	System.out.println(W.length + "Sk time:" + (end - start));
//        }
        
        
        start = System.nanoTime();
        ClientKeyP ckp = nssep.ClientKeyGen(nakp, W);
        end = System.nanoTime();
        System.out.println("Client Key Time: " + (end - start));
        
//        //for(int i=0; i<5; i++) {
//        	System.out.print("Query: ");
//            //for(int j=0; j<Q[i].length; j++)
//            for(int j=0; j<Q.length; j++)
//            	//System.out.print(Q[i][j] + " ");
//            	System.out.print(Q[j] + " ");
//            System.out.println();
//             
//            start = System.nanoTime(); 
//            //byte[] stag = nssep.StagGen(Q[i][0], ckp);
//            byte[] stag = nssep.StagGen(Q[0], ckp);
//
//            Map<String, EY> mey = nssep.SearchStag(stag, eax.edb);
//
//            //Token t = nssep.TokenGen(mey.size(), Q[i], ckp, nakp.nppp.g);
//            Token t = nssep.TokenGen(mey.size(), Q, ckp, nakp.nppp.g);
//
//            Set<byte[]> es = nssep.SearchXtoken(t, stag, mey, eax.xset);
//            end = System.nanoTime();
//            System.out.println("Search Time: " + (end - start));
//
//            Iterator<byte[]> it = es.iterator();
//              
//            byte[] k_w = AES.encrypt(ckp.K, stag);
//            while (it.hasNext()){
//            	byte[] e = it.next();
//                byte[] id = AES.decrypt(k_w, e);
//                System.out.println(new String(id));
//            }
        }
    //}
}
