package nsse;

import entity.*;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import util.*;

import java.math.BigInteger;
import java.util.*;

public class NSSE {
	public Pairing pairing = PairingFactory.getPairing("params/curves/a.properties");

    public NAllKey KeySetup(int bitLen){
        NAllKey nak = new NAllKey();
        
        //int keyLen = 128;
        //int keyLen = 256;
        Random rand = new Random();

        nak.nmsk.p = new BigInteger(bitLen/2-1, 100, rand);
        nak.nmsk.q = new BigInteger(bitLen/2+1, 100, rand);
        nak.npp.n = nak.nmsk.p.multiply(nak.nmsk.q);

        for(int i=0; i<3; i++)
            nak.nmsk.g[i] = new BigInteger(String.valueOf(123+i));
        nak.npp.g = pairing.getGT().newRandomElement().getImmutable();
        
        byte[] k = {5,5,5};
        byte[] k_i = {1,1,1};
        byte[] k_s = {2,2,2};
        byte[] k_z = {3,3,3};
        byte[] k_x = {4,4,4};
        
        nak.nmsk.K = k;
        nak.nmsk.K_I = k_i;
        nak.nmsk.K_S = k_s;
        nak.nmsk.K_Z = k_z;
        nak.nmsk.K_X = k_x;

        return nak;
    }

    public EDBAndXSet EDBSetup(DBBlock[] db, NAllKey nak, int byteLen){
        EDBAndXSet eax = new EDBAndXSet(db.length);

        for(int i=0; i<db.length; i++){
        	
        	
            BigInteger w_prime = KeywordToPrime.FindPrime(db[i].kw, byteLen);
            BigInteger w1 = RSA.getInverse(nak.nmsk.p, nak.nmsk.q, w_prime);
            BigInteger g1_w1 = nak.nmsk.g[0].modPow(w1, nak.npp.n);

            eax.edb[i].stag = AES.encrypt(nak.nmsk.K_S, g1_w1.toByteArray());
            
            byte[] k_w = AES.encrypt(nak.nmsk.K, eax.edb[i].stag);
            
            for(int j=0; j<db[i].index.size(); j++){
                byte[] l = AES.encrypt(eax.edb[i].stag, IntToByteArray.IntToByte(j));
                String l_str = new String(l);

                EY ey = new EY();
                String id = db[i].index.get(j);
                ey.e = AES.encrypt(k_w, id.getBytes());

                byte[] xind = AES.encrypt(nak.nmsk.K_I, id.getBytes());
                BigInteger g2_w1 = nak.nmsk.g[1].modPow(w1, nak.npp.n);
                String g2_w1_c = String.valueOf(j).concat(g2_w1.toString());
                byte[] z = AES.encrypt(nak.nmsk.K_Z, g2_w1_c.getBytes());

                Element e_xind = Hash.HashToZr(pairing, xind).getImmutable();
                Element e_z = Hash.HashToZr(pairing, z).getImmutable();
                Element e_z1 = pairing.getZr().newOneElement().div(e_z).getImmutable();
                ey.y = e_xind.mul(e_z1).getImmutable();

                BigInteger g3_w1 = nak.nmsk.g[2].modPow(w1, nak.npp.n);
                byte[] g3_w1_e = AES.encrypt(nak.nmsk.K_X, g3_w1.toByteArray());
                Element e_g3_w1_e = Hash.HashToZr(pairing, g3_w1_e).getImmutable();

                Element xtag = nak.npp.g.powZn(e_g3_w1_e.mul(e_xind)).getImmutable();

                eax.edb[i].mey.put(l_str, ey);
                eax.xset.add(xtag);
            }
        }
        return  eax;
    }

    public ClientKey ClientKeyGen(NAllKey nak, String[] W, int byteLen){
        ClientKey ck = new ClientKey();

        ck.K = nak.nmsk.K;
        ck.K_I = nak.nmsk.K_I;
        ck.K_S = nak.nmsk.K_S;
        ck.K_X = nak.nmsk.K_X;
        ck.K_Z = nak.nmsk.K_Z;

        BigInteger w_m = BigInteger.ONE;
        for(int i=0; i<W.length; i++){
            BigInteger w_prime = KeywordToPrime.FindPrime(W[i], byteLen);    //
            w_m = w_m.multiply(w_prime);
        }
        BigInteger w_m1 = RSA.getInverse(nak.nmsk.p, nak.nmsk.q, w_m);  //鍙兘闇�瑕乵od

        for(int i=0; i<3; i++)
            ck.sk_w[i] = nak.nmsk.g[i].modPow(w_m1, nak.npp.n);

        return ck;
    }

    public byte[] StagGen(String w1, String[] W, ClientKey ck, BigInteger n, int byteLen){
        BigInteger ws_prime = BigInteger.ONE;
        for(int i=0; i<W.length; i++){
            if(!W[i].equals(w1)){
                BigInteger w_prime = KeywordToPrime.FindPrime(W[i], byteLen);
                ws_prime = ws_prime.multiply(w_prime);
            }
        }

        BigInteger sk1_w1 = ck.sk_w[0].modPow(ws_prime, n);

        byte[] stag = AES.encrypt(ck.K_S, sk1_w1.toByteArray());

        return stag;
    }

    public Token TokenGen(int c, String w1, String[] W, String[] W_1, ClientKey ck, BigInteger n, Element g, int byteLen){
        int m = W_1.length - 1;
        Token t = new Token(c, m);
        
        BigInteger sk2_w = BigInteger.ONE;

        for(int k=0; k<W.length; k++){
            if(!W[k].equals(w1)){
                BigInteger w_prime = KeywordToPrime.FindPrime(W[k], byteLen);
                sk2_w = sk2_w.multiply(w_prime);
            }
        }
        
        BigInteger sk2_w1 = ck.sk_w[1].modPow(sk2_w, n);
        String sk2_w1_str = sk2_w1.toString();
        
        Element[] e_sk3s = new Element[m];
        
        for(int j=0; j<m; j++) {
        	BigInteger sk3_w = BigInteger.ONE;

            for(int k=0; k<W.length; k++){
                if(!W[k].equals(W_1[j+1])){
                    BigInteger w_prime = KeywordToPrime.FindPrime(W[k], byteLen);
                    sk3_w = sk3_w.multiply(w_prime);
                }
            }
            BigInteger sk3_wj1 = ck.sk_w[2].modPow(sk3_w, n);
            byte[] sk3_wj1_e = AES.encrypt(ck.K_X, sk3_wj1.toByteArray());
            e_sk3s[j] = Hash.HashToZr(pairing, sk3_wj1_e).getImmutable();
        }
        
        for(int i=0; i<c; i++){
        	String sk2_w1_c = String.valueOf(i).concat(sk2_w1_str);
            byte[] sk2_w1_c_e = AES.encrypt(ck.K_Z, sk2_w1_c.getBytes());
            Element e_sk2 = Hash.HashToZr(pairing, sk2_w1_c_e).getImmutable();
        	
            for(int j=0; j<m; j++){
                t.xtoken[i][j] = g.powZn(e_sk2.mul(e_sk3s[j])).getImmutable();
            }
        }
        return t;
    }

    public Map<String, EY> SearchStag(byte[] stag, EDBBlock[] edb){
        for(int i=0; i<edb.length; i++){
            if(Arrays.equals(edb[i].stag, stag))
                return edb[i].mey;
        }
        return null;
    }

    public Set<byte[]> SearchXtoken(Token t, byte[] stag, Map<String, EY> mey, Set<Element> xset){
        Set<byte[]> es = new HashSet<>();

        Element[] xs = new Element[xset.size()];
        Iterator<Element> it = xset.iterator();
        for(int i=0; i<xs.length; i++){
            xs[i] = it.next();
        }

        for(int i=0; i<t.xtoken.length; i++){
            byte[] l = AES.encrypt(stag, IntToByteArray.IntToByte(i));
            String l_str = new String(l);

            EY ey = mey.get(l_str);

            int counter = 0;
            for(int j=0; j<t.xtoken[i].length; j++){
                Element xtag = t.xtoken[i][j].powZn(ey.y).getImmutable();
                //System.out.println("xtoken" + i + j + ": " + t.xtoken[i][j]);
                //System.out.println("xtag" + i + j + ": " + xtag);
                for(int k=0; k<xs.length; k++){
                    if(xs[k].isEqual(xtag)){
                        counter ++;
                        break;
                    }
                }
            }
            if(counter == t.xtoken[i].length)
                es.add(ey.e);
        }

        return es;
    }

    public static void main(String[] args){
        NSSE nsse = new NSSE();
        DBBlock[] db = ReadInvertedIndex.Read("InvertedIndex.txt");
        //DBBlock[] db = ReadInvertedIndex.Read("inverted_index_aaron_dataset.txt");
//        System.out.println("Inverted Index DB:");
//        for(int i=0; i<db.length; i++){
//            System.out.print(db[i].kw + " ");
//            for(int j=0; j<db[i].index.size(); j++){
//                System.out.print(db[i].index.get(j) + " ");
//            }
//            System.out.println();
//        }

        String[] W = new String[500];
        for(int i=0; i<W.length; i++)
        	W[i] = "w" + i;
        
        String[][] Q = new String[5][];
        for(int i=0; i<5; i++) {
        	Q[i] = new String[(i+1)*10];
        	for(int j=0; j<Q[i].length; j++)
            	Q[i][j] = "w" + j;
        }
        
//        String[] W = {"w0", "w1", "w2", "w3"};
//        String[] Q = {"w0", "w1", "w2"};
        
        //int keyLen = 512;
        int keyLen = 2048;
        int byteLen = 32;
        
        long start, end;
        
        NAllKey nak = nsse.KeySetup(keyLen);
        //NAllKeyByte nakB = new NAllKeyByte(nak);
    	
		//WRObject.writeObjectToFile("NAllKey.dat", nakB);
		//NAllKeyByte nakBR = (NAllKeyByte)WRObject.readObjectFromFile("NAllKey.dat");
		//NAllKey nakBnak = new NAllKey(nakBR, nsse.pairing);
        
        start = System.nanoTime();
        EDBAndXSet eax = nsse.EDBSetup(db, nak, byteLen);
        end = System.nanoTime();
        System.out.println("EDB Setup Time: " + (end - start));
        //EDBAndXSetByte eaxB = new EDBAndXSetByte(eax);
        
        //WRObject.writeObjectToFile("EDBAndXSet.dat", eaxB);
        //EDBAndXSetByte eaxBR = (EDBAndXSetByte)WRObject.readObjectFromFile("EDBAndXSet.dat");
        //EDBAndXSet eaxBeax = new EDBAndXSet(eaxBR, nsse.pairing);
        
//        long start, end;
//        
//        String[] W;
//        ClientKey ck = null;
//        for(int i=1; i<=4; i++) {
//        	W = new String[i*500];
//        	for(int j=0; j<W.length; j++)
//        		W[j] = "w" + (j+1);
//        	start = System.nanoTime();
//        	ck = nsse.ClientKeyGen(nakBnak, S, W);
//        	end = System.nanoTime();
//        	System.out.println(W.length + "Sk time:" + (end - start));
//        }
        
        
        start = System.nanoTime();
        ClientKey ck = nsse.ClientKeyGen(nak, W, byteLen);
        end = System.nanoTime();
        System.out.println("Client Key Time: " + (end - start));
        
        //WRObject.writeObjectToFile("ClientKey.dat", ck);
        //ClientKey ckR = (ClientKey)WRObject.readObjectFromFile("ClientKey.dat");
        
        for(int i=0; i<5; i++) {
        	   System.out.print("Query: ");
               for(int j=0; j<Q[i].length; j++)
        	   //for(int j=0; j<Q.length; j++)
                   System.out.print(Q[i][j] + " ");
        		   //System.out.print(Q[j] + " ");
               System.out.println();
               
               start = System.nanoTime();
               byte[] stag = nsse.StagGen(Q[i][0], W, ck, nak.npp.n, byteLen);
               //byte[] stag = nsse.StagGen(Q[0], W, ck, nak.npp.n, byteLen);

               Map<String, EY> mey = nsse.SearchStag(stag, eax.edb);

               Token t = nsse.TokenGen(mey.size(), Q[i][0], W, Q[i], ck, nak.npp.n, nak.npp.g, byteLen);
               //Token t = nsse.TokenGen(mey.size(), Q[0], W, Q, ck, nak.npp.n, nak.npp.g, byteLen);
               //TokenByte tB = new TokenByte(t);
               
               //WRObject.writeObjectToFile("Token.dat", tB);
               //TokenByte tBR = (TokenByte)WRObject.readObjectFromFile("Token.dat");
               //Token tBt = new Token(tBR, nsse.pairing);

               Set<byte[]> es = nsse.SearchXtoken(t, stag, mey, eax.xset);
               end = System.nanoTime();
               System.out.println("Search Time: " + (end - start));

               Iterator<byte[]> it = es.iterator();
               
               byte[] k_w = AES.encrypt(ck.K, stag);
               while (it.hasNext()){
                   byte[] e = it.next();
                   byte[] id = AES.decrypt(k_w, e);
                   System.out.println(new String(id));
               }
        }
    }
}
