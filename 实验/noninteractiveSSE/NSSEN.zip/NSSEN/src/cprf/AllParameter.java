package cprf;

import java.util.Map;

public class AllParameter {
	public Map<String, String> kbs;
}
