package cprf;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import util.AES;

public class CPRF {
	
	public Map<String, String> KeywordMap(String[] kws){
		Map<String, String> kbs = new HashMap<>();
		
		if(kws.length == 1) {
			kbs.put(kws[0], "");
		} else {
			String kb = Integer.toBinaryString(kws.length-1);
			
			for(int i=0; i<kws.length; i++) {
				String b = Integer.toBinaryString(i);
				char[] temp = new char[kb.length()];
				for(int j=0; j<temp.length; j++)
					temp[j] = '0';
				
				int extral = kb.length()-b.length();
				for(int j=0; j<b.length(); j++)
					temp[extral + j] = b.charAt(j);
				
				kbs.put(kws[i], new String(temp));
			}
		}
		
		return kbs;
	}
	
	public Set<String> GetCover(String[] ckw, Map<String, String> kbs){
		
		Set<String> bs = new HashSet<>();
		Set<String> bs_new = new HashSet<>();
		Set<String> rs = new HashSet<>();
		
		for(int i=0; i<ckw.length; i++)
			bs.add(kbs.get(ckw[i]));
		
		if(kbs.size() == 1)
			return bs;
		
		GetCoverSub(bs, bs_new, rs);
		
		return rs;
	}
	
	public void GetCoverSub(Set<String> bs, Set<String> bs_new, Set<String> rs) {
		
		while(!bs.isEmpty()) {
			String b = bs.iterator().next();
			bs.remove(b);
			
			if(b.length()>0) {
				String b_o;
				if(b.endsWith("0")) {
					if(b.length()==1)
						b_o = "1";
					else
						b_o = b.substring(0, b.length()-1).concat("1");
				}else {
					if(b.length()==1)
						b_o = "0";
					else
						b_o = b.substring(0, b.length()-1).concat("0");
				}
					
				if(bs.contains(b_o)) {
					bs.remove(b_o);
					String b_n;
					if(b.length() == 1) {
						b_n = "";
						rs.add(b_n);
					} else {
						b_n = b.substring(0, b.length()-1);
						bs_new.add(b_n);
					}	
				}else {
					rs.add(b);
				}
			}
		}
		if(bs_new.isEmpty())
			return ;
		
		bs.clear();
		bs.addAll(bs_new);
		bs_new.clear();
		
		GetCoverSub(bs, bs_new, rs);
	}
	
	public AllParameter Setup(String[] kws) {
		AllParameter ap = new AllParameter();
		ap.kbs = KeywordMap(kws);
		
		return ap;
	}
	
	public byte[] PRFW(String kw, Map<String, String> kbs, byte[] mkey){
		String b = kbs.get(kw);
		if(b.length() == 0)
			return mkey;
		else {
			int n = b.length();
			int c = 0;
			byte[] key = mkey;
			byte[] key_new;
				
			while(c<n) {
				key_new = AES.encrypt(key, b.substring(c, c+1).getBytes());
				c++;
				key = key_new;
			}
			return key;
		}
	}
	
	public Map<String, byte[]> CKeyGen(String[] ckw, Map<String, String> kbs, byte[] mkey) {
		Map<String, byte[]> ck = new HashMap<>();
		
		Set<String> cv = GetCover(ckw, kbs);
		Iterator<String> it = cv.iterator();
		
		while(it.hasNext()) {
			String v = it.next();
			
			if(v.length() == 0) {
				ck.put(v, mkey);
			}else {
				int n = v.length();
				int c = 0;
				byte[] key = mkey;
				byte[] key_new;
				while(c<n) {
					key_new = AES.encrypt(key, v.substring(c, c+1).getBytes());
					c++;
					key = key_new;
				}
				ck.put(v, key);
			}
		}
		
		return ck;
	}
	
	public byte[] PRFW(Map<String, byte[]> ck, String kw, Map<String, String> kbs) {
		String b = kbs.get(kw);
		
		Set<String> bs = ck.keySet();
		
		String b_p;
		Stack<String> st = new Stack<>();
		while(b.length() >= 0) {
			if(bs.contains(b)) {
				byte[] key = ck.get(b);
				byte[] key_new;
				while(!st.isEmpty()) {
					String m = st.pop();
					key_new = AES.encrypt(key, m.getBytes());
					key = key_new;
				}
				return key;
			}else {
				if(b.length()>0) {
					b_p = b.substring(b.length()-1, b.length());
					st.push(b_p);
					b = b.substring(0, b.length()-1);
				}else {
					return null;
				}
			}
		}
		return null;
	} 
	
	public static void main(String[] args) {
		CPRF cp = new CPRF();
		String kws[] = {"w0", "w1", "w2", "w3", "w4", "w5", "w6", "w7"};
		//String kws[] = {"w0"};
		
		//String ckw[] = {"w0", "w1", "w2", "w3", "w4", "w5", "w6", "w7"};
		//String ckw[] = {"w0", "w1", "w2", "w3"};
		//String ckw[] = {"w0", "w1"};
		String ckw[] = {"w0", "w1", "w5", "w6", "w7"};
		//String ckw[] = {"w0"};
		
		byte[] key = {1,1,1};
		AllParameter ap = cp.Setup(kws);
		System.out.println(cp.GetCover(ckw, ap.kbs).size());
		Map<String, byte[]> ck = cp.CKeyGen(ckw, ap.kbs, key);
		
		byte[] prfw = cp.PRFW(kws[6], ap.kbs, key);
		
		byte[] prfw_ck = cp.PRFW(ck, kws[6], ap.kbs);
		
		System.out.println(ck);
		System.out.println(Arrays.equals(prfw, prfw_ck));
		//System.out.println(prfw);
	}
	
}
