package util;

import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

public class PR {
	public static Pairing pairing = PairingFactory.getPairing("params/curves/a.properties");
}
