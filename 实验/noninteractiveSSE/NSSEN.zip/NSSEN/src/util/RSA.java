package util;

import entity.Result;

import java.math.BigInteger;

public class RSA {
	
	public static BigInteger getInverse(BigInteger p, BigInteger q, BigInteger e){
		Result r = new Result();

		BigInteger p1 = p.subtract(BigInteger.ONE);			// p1 = p - 1
		BigInteger q1 = q.subtract(BigInteger.ONE);			// q1 = q - 1
		BigInteger n1 = p1.multiply(q1);					// n1 = p1 * q1 n

		exGcd(e, n1, r);
//		if(r.getX().compareTo(BigInteger.ZERO) == -1)
//			return null;
		BigInteger d = r.getX();
		return d.add(n1).mod(n1);
	}
	
	public static Result exGcd(BigInteger a, BigInteger b, Result r){
		if(b.toString().equals("0")){
			r.setX(new BigInteger("1"));
			r.setY(new BigInteger("0"));
			return r;
		}
		r = exGcd(b, a.divideAndRemainder(b)[1], r);
		
		BigInteger temp = r.getX();
		r.setX(r.getY());										//x=y'
		r.setY(temp.subtract(a.divide(b).multiply(r.getY())));	//y=x'-a/b*y'
		return r;
	}
}
