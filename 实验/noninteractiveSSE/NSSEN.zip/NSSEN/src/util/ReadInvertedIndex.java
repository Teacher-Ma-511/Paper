package util;

import entity.DBBlock;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ReadInvertedIndex {
    public static DBBlock[] Read(String filename){
        String str = "";
        Set<DBBlock> sdb = new HashSet<DBBlock>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            while((str=br.readLine()) != null){
                DBBlock dbb = new DBBlock();
                String str_a[] = str.split(" ");
                dbb.kw = str_a[0];
                String index[] = str_a[1].split(",");
                for(int i=0; i<index.length; i++)
                    dbb.index.put(i, index[i]);
                sdb.add(dbb);
            }
            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        DBBlock[] db = new DBBlock[sdb.size()];

        Iterator<DBBlock> it = sdb.iterator();
        int i = 0;
        while(it.hasNext()){
            db[i] = it.next();
            i++;
        }

        return db;
    }
}
