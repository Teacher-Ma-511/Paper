package util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class WRObject {
    public static void writeObjectToFile(String filename, Object obj)
    {
        ObjectOutputStream out;
        try {
            out = new ObjectOutputStream(new FileOutputStream(filename));
            out.writeObject(obj);
            out.flush();
            out.close();
        } catch (IOException e) {
            System.out.println("write object failed");
            e.printStackTrace();
        }
    }
    
    public static Object readObjectFromFile(String filename)
    {
        Object temp=null;
        ObjectInputStream in;
        try {
            in = new ObjectInputStream(new FileInputStream(filename));
            temp= in.readObject();
            in.close();
        } catch (IOException e) {
            System.out.println("read object failed");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return temp;
    }
}
