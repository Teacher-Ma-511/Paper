package util;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class GenInvertedIndex {
	public static void Gen(String filename) {
		try {
			FileWriter fw = new FileWriter(filename);
			
			Random r = new Random();
			for(int i=0; i<500; i++) {
				String str = "w" + String.valueOf(i) + " ";
				for(int j=0; j<200; j++)
					str = str + r.nextInt(500) + ",";
				fw.write(str + "\n");
			}
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		GenInvertedIndex.Gen("InvertedIndex.txt");
	}
}
