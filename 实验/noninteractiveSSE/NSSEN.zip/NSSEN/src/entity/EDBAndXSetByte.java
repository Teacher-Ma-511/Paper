package entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import it.unisa.dia.gas.jpbc.Element;

public class EDBAndXSetByte implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public EDBBlockByte[] edb;
    public Set<byte[]> xset = new HashSet<byte[]>();
    
    public EDBAndXSetByte(EDBAndXSet eax) {
    	edb = new EDBBlockByte[eax.edb.length];
    	for(int i=0; i<edb.length; i++)
    		edb[i] = new EDBBlockByte(eax.edb[i]);
    	
    	Iterator<Element> it = eax.xset.iterator();
    	while(it.hasNext()) {
    		Element xtag = it.next();
    		byte[] xtagB = xtag.toBytes();
    		xset.add(xtagB);
    	}
    }
}
