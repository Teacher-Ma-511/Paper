package entity;

import java.io.Serializable;
import java.math.BigInteger;

public class NPublicParamByte implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public byte[] g;
	public BigInteger n;
	 
	public NPublicParamByte(NPublicParam npp) {
		g = npp.g.toBytes();
		n = npp.n;
	}
}
