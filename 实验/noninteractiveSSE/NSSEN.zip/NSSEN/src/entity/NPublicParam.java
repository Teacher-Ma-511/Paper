package entity;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;

import java.math.BigInteger;

public class NPublicParam{
    public Element g;
    public BigInteger n;
    
    public NPublicParam() {}
    
    public NPublicParam(NPublicParamByte nppB, Pairing pairing) {
    	g = pairing.getGT().newElementFromBytes(nppB.g).getImmutable();
    	n = nppB.n;
    }
}
