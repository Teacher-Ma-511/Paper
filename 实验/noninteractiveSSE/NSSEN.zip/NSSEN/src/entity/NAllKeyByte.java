package entity;

import java.io.Serializable;

public class NAllKeyByte implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public NMasterSecretKey nmsk;
    public NPublicParamByte npp;
    
    public NAllKeyByte(NAllKey nak) {
    	nmsk = nak.nmsk;
    	npp = new NPublicParamByte(nak.npp);
    }
}
