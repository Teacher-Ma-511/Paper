package entity;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class EDBBlockByte implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public byte[] stag;
    public Map<String, EYByte> mey = new HashMap<>();
    
    public EDBBlockByte(EDBBlock eb) {
    	stag = eb.stag;
    	
    	Set<String> ks = eb.mey.keySet();
		Iterator<String> it = ks.iterator();
		while(it.hasNext()) {
			String key = it.next();
			EY ey = eb.mey.get(key);
			EYByte eyB = new EYByte(ey);
			
			mey.put(key, eyB);
		}
    }
}
