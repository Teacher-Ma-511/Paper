package entity;

import java.io.Serializable;
import java.util.Map;

public class ClientKeyP implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public byte[] K;
	public byte[] K_S;
    public byte[] K_I;
    public byte[] K_Z;
    public byte[] K_X;
    
    public Map<String, byte[]> ckw1;
    public Map<String, byte[]> ckw2;
    public Map<String, byte[]> ckw3;
    
    public Map<String, String> kbs;
    
    public ClientKeyP() {}
}
