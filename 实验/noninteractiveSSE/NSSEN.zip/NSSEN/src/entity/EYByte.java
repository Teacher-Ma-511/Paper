package entity;

import java.io.Serializable;

public class EYByte implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public byte[] e;
    public byte[] y;
    
    public EYByte(EY ey) {
    	e = ey.e;
    	y = ey.y.toBytes();
    }
}
