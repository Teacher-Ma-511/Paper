package entity;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;

public class EY {
    public byte[] e;
    public Element y;

    public EY(){
    }
    
    public EY(EYByte eyB, Pairing pairing) {
    	e = eyB.e;
    	y = pairing.getZr().newElementFromBytes(eyB.y).getImmutable();
    }
}
