package entity;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;

public class Token {
    public Element[][] xtoken;

    public Token(int c, int m){
        xtoken = new Element[c][];
        for(int i=0; i<c; i++)
            xtoken[i] = new Element[m];
    }
    
    public Token(TokenByte tkB, Pairing pairing) {
    	xtoken = new Element[tkB.xtoken.length][];
    	for(int i=0; i<xtoken.length; i++) {
    		xtoken[i] = new Element[tkB.xtoken[i].length];
    		for(int j=0; j<xtoken[i].length; j++)
    			xtoken[i][j] = pairing.getGT().newElementFromBytes(tkB.xtoken[i][j]).getImmutable();
    	}
    }
}
