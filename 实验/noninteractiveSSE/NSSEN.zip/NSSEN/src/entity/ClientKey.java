package entity;

import java.io.Serializable;
import java.math.BigInteger;

public class ClientKey implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public byte[] K;
	public byte[] K_S;
    public byte[] K_I;
    public byte[] K_Z;
    public byte[] K_X;
    public BigInteger[] sk_w = new BigInteger[3];
    
    public ClientKey() {}
}
