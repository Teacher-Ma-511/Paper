package entity;

import it.unisa.dia.gas.jpbc.Pairing;

public class NAllKey{
    public NMasterSecretKey nmsk;
    public NPublicParam npp;

    public NAllKey(){
        nmsk = new NMasterSecretKey();
        npp = new NPublicParam();
    }
    
    public NAllKey(NAllKeyByte nakB, Pairing pairing) {
    	nmsk = nakB.nmsk;
    	npp = new NPublicParam(nakB.npp, pairing);
    }
}
