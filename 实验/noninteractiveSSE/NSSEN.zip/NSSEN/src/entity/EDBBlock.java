package entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import it.unisa.dia.gas.jpbc.Pairing;

public class EDBBlock {
	
	public byte[] stag;
    //public Map<byte[], EY> mey = new HashMap<>();
    public Map<String, EY> mey = new HashMap<>();
    
    public EDBBlock() {}
    
    public EDBBlock(EDBBlockByte ebB, Pairing pairing) {
    	stag = ebB.stag;
    	
    	Set<String> ks = ebB.mey.keySet();
		Iterator<String> it = ks.iterator();
		while(it.hasNext()) {
			String key = it.next();
			EYByte eyB = ebB.mey.get(key);
			EY ey = new EY(eyB, pairing);
			
			mey.put(key, ey);
		}
    }
}
