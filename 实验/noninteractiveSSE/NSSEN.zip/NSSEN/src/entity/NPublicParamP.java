package entity;

import it.unisa.dia.gas.jpbc.Element;

import java.util.Map;

public class NPublicParamP{
    public Element g;
    public Map<String, String> kbs;
}
