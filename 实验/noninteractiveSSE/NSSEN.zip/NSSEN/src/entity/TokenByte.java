package entity;

import java.io.Serializable;

public class TokenByte implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public byte[][][] xtoken;
	
	public TokenByte(Token tk) {
		xtoken = new byte[tk.xtoken.length][][];
		for(int i=0; i<xtoken.length; i++) {
			xtoken[i] = new byte[tk.xtoken[i].length][];
			for(int j=0; j<xtoken[i].length; j++)
				xtoken[i][j] = tk.xtoken[i][j].toBytes();
		}
	}
}
