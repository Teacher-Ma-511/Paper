package entity;

import java.io.Serializable;
import java.math.BigInteger;

public class Result implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private BigInteger x,y;
	
	public Result(){
		x = y = new BigInteger("0");
	}
	
	public void setX(BigInteger x){
		this.x = x;
	}
	
	public void setY(BigInteger y){
		this.y = y;
	}
	
	public BigInteger getX(){
		return this.x;
	}
	
	public BigInteger getY(){
		return this.y;
	}
}
