package entity;

public class NAllKeyP{
    public NMasterSecretKeyP nmskp;
    public NPublicParamP nppp;

    public NAllKeyP(){
        nmskp = new NMasterSecretKeyP();
        nppp = new NPublicParamP();
    }
}
