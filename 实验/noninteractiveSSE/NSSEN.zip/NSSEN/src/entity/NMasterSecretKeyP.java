package entity;

import java.io.Serializable;

public class NMasterSecretKeyP implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public byte[] K;
    public byte[] K_S;
    public byte[] K_I;
    public byte[] K_Z;
    public byte[] K_X;
    
    public byte[] K1;
    public byte[] K2;
    public byte[] K3;
    
    public NMasterSecretKeyP() {}
}
