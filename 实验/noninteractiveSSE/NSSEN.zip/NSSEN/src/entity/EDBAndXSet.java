package entity;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;

public class EDBAndXSet {
    public EDBBlock[] edb;
    public Set<Element> xset = new HashSet<Element>();

    public EDBAndXSet(int n){
        edb = new EDBBlock[n];

        for(int i=0; i<n; i++)
            edb[i] = new EDBBlock();
    }
    
    public EDBAndXSet(EDBAndXSetByte eaxB, Pairing pairing) {
    	edb = new EDBBlock[eaxB.edb.length];
    	
    	for(int i=0; i<edb.length; i++)
    		edb[i] = new EDBBlock(eaxB.edb[i], pairing);
    	
    	Iterator<byte[]> it = eaxB.xset.iterator();
    	while(it.hasNext()) {
    		byte[] xtagB = it.next();
    		Element xtag = pairing.getGT().newElementFromBytes(xtagB);
    		xset.add(xtag);
    	}
    }
}
