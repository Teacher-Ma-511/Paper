#!/bin/bash
echo "开始删除!"
rm -r /home/helen/Desktop/sse/sample/test
rm -r /home/helen/Desktop/sse/sample/sdb
mkdir  /home/helen/Desktop/sse/sample/test
mkdir  /home/helen/Desktop/sse/sample/sdb


